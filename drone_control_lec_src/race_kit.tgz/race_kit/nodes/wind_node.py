#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""바람 구역 노드. 드론이 구역 안에 있을 때만 항력 F = 1/2 rho C_dA |w - v| (w - v) 를 가한다.

돌풍은 구역의 seed 로 정해지는 두 사인파의 합이고 위치로 정해진다(같은 길을 가면 실행할 때마다 같은 바람).
"""
import argparse
import json
import math
import sys

import rospy
import yaml
from gazebo_msgs.msg import ModelStates
from gazebo_msgs.srv import ApplyBodyWrench
from geometry_msgs.msg import Point, Vector3, Wrench
from std_msgs.msg import String

RHO = 1.225
EDGE = 0.5          # 구역 경계에서 바람이 0 에서 다 커질 때까지의 거리 (m)
RATE_HZ = 25.0


def gust_value(zone, pos, t):
    """돌풍 세기 (m/s). gust_length_m 이 있으면 위치로 정해지는 굳은 무늬(같은 길을 가면 늘 같은 바람),
    없으면 gust_period_s 로 시간에 따라 바뀐다."""
    amp = float(zone.get("gust_amp", 0.0))
    if amp <= 0.0:
        return 0.0
    seed = float(zone.get("seed", 0))
    p1 = (seed * 0.731) % (2.0 * math.pi)
    p2 = (seed * 1.913) % (2.0 * math.pi)
    if "gust_length_m" in zone:
        lam = float(zone["gust_length_m"])
        w = zone["wind"]
        mag = math.hypot(float(w[0]), float(w[1])) or 1.0
        u = (pos[0] * (-float(w[1])) + pos[1] * float(w[0])) / mag      # 바람에 수직인 방향의 좌표
        s = (pos[0] * float(w[0]) + pos[1] * float(w[1])) / mag         # 바람 방향의 좌표
        return amp * (0.6 * math.sin(2.0 * math.pi * u / lam + p1) + 0.4 * math.sin(2.0 * math.pi * (u + 0.5 * s) / (0.37 * lam) + p2))
    period = float(zone.get("gust_period_s", 3.0))
    return amp * (0.6 * math.sin(2.0 * math.pi * t / period + p1) + 0.4 * math.sin(2.0 * math.pi * t / (0.37 * period) + p2))


def wind_at(zones, pos, t):
    """위치와 시각에서의 바람 벡터와 구역 이름."""
    total = [0.0, 0.0, 0.0]
    name = ""
    for z in zones:
        d = min(pos[0] - z["xmin"], z["xmax"] - pos[0], pos[1] - z["ymin"], z["ymax"] - pos[1],
                pos[2] - z["zmin"], z["zmax"] - pos[2])
        if d <= 0.0:
            continue
        k = min(d / EDGE, 1.0)
        w = [float(v) for v in z["wind"]]
        mag = math.sqrt(sum(v * v for v in w))
        if mag < 1e-6:
            continue
        g = gust_value(z, pos, t)
        for i in range(3):
            total[i] += k * (w[i] + g * w[i] / mag)
        name = z["id"]
    return total, name


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--course", required=True)
    ap.add_argument("--vehicle", required=True)
    a = ap.parse_args(rospy.myargv()[1:])
    with open(a.course, encoding="utf-8") as f:
        course = yaml.safe_load(f)
    with open(a.vehicle, encoding="utf-8") as f:
        vehicle = yaml.safe_load(f)
    zones = course.get("wind_zones", []) or []
    cda = float(vehicle["cda"])
    rospy.init_node("race_wind")
    state = {"pos": None, "vel": None}

    def on_models(msg):
        try:
            i = msg.name.index("iris")
        except ValueError:
            return
        p = msg.pose[i].position
        v = msg.twist[i].linear
        state["pos"] = (p.x, p.y, p.z)
        state["vel"] = (v.x, v.y, v.z)

    rospy.Subscriber("/gazebo/model_states", ModelStates, on_models, queue_size=1)
    pub = rospy.Publisher("/race/wind", String, queue_size=5)
    if not zones:
        rospy.loginfo("wind: no zones in this course")
    rospy.wait_for_service("/gazebo/apply_body_wrench")
    srv = rospy.ServiceProxy("/gazebo/apply_body_wrench", ApplyBodyWrench, persistent=True)
    rate = rospy.Rate(RATE_HZ)
    dt = 1.0 / RATE_HZ
    n = 0
    while not rospy.is_shutdown():
        rate.sleep()
        if state["pos"] is None or not zones:
            continue
        t = rospy.get_time()
        w, name = wind_at(zones, state["pos"], t)
        force = [0.0, 0.0, 0.0]
        if name:
            rel = [w[i] - state["vel"][i] for i in range(3)]
            mag = math.sqrt(sum(r * r for r in rel))
            force = [0.5 * RHO * cda * mag * r for r in rel]
            try:
                srv(body_name="iris::base_link", reference_frame="world", reference_point=Point(0.0, 0.0, 0.0),
                    wrench=Wrench(force=Vector3(*force), torque=Vector3(0.0, 0.0, 0.0)),
                    start_time=rospy.Time(0), duration=rospy.Duration(dt))
            except rospy.ServiceException as e:
                rospy.logwarn_throttle(5.0, "wind: apply_body_wrench failed: %s" % e)
                srv = rospy.ServiceProxy("/gazebo/apply_body_wrench", ApplyBodyWrench, persistent=True)
        n += 1
        if n % 5 == 0:
            pub.publish(String(data=json.dumps({"t": round(t, 3), "zone": name, "w": [round(v, 2) for v in w],
                                                "f": [round(v, 3) for v in force]})))
    return 0


if __name__ == "__main__":
    sys.exit(main())
