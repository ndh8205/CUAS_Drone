#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""레이스 실행 노드 (키트 원본). 코스의 요소를 순서대로 비행하고 게인 파일의 값을 PX4 에 적용한다.

하는 일
- 게인 적용  : 게인 파일의 base 값을 PX4 파라미터로 적용, 구간(tag)이 바뀔 때 그 구간의 값으로 변경 (게인 스케줄)
- 목표점     : 게이트와 제자리 유지 지점의 위치 목표를 /mavros/setpoint_position/local 로 발행
- 비전 착륙  : 아래 방향 카메라에서 ArUco 표식을 찾아 그 위로 이동한 뒤 하강 (기체 기울기는 보정하지 않음)

수정 방법
- 이 파일을 my_code/my_runner.py 로 복사해 수정 (그 파일이 있으면 race.sh 가 그 파일로 실행)
- 심판(nodes/referee.py)은 이 노드의 신호를 받지 않고 Gazebo 참값으로만 판정
- /race/state 로 발행하는 글은 터미널의 진행 줄과 드론 카메라 창에만 사용

수정 위치
- gains_for()      : 상황에 맞는 게인 20개 결정. 원본은 구간 이름으로만 결정
- apply_gains()    : 게인을 PX4 에 적용. 비행 중 원하는 때에 호출 가능
- do_gate()        : 게이트로 가는 목표점 결정
- do_hold()        : 제자리 유지 지점에서의 유지
- do_land()        : 표식 탐색, 정렬, 하강. 표식 위치는 on_image() 가 계산
"""
import argparse
import json
import math
import os
import sys

import cv2
import numpy as np
import rospy
import yaml
from gazebo_msgs.msg import ModelStates
from geometry_msgs.msg import PoseStamped, TwistStamped
from mavros_msgs.msg import ParamValue, State
from mavros_msgs.srv import CommandBool, CommandLong, ParamGet, ParamSet, SetMode
from sensor_msgs.msg import CompressedImage
from std_msgs.msg import String

# 게인 파일로 바꿀 수 있는 PX4 게인과 허용 범위 (최소, 최대). 게인 파일에 없는 게인은 최솟값으로 넣는다.
ALLOWED = {
    "MPC_XY_P": (0.1, 2.0), "MPC_Z_P": (0.1, 1.5),
    "MPC_XY_VEL_P_ACC": (1.2, 5.0), "MPC_XY_VEL_I_ACC": (0.0, 10.0), "MPC_XY_VEL_D_ACC": (0.1, 2.0),
    "MPC_Z_VEL_P_ACC": (2.0, 15.0), "MPC_Z_VEL_I_ACC": (0.2, 3.0), "MPC_Z_VEL_D_ACC": (0.0, 2.0),
    "MC_ROLL_P": (0.5, 12.0), "MC_PITCH_P": (0.5, 12.0), "MC_YAW_P": (0.5, 5.0),
    "MC_ROLLRATE_P": (0.01, 0.5), "MC_ROLLRATE_I": (0.0, 2.0), "MC_ROLLRATE_D": (0.0, 0.01),
    "MC_PITCHRATE_P": (0.01, 0.6), "MC_PITCHRATE_I": (0.0, 2.0), "MC_PITCHRATE_D": (0.0, 0.01),
    "MC_YAWRATE_P": (0.0, 0.6), "MC_YAWRATE_I": (0.0, 2.0), "MC_YAWRATE_D": (0.0, 0.01),
}
TAGS = ("cruise", "wind", "precision", "landing")
RATE_HZ = 20.0
GATE_SWITCH_DIST = 2.0      # 게이트 중심에 이만큼 다가가면 목표를 게이트 뒤쪽 점으로 바꿈 (m)
GATE_EXIT_DIST = 1.5        # 게이트 뒤쪽 목표점까지의 거리 (m)
ITEM_TIMEOUT_S = 30.0       # 게이트 하나에 쓰는 최대 시간 (심판의 제한 시간과 같음)
HOLD_TIMEOUT_S = 25.0       # 제자리 유지 하나에 쓰는 최대 시간 (심판의 제한 시간과 같음)
CAM_HFOV = 1.047            # iris 카메라 수평 화각 (rad)
ALIGN_TOL_M = 0.12
ALIGN_HOLD_S = 1.0
DESCEND_RATE = 0.5          # 착륙 접근 하강 속도 (m/s)
FINAL_HEIGHT = 1.5          # 패드 위 이 높이부터는 표식 전체가 화면에 안 들어와 PX4 자동 착륙으로 넘김 (m)
ZB_TAU = 0.7                # 높이 보정 값의 저역 통과 시간 상수 (s)
LIFTOFF_DZ = 0.10           # 출발 높이에서 이만큼 뜨면 이륙으로 봄 (m). 심판의 기록 시작 기준과 같음
LIFTOFF_WAIT_S = 20.0       # 이 시간 안에 뜨지 못하면 그만둠


def yaw_to_quat(yaw):
    return (0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0))


def quat_to_yaw(q):
    return math.atan2(2.0 * (q.w * q.z + q.x * q.y), 1.0 - 2.0 * (q.y * q.y + q.z * q.z))


class Runner(object):
    def __init__(self, course, gains, px4_params):
        self.course = course
        self.base = dict(gains.get("base", {}) or {})
        self.schedule = dict(gains.get("schedule", {}) or {})
        self.px4_params = px4_params
        self.start = (float(course["start"]["x"]), float(course["start"]["y"]))
        self.state = State()
        self.pos = None
        self.yaw = 0.0
        self.vel = (0.0, 0.0, 0.0)
        self.truth_z = None                           # Gazebo 참값 높이 (월드 z)
        self.zb = 0.0                                 # 높이 보정 값 = PX4 추정 높이 - 참값 높이
        self.zb_on = not os.environ.get("RACE_NO_ZCORR")
        self.t_pose = None
        self.applied = {}
        self.tag = None
        self.target = None
        self.target_yaw = 0.0
        self.aruco_dict = cv2.aruco.Dictionary_get(cv2.aruco.DICT_4X4_1000)
        self.aruco_params = cv2.aruco.DetectorParameters_create()
        self.vis = {"stamp": None, "offset": None, "est": None, "count": 0, "h": None}
        self.image_sub = None
        landing = course.get("landing") or {}
        self.marker_id = int(landing["marker"]["id"]) if landing else None
        self.pattern = float(landing["marker"]["pattern_size"]) if landing else None
        rospy.Subscriber("/mavros/state", State, self.on_state, queue_size=5)
        rospy.Subscriber("/mavros/local_position/pose", PoseStamped, self.on_pose, queue_size=5)
        rospy.Subscriber("/mavros/local_position/velocity_local", TwistStamped, self.on_vel, queue_size=5)
        rospy.Subscriber("/gazebo/model_states", ModelStates, self.on_models, queue_size=1)
        self.sp_pub = rospy.Publisher("/mavros/setpoint_position/local", PoseStamped, queue_size=5)
        self.state_pub = rospy.Publisher("/race/state", String, queue_size=20, latch=True)
        self.vis_pub = rospy.Publisher("/race/vision", String, queue_size=20)
        rospy.wait_for_service("/mavros/param/set")
        self.srv_param = rospy.ServiceProxy("/mavros/param/set", ParamSet)
        self.srv_get = rospy.ServiceProxy("/mavros/param/get", ParamGet)
        self.srv_mode = rospy.ServiceProxy("/mavros/set_mode", SetMode)
        self.srv_arm = rospy.ServiceProxy("/mavros/cmd/arming", CommandBool)
        self.srv_cmd = rospy.ServiceProxy("/mavros/cmd/command", CommandLong)
        self.ground_z = None                          # 출발 때 참값 높이
        self.rate = rospy.Rate(RATE_HZ)

    # ---------- 받은 자료 ----------
    def on_state(self, msg):
        self.state = msg

    def on_pose(self, msg):
        p = msg.pose.position
        self.pos = (p.x, p.y, p.z)
        self.yaw = quat_to_yaw(msg.pose.orientation)
        # 높이 보정: 항법은 평가 대상이 아니므로 PX4 추정 높이의 느린 오차를 참값으로 걷어 낸다
        if self.zb_on and self.truth_z is not None:
            now = rospy.get_time()
            b = p.z - self.truth_z
            if self.t_pose is None:
                self.zb = b
            else:
                a = min(max((now - self.t_pose) / ZB_TAU, 0.0), 1.0)
                self.zb += a * (b - self.zb)
            self.t_pose = now

    def on_models(self, msg):
        try:
            i = msg.name.index("iris")
        except ValueError:
            return
        self.truth_z = msg.pose[i].position.z

    def alt(self):
        """월드 기준 높이 (m). 코스 파일의 z 와 같은 기준."""
        return self.pos[2] - self.zb

    def on_vel(self, msg):
        v = msg.twist.linear
        self.vel = (v.x, v.y, v.z)

    def on_image(self, msg):
        """아래 방향 카메라 영상에서 착륙 표식을 찾아 표식의 위치를 계산한다."""
        if self.pos is None:
            return
        img = cv2.imdecode(np.frombuffer(msg.data, np.uint8), cv2.IMREAD_GRAYSCALE)
        if img is None:
            return
        hgt, wid = img.shape[:2]
        corners, ids, _ = cv2.aruco.detectMarkers(img, self.aruco_dict, parameters=self.aruco_params)
        found = None
        if ids is not None:
            for c, i in zip(corners, ids.flatten()):
                if int(i) == self.marker_id:
                    found = c[0]
                    break
        if found is None:
            self.vis["count"] = 0
            return
        u, v = found.mean(axis=0)
        side = float(np.mean([np.linalg.norm(found[k] - found[(k + 1) % 4]) for k in range(4)]))
        fx = (wid / 2.0) / math.tan(CAM_HFOV / 2.0)
        h = fx * self.pattern / max(side, 1.0)                 # 표식 크기로 구한 높이
        xb = (hgt / 2.0 - v) / fx * h                          # 화면 위쪽 = 기체 앞쪽
        yb = (wid / 2.0 - u) / fx * h                          # 화면 왼쪽 = 기체 왼쪽
        c, s = math.cos(self.yaw), math.sin(self.yaw)
        dx, dy = xb * c - yb * s, xb * s + yb * c              # 기울기 보정 없음
        new = (self.pos[0] + dx, self.pos[1] + dy)
        est = self.vis["est"]
        self.vis["est"] = new if est is None else (est[0] + 0.25 * (new[0] - est[0]), est[1] + 0.25 * (new[1] - est[1]))
        self.vis["offset"] = (dx, dy)
        self.vis["h"] = h
        self.vis["stamp"] = rospy.get_time()
        self.vis["count"] += 1
        self.vis_pub.publish(String(data=json.dumps({
            "t": round(self.vis["stamp"], 3), "side": round(side, 2), "h": round(h, 3), "xb": round(xb, 3), "yb": round(yb, 3),
            "dx": round(dx, 3), "dy": round(dy, 3), "ex": round(self.vis["est"][0], 3), "ey": round(self.vis["est"][1], 3),
            "px": round(self.pos[0], 3), "py": round(self.pos[1], 3), "pz": round(self.pos[2], 3), "yaw": round(self.yaw, 4),
            "zb": round(self.zb, 3)})))

    # ---------- 도우미 ----------
    def local(self, x, y):
        return (x - self.start[0], y - self.start[1])

    def say(self, phase, item="", sub="", extra=None):
        """진행 상황을 알린다 (터미널의 진행 줄과 드론 카메라 창에 쓰임. 채점에는 쓰이지 않음)."""
        d = {"t": round(rospy.get_time(), 3), "phase": phase, "item": item, "sub": sub, "tag": self.tag or ""}
        if extra:
            d.update(extra)
        self.state_pub.publish(String(data=json.dumps(d)))
        rospy.loginfo("RACE %s" % json.dumps(d, ensure_ascii=False))

    def set_param(self, name, value, integer=False):
        pv = ParamValue(integer=int(value), real=0.0) if integer else ParamValue(integer=0, real=float(value))
        for _ in range(3):
            try:
                r = self.srv_param(param_id=name, value=pv)
                if r.success:
                    return True
            except rospy.ServiceException:
                pass
            self.spin(0.1)
        rospy.logwarn("param set failed: %s" % name)
        return False

    # ---------- 게인 (게인 스케줄) ----------
    def gains_for(self, tag):
        """구간 이름에 쓸 게인 20개를 돌려준다: 최솟값 위에 base, 그 위에 그 구간의 값. 범위를 벗어난 값은 범위 끝값."""
        g = dict(self.base)
        g.update(self.schedule.get(tag, {}) or {})
        out = {k: lo for k, (lo, hi) in ALLOWED.items()}
        for k, v in g.items():
            if k not in ALLOWED:
                continue
            try:
                x = float(v)
            except (TypeError, ValueError):
                continue
            lo, hi = ALLOWED[k]
            out[k] = min(max(x, lo), hi)
        return out

    def apply_gains(self, gains):
        """게인을 PX4 에 넣는다. 지금 값과 다른 것만 보낸다. 바꾼 값을 돌려준다."""
        changed = {}
        for k, v in gains.items():
            if self.applied.get(k) is None or abs(self.applied[k] - v) > 1e-9:
                if self.set_param(k, v):
                    self.applied[k] = v
                    changed[k] = v
                self.publish_target()                 # 값을 바꾸는 동안에도 목표를 계속 보냄
        return changed

    def apply_tag(self, tag):
        """구간이 바뀌면 그 구간의 게인 조로 바꾼다."""
        if tag == self.tag:
            return
        self.tag = tag
        changed = self.apply_gains(self.gains_for(tag))
        rospy.loginfo("GAINS tag=%s changed=%s" % (tag, json.dumps(changed)))

    def check_gains(self):
        """게인 파일 점검. 바꿀 수 없는 이름, 범위를 벗어난 값, 모르는 구간 이름, 빠진 게인을 한 줄로 남긴다."""
        ignored, clamped, bad_tags = [], [], [t for t in self.schedule if t not in TAGS]
        for where, g in [("base", self.base)] + [(t, self.schedule.get(t) or {}) for t in TAGS]:
            for k, v in g.items():
                if k not in ALLOWED:
                    ignored.append("%s.%s" % (where, k))
                    continue
                try:
                    x = float(v)
                except (TypeError, ValueError):
                    ignored.append("%s.%s" % (where, k))
                    continue
                lo, hi = ALLOWED[k]
                if x < lo or x > hi:
                    clamped.append("%s.%s=%g->%g" % (where, k, x, min(max(x, lo), hi)))
        missing = [k for k in ALLOWED if k not in self.base]
        rospy.loginfo("GAINS_CHECK %s" % json.dumps({"ignored": ignored, "clamped": clamped, "unknown_tags": bad_tags, "missing": missing},
                                                    ensure_ascii=False))

    # ---------- 목표점 ----------
    def publish_target(self):
        if self.target is None:
            return
        m = PoseStamped()
        m.header.stamp = rospy.Time.now()
        m.header.frame_id = "map"
        m.pose.position.x, m.pose.position.y = self.target[0], self.target[1]
        m.pose.position.z = self.target[2] + self.zb            # 목표 높이는 월드 기준, PX4 로는 추정 기준으로 보냄
        q = yaw_to_quat(self.target_yaw)
        m.pose.orientation.x, m.pose.orientation.y, m.pose.orientation.z, m.pose.orientation.w = q
        self.sp_pub.publish(m)

    def spin(self, seconds):
        end = rospy.get_time() + seconds
        while not rospy.is_shutdown() and rospy.get_time() < end:
            self.publish_target()
            self.rate.sleep()

    def go(self, x, y, z, face=True):
        self.target = (x, y, z)
        if face and self.pos is not None:
            dx, dy = x - self.pos[0], y - self.pos[1]
            if math.hypot(dx, dy) > 0.8:
                self.target_yaw = math.atan2(dy, dx)

    def dist_xy(self, x, y):
        return math.hypot(self.pos[0] - x, self.pos[1] - y)

    # ---------- 준비와 시동 ----------
    def prepare(self):
        while not rospy.is_shutdown() and not (self.state.connected and self.pos is not None):
            self.rate.sleep()
        t0 = rospy.get_time()                         # MAVROS 가 PX4 파라미터 목록을 받을 때까지 대기
        while not rospy.is_shutdown() and rospy.get_time() - t0 < 60.0:
            try:
                if self.srv_get(param_id="MPC_XY_P").success:
                    break
            except rospy.ServiceException:
                pass
            self.rate.sleep()
        self.check_gains()
        for k, v in sorted(self.course.get("limits", {}).items()):
            self.set_param(k, v)
        for k, v in sorted(self.px4_params.items()):
            self.set_param(k, v)
        t0 = rospy.get_time()
        while not rospy.is_shutdown() and self.truth_z is None and rospy.get_time() - t0 < 10.0:
            self.rate.sleep()
        self.ground_z = self.truth_z
        first_tag = self.course["sequence"][0].get("tag", "cruise")
        self.apply_tag(first_tag)
        self.target = (self.pos[0], self.pos[1], self.alt())
        self.target_yaw = self.yaw
        self.spin(2.0)

    def arm_offboard(self):
        for attempt in range(40):
            if self.state.mode != "OFFBOARD":
                try:
                    self.srv_mode(base_mode=0, custom_mode="OFFBOARD")
                except rospy.ServiceException:
                    pass
            elif not self.state.armed:
                try:
                    r = self.srv_arm(value=True)
                    if not r.success and attempt == 10:      # 조종기 없는 시뮬레이션에서 거부될 때의 대비
                        self.set_param("COM_RCL_EXCEPT", 4, integer=True)
                except rospy.ServiceException:
                    pass
            else:
                return True
            self.spin(0.5)
        return False

    def land_and_stop(self):
        """PX4 자동 착륙으로 내려가 땅에 닿으면 시동을 끈다 (접지 뒤 기체가 튀는 것을 막음)."""
        for _ in range(10):
            try:
                self.srv_mode(base_mode=0, custom_mode="AUTO.LAND")
            except rospy.ServiceException:
                pass
            self.spin(0.3)
            if self.state.mode == "AUTO.LAND":
                break
        t1 = rospy.get_time()
        while not rospy.is_shutdown() and self.state.armed and rospy.get_time() - t1 < 40.0:
            if self.ground_z is not None and self.truth_z is not None and self.truth_z <= self.ground_z + 0.05:
                try:                                  # 강제 시동 끄기 (MAV_CMD_COMPONENT_ARM_DISARM, 21196)
                    self.srv_cmd(broadcast=False, command=400, confirmation=0, param1=0.0, param2=21196.0,
                                 param3=0.0, param4=0.0, param5=0.0, param6=0.0, param7=0.0)
                except rospy.ServiceException:
                    pass
                rospy.sleep(0.2)
            self.rate.sleep()

    # ---------- 코스 요소 ----------
    def do_gate(self, g):
        cx, cy = self.local(float(g["x"]), float(g["y"]))
        cz = float(g["z"])
        yaw = math.radians(float(g.get("yaw_deg", 0.0)))
        nx, ny = math.cos(yaw), math.sin(yaw)
        ex, ey = cx + GATE_EXIT_DIST * nx, cy + GATE_EXIT_DIST * ny
        t0 = rospy.get_time()
        through = False
        s_prev = None
        while not rospy.is_shutdown():
            s = (self.pos[0] - cx) * nx + (self.pos[1] - cy) * ny
            d = self.dist_xy(cx, cy)
            if not through and d < GATE_SWITCH_DIST:
                through = True
            if through:
                self.go(ex, ey, cz)
            else:
                self.go(cx, cy, cz)
            if d < 4.0 and s >= 0.0 and (s_prev is None or s_prev < 0.0 or through):
                if s_prev is not None:
                    return True
            s_prev = s
            if rospy.get_time() - t0 > ITEM_TIMEOUT_S:
                return False
            self.publish_target()
            self.rate.sleep()
        return False

    def do_hold(self, hd):
        hx, hy = self.local(float(hd["x"]), float(hd["y"]))
        hz = float(hd["z"])
        r = float(hd["radius"])
        need = float(hd["seconds"])
        t0 = rospy.get_time()
        t_in = None
        while not rospy.is_shutdown():
            self.go(hx, hy, hz)
            d = math.sqrt((self.pos[0] - hx) ** 2 + (self.pos[1] - hy) ** 2 + (self.alt() - hz) ** 2)
            now = rospy.get_time()
            if d <= r:
                t_in = now if t_in is None else t_in
                if now - t_in >= need:
                    return True
            else:
                t_in = None
            if now - t0 > HOLD_TIMEOUT_S:
                return False
            self.publish_target()
            self.rate.sleep()
        return False

    def do_land(self, item):
        ld = self.course.get("landing")
        if not ld:                                    # 표식이 없는 코스(조절용 코스): 그 자리에 내려앉음
            self.say("LAND", item["id"], "final")
            self.land_and_stop()
            return
        sx, sy = self.local(float(ld["search"]["x"]), float(ld["search"]["y"]))
        sz = float(ld["search"]["z"])
        z_final = float(ld.get("pad_top_z", 0.0)) + FINAL_HEIGHT
        self.image_sub = rospy.Subscriber("/iris/usb_cam/image_raw/compressed", CompressedImage, self.on_image,
                                          queue_size=1, buff_size=2 ** 22)
        t0 = rospy.get_time()
        sub = "search"
        self.say("LAND", item["id"], sub)
        z_cmd = sz
        t_ok = None
        # 착륙 구간의 기수 방향은 코스가 정한다 (표식 무늬가 화면과 나란해 탐색 지점과 하강 끝에서 화면 안에 다 들어옴).
        # 코스에 값이 없으면 지금 방향에서 가장 가까운 90도 방향을 쓴다.
        if ld.get("yaw_deg") is not None:
            hold_yaw = math.radians(float(ld["yaw_deg"]))
        else:
            hold_yaw = round(self.yaw / (math.pi / 2.0)) * (math.pi / 2.0)
        while not rospy.is_shutdown():
            now = rospy.get_time()
            fresh = self.vis["stamp"] is not None and now - self.vis["stamp"] < 0.5
            if sub == "search":
                self.go(sx, sy, sz, face=False)
                self.target_yaw = hold_yaw
                if self.dist_xy(sx, sy) < 0.6 and abs(self.alt() - sz) < 0.4 and fresh and self.vis["count"] >= 5:
                    sub = "align"
                    self.say("LAND", item["id"], sub)
                elif now - t0 > 25.0:
                    self.say("LAND", item["id"], "no_marker")
                    break
            else:
                self.target_yaw = hold_yaw
                if self.vis["est"] is not None:
                    self.target = (self.vis["est"][0], self.vis["est"][1], z_cmd)
                err = math.hypot(*self.vis["offset"]) if (fresh and self.vis["offset"]) else None
                ok = err is not None and err < ALIGN_TOL_M
                if ok:
                    t_ok = now if t_ok is None else t_ok
                else:
                    t_ok = None
                if sub == "align" and t_ok is not None and now - t_ok >= ALIGN_HOLD_S:
                    sub = "descend"
                    t_ok = None
                    self.say("LAND", item["id"], sub)
                elif sub == "descend":
                    if fresh:
                        z_cmd = max(z_final, z_cmd - DESCEND_RATE / RATE_HZ)
                    if self.alt() <= z_final + 0.15 and t_ok is not None and now - t_ok >= 0.5:
                        break
                if now - t0 > 70.0:
                    self.say("LAND", item["id"], "land_timeout")
                    break
            self.publish_target()
            self.rate.sleep()
        self.say("LAND", item["id"], "final", {"vision_err": None if not self.vis["offset"] else round(math.hypot(*self.vis["offset"]), 3)})
        self.land_and_stop()

    # ---------- 전체 순서 ----------
    def run(self):
        self.prepare()
        if not self.arm_offboard():
            self.say("ABORT", sub="arming_failed")
            return 1
        timeout = float(self.course.get("timeout_s", 180.0))
        alt = float(self.course["takeoff_alt"])
        x0, y0 = self.pos[0], self.pos[1]
        t_cmd = rospy.get_time()                      # 이륙 명령을 내기 시작한 시각
        t_start = None                                # 기체가 땅에서 뜬 순간 (참값 높이 기준)
        while not rospy.is_shutdown():
            self.go(x0, y0, alt, face=False)
            self.publish_target()
            self.rate.sleep()
            if (t_start is None and self.truth_z is not None and self.ground_z is not None
                    and self.truth_z - self.ground_z >= LIFTOFF_DZ):
                t_start = rospy.get_time()
                self.say("TAKEOFF")
            if t_start is not None and abs(self.alt() - alt) <= 0.3:
                break
            if rospy.get_time() - t_cmd > LIFTOFF_WAIT_S:
                break
        if t_start is None:                           # 뜨지 못함
            self.say("ABORT", sub="no_liftoff")
            return 1
        for item in self.course["sequence"]:
            if rospy.get_time() - t_start > timeout:
                self.say("TIMEOUT")
                break
            self.apply_tag(item.get("tag", "cruise"))
            if item["type"] == "gate":
                self.say("GATE", item["id"])
                ok = self.do_gate(item)
                self.say("GATE_DONE", item["id"], "passed" if ok else "skipped")
            elif item["type"] == "hold":
                self.say("HOLD", item["id"])
                ok = self.do_hold(item)
                self.say("HOLD_DONE", item["id"], "ok" if ok else "fail")
            elif item["type"] == "land":
                self.do_land(item)
        if self.state.armed:
            self.land_and_stop()
        self.say("DONE", extra={"elapsed": round(rospy.get_time() - t_start, 2)})
        rospy.sleep(1.0)
        return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--course", required=True)
    ap.add_argument("--gains", required=True)
    ap.add_argument("--px4-params", required=True)
    a = ap.parse_args(rospy.myargv()[1:])
    with open(a.course, encoding="utf-8") as f:
        course = yaml.safe_load(f)
    with open(a.gains, encoding="utf-8") as f:
        gains = yaml.safe_load(f) or {}
    with open(a.px4_params, encoding="utf-8") as f:
        px4_params = yaml.safe_load(f) or {}
    rospy.init_node("race_runner")
    return Runner(course, gains, px4_params).run()


if __name__ == "__main__":
    sys.exit(main())
