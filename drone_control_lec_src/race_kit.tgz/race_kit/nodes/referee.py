#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""심판 노드 (고치지 않는 파일). Gazebo 참값만으로 채점한다. 시간은 모두 시뮬레이션 시간이다.

실행 노드가 보내는 신호는 쓰지 않는다. 실행 노드를 고치거나 바꿔도 판정이 같도록 아래를 모두 참값으로 정한다.
- 기록 시작  : 기체가 출발 높이에서 LIFTOFF_DZ 만큼 뜬 순간
- 요소 순서  : 코스의 sequence 순서. 차례가 된 요소를 제한 시간 안에 지나지 못하면 놓침·실패로 처리하고 다음 요소로 넘어감
- 게이트     : 게이트 면을 뒤에서 앞으로 지난 지점이 열린 면 안이면 통과
- 제자리 유지: 중심에서 (반경 + HOLD_MARGIN_M) 안에 (유지 시간 x HOLD_FRACTION) 이상 연속으로 머무르면 성공
- 완주       : 남은 요소가 없을 때 땅에 닿은 순간 (닿은 자리로 착륙 오차 계산)
- 한도       : 코스의 limits 값을 참값 속도·기울기와 대조. 넘긴 채 LIMIT_HOLD_S 넘게 이어지면 완주 실패
- 파라미터   : 비행 중 PX4 의 게인 20개와 한도 값을 차례로 읽어 허용 범위와 대조. 벗어나 있으면 완주 실패

점수 = 완주 시간 + 벌점. 전복·시간 초과·배터리 소진·한도 위반·허용 범위 밖 게인·코스 중간 접지는 완주 실패.
결과: <out>/result.json, traj.csv, plot.png.  진행 기록은 EVENT 줄로 바로 내보낸다 (race.sh 가 터미널에 보여 줌).
"""
import argparse
import collections
import csv
import json
import math
import os
import sys

import rospy
import yaml
from gazebo_msgs.msg import LinkStates, ModelStates
from mavros_msgs.srv import ParamGet

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "tools"))
import check_inputs  # noqa: E402  (키트의 게인 표를 읽는 데 씀)

RATE_HZ = 50.0
MARKER_BOARD_HALF = 0.7
SLOWDOWN = 10.0             # iris 모델의 rotorVelocitySlowdownSim
LIFTOFF_DZ = 0.10           # 출발 높이에서 이만큼 뜨면 기록 시작 (m)
TILT_CRASH_DEG = 70.0
TOUCH_Z = 0.05              # 출발 때 높이보다 이만큼 안으로 내려오면 접지 (m)
TOUCH_SPEED_MAX = 2.5       # 접지 순간 속도가 이보다 크면 충돌로 봄 (m/s)
GATE_TIMEOUT_S = 30.0       # 게이트가 차례가 된 뒤 이 시간 안에 지나지 못하면 놓침
HOLD_TIMEOUT_S = 25.0       # 제자리 유지가 차례가 된 뒤 이 시간 안에 못 하면 실패
HOLD_MARGIN_M = 0.15        # 유지 반경에 더하는 여유 (m)
HOLD_FRACTION = 0.8         # 유지 시간에 곱하는 비율
GATE_NEAR_M = 6.0           # 게이트 면을 지난 지점이 중심에서 이 거리 안일 때만 그 게이트를 지난 것으로 봄
PAD_NEAR_M = 2.0            # 남은 요소가 있어도 표식 중심에서 이 거리 안에 내려앉으면 착륙으로 봄 (남은 요소는 놓침·실패)
NO_LIFTOFF_S = 90.0         # 심판이 켜진 뒤 이 시간 안에 뜨지 않으면 완주 실패
RUNNER_GONE_S = 20.0        # 실행 노드가 비행 중에 끝난 뒤 이 시간 안에 땅에 닿지 않으면 완주 실패
LIMIT_SPEED_FACTOR = 1.25   # 수평 속도 한도(MPC_XY_VEL_MAX)에 곱하는 여유
LIMIT_UP_FACTOR = 1.5       # 상승 속도 한도(MPC_Z_VEL_MAX_UP)에 곱하는 여유
LIMIT_TILT_EXTRA_DEG = 15.0  # 기울기 한도(MPC_TILTMAX_AIR)에 더하는 여유 (도)
LIMIT_HOLD_S = 1.0          # 한도를 넘긴 채 이 시간 넘게 이어지면 위반
SPEED_WINDOW_S = 0.5        # 한도와 대조할 속도는 이 시간 동안 실제로 옮겨 간 거리로 구함
JUMP_M = 1.0                # 한 번의 측정 간격에 (이 거리 + JUMP_SPEED x 간격) 보다 많이 움직이면 비정상 이동
JUMP_SPEED = 15.0           # 위 판정에 쓰는 속도 (m/s)
AUDIT_PERIOD_S = 0.2        # 이 간격으로 PX4 파라미터를 하나씩 읽어 허용 범위와 대조


def quat_tilt_deg(q):
    """기체 z 축이 연직에서 기운 각."""
    zz = 1.0 - 2.0 * (q.x * q.x + q.y * q.y)
    return math.degrees(math.acos(max(-1.0, min(1.0, zz))))


def point_seg_dist(p, a, b):
    ax, ay, bx, by = a[0], a[1], b[0], b[1]
    dx, dy = bx - ax, by - ay
    l2 = dx * dx + dy * dy
    if l2 < 1e-9:
        return math.hypot(p[0] - ax, p[1] - ay)
    t = max(0.0, min(1.0, ((p[0] - ax) * dx + (p[1] - ay) * dy) / l2))
    return math.hypot(p[0] - (ax + t * dx), p[1] - (ay + t * dy))


class Referee(object):
    def __init__(self, course, vehicle, out_dir, label, runner_flag):
        self.course = course
        self.v = vehicle
        self.out = out_dir
        self.label = label
        self.runner_flag = runner_flag
        self.pen = course.get("penalties", {}) or {}
        self.seq = course["sequence"]
        self.gates = [i for i in self.seq if i["type"] == "gate"]
        self.holds = [i for i in self.seq if i["type"] == "hold"]
        self.landing = course.get("landing")
        self.limits = course.get("limits", {}) or {}
        self.model = None
        self.links = None
        self.t_start = None
        self.t_end = None
        self.status = "RUNNING"
        self.reason = ""
        self.idx = 0                                  # 지금 차례인 요소의 번호
        self.t_cur = None                             # 그 요소가 차례가 된 시각
        self.gate_res = {}
        self.gate_watch = None                        # 지금 면을 지켜보는 게이트의 번호
        self.s_prev = None
        self.p_prev = None
        self.corr = {z["id"]: 0.0 for z in course.get("wind_zones", []) or []}
        self.hold_res = {}
        self.hold_in = None
        self.hold_best = {}
        self.energy_wh = 0.0
        self.max_speed = 0.0
        self.max_tilt = 0.0
        self.traj = []
        self.p_touch = None
        self.ground_z = None
        self.was_air = False
        self.over = {"speed": None, "up": None, "tilt": None}     # 한도를 넘기 시작한 시각
        self.t_runner_gone = None
        self.steps = []                               # 조절용 코스의 계단 응답 (요소마다)
        self.step_cur = None
        self.events = []                              # 심판이 참값으로 적은 진행 기록 (시각은 시뮬레이션 시간)
        self.hist = collections.deque()               # 최근 SPEED_WINDOW_S 동안의 (시각, 위치)
        self.t_prev = None
        # 파라미터 점검 목록: (이름, 최소, 최대). 한도 값은 코스의 값보다 크면 위반
        self.audit = [(k, lo, hi) for k, (lo, hi) in check_inputs.allowed_table().items()]
        self.audit += [(k, None, float(v)) for k, v in sorted(self.limits.items())]
        self.audit_i = 0
        self.param_violation = None
        self.srv_get = rospy.ServiceProxy("/mavros/param/get", ParamGet)
        rospy.Timer(rospy.Duration(AUDIT_PERIOD_S), self.audit_tick)
        rospy.Subscriber("/gazebo/model_states", ModelStates, self.on_model, queue_size=1)
        rospy.Subscriber("/gazebo/link_states", LinkStates, self.on_links, queue_size=1)

    def on_model(self, msg):
        self.model = msg

    def on_links(self, msg):
        self.links = msg

    # ---------- 요소 순서 ----------
    def cur(self):
        return self.seq[self.idx] if self.idx < len(self.seq) else None

    def note(self, t, phase, item="", sub=""):
        e = {"t": round(t, 3), "phase": phase, "item": item, "sub": sub}
        self.events.append(e)
        print("EVENT %s" % json.dumps(e, ensure_ascii=False))
        sys.stdout.flush()

    def audit_tick(self, _event):
        """비행 중 PX4 파라미터를 하나씩 읽어 허용 범위와 대조한다 (실행 노드를 바꿔도 같은 범위가 적용되게)."""
        if self.t_start is None or self.status != "RUNNING" or self.param_violation or not self.audit:
            return
        k, lo, hi = self.audit[self.audit_i % len(self.audit)]
        self.audit_i += 1
        try:
            r = self.srv_get(param_id=k)
        except (rospy.ServiceException, rospy.ROSException):
            return
        if not r.success:
            return
        x = float(r.value.integer) if (r.value.real == 0.0 and r.value.integer != 0) else float(r.value.real)
        tol = 1e-3 * max(1.0, abs(hi))
        if lo is None:
            if x > hi + tol:
                self.param_violation = "한도 값 변경: %s = %g (코스의 값 %g)" % (k, x, hi)
        elif x < lo - tol or x > hi + tol:
            self.param_violation = "허용 범위 밖 게인: %s = %g (허용 %g - %g)" % (k, x, lo, hi)

    def advance(self, t, new_idx, p):
        """다음 요소로 넘어간다. 조절용 코스에서는 새 요소의 계단 응답 기록을 시작한다."""
        self.step_close(t)
        self.idx = new_idx
        self.t_cur = t
        self.hold_in = None
        item = self.cur()
        if item is not None and item["type"] == "hold":
            self.note(t, "HOLD", item["id"])
        elif item is not None and item["type"] == "land":
            self.note(t, "LAND", item["id"], "search")
        if self.course.get("step_metrics") and item is not None and item["type"] == "hold":
            self.step_cur = {"id": item["id"], "t0": t, "p0": p, "target": (item["x"], item["y"], item["z"]), "samples": []}

    def mark_gate(self, g, passed, lat, vert, how):
        if g["id"] in self.gate_res:
            return
        self.gate_res[g["id"]] = {"passed": bool(passed), "lateral_m": None if lat is None else round(lat, 3),
                                  "vertical_m": None if vert is None else round(vert, 3), "how": how}
        self.note(rospy.get_time(), "GATE_DONE", g["id"], "passed" if passed else ("missed" if how == "crossed" else how))

    def skip_before(self, k):
        """k 번째 요소 앞에 남아 있는 요소를 놓침·실패로 처리한다."""
        for j in range(self.idx, k):
            it = self.seq[j]
            if it["type"] == "gate":
                self.mark_gate(it, False, None, None, "skipped")
            elif it["type"] == "hold" and it["id"] not in self.hold_res:
                self.hold_res[it["id"]] = False
                self.note(rospy.get_time(), "HOLD_DONE", it["id"], "skipped")

    def check_sequence(self, p, t):
        item = self.cur()
        if item is None:
            return
        # 1) 지금 차례부터 처음 나오는 게이트의 면을 지났는지 본다 (그 앞의 제자리 유지를 건너뛴 경우도 여기서 잡힌다)
        gi = next((k for k in range(self.idx, len(self.seq)) if self.seq[k]["type"] == "gate"), None)
        if gi != self.gate_watch:
            self.gate_watch, self.s_prev = gi, None
        if gi is not None:
            g = self.seq[gi]
            yaw = math.radians(float(g.get("yaw_deg", 0.0)))
            nx, ny = math.cos(yaw), math.sin(yaw)
            s = (p[0] - g["x"]) * nx + (p[1] - g["y"]) * ny
            if self.s_prev is not None and self.s_prev < 0.0 <= s and self.p_prev is not None:
                k = -self.s_prev / (s - self.s_prev) if s != self.s_prev else 0.0
                cx = self.p_prev[0] + k * (p[0] - self.p_prev[0])
                cy = self.p_prev[1] + k * (p[1] - self.p_prev[1])
                cz = self.p_prev[2] + k * (p[2] - self.p_prev[2])
                lat = -(cx - g["x"]) * ny + (cy - g["y"]) * nx
                vert = cz - g["z"]
                if abs(lat) < GATE_NEAR_M:
                    ok = abs(lat) <= g["w"] / 2.0 and abs(vert) <= g["h"] / 2.0
                    self.skip_before(gi)
                    self.mark_gate(g, ok, lat, vert, "crossed")
                    self.advance(t, gi + 1, p)
                    return
            self.s_prev = s
        # 2) 지금 차례인 요소의 판정과 제한 시간
        if item["type"] == "hold":
            d = math.sqrt((p[0] - item["x"]) ** 2 + (p[1] - item["y"]) ** 2 + (p[2] - item["z"]) ** 2)
            if d <= float(item["radius"]) + HOLD_MARGIN_M:
                self.hold_in = t if self.hold_in is None else self.hold_in
                self.hold_best[item["id"]] = max(self.hold_best.get(item["id"], 0.0), t - self.hold_in)
                if t - self.hold_in >= HOLD_FRACTION * float(item["seconds"]):
                    self.hold_res[item["id"]] = True
                    self.note(t, "HOLD_DONE", item["id"], "ok")
                    self.advance(t, self.idx + 1, p)
                    return
            else:
                self.hold_in = None
            if t - self.t_cur > HOLD_TIMEOUT_S:
                self.hold_res[item["id"]] = False
                self.note(t, "HOLD_DONE", item["id"], "fail")
                self.advance(t, self.idx + 1, p)
        elif item["type"] == "gate":
            if t - self.t_cur > GATE_TIMEOUT_S:
                self.mark_gate(item, False, None, None, "timeout")
                self.advance(t, self.idx + 1, p)

    # ---------- 계단 응답 (조절용 코스) ----------
    def step_sample(self, p, t):
        s = self.step_cur
        if s is None:
            return
        s["samples"].append((t - s["t0"], p[0], p[1], p[2]))

    def step_close(self, t):
        s, self.step_cur = self.step_cur, None
        if s is None or len(s["samples"]) < 5:
            return
        d = [s["target"][k] - s["p0"][k] for k in range(3)]
        dist = math.sqrt(sum(x * x for x in d))
        if dist < 0.3:                                # 제자리에서 버티는 요소: 흔들린 크기만 기록
            dev = max(math.sqrt(sum((q[k + 1] - s["target"][k]) ** 2 for k in range(3))) for q in s["samples"])
            self.steps.append({"id": s["id"], "kind": "stay", "max_dev_m": round(dev, 3), "seconds": round(s["samples"][-1][0], 2)})
            return
        u = [x / dist for x in d]
        prog = [(q[0], sum((q[k + 1] - s["p0"][k]) * u[k] for k in range(3)) / dist) for q in s["samples"]]
        t10 = next((tt for tt, e in prog if e >= 0.1), None)
        t90 = next((tt for tt, e in prog if e >= 0.9), None)
        peak = max(e for _, e in prog)
        settle = 0.0
        for tt, e in prog:
            if abs(e - 1.0) > 0.05:
                settle = tt
        reached = t90 is not None
        self.steps.append({
            "id": s["id"], "kind": "step", "dist_m": round(dist, 2),
            "axis": "수직" if abs(u[2]) > 0.7 else "수평" if abs(u[2]) < 0.3 else "대각",
            "rise_s": None if (t10 is None or t90 is None) else round(t90 - t10, 2),
            "overshoot_pct": round(max(0.0, peak - 1.0) * 100.0, 1) if reached else None,
            # 정착 시간 = 움직이기 시작한 때(10 %)부터 목표의 5 % 안에 들어와 머문 때까지
            "settle_s": round(max(settle - t10, 0.0), 2) if (reached and abs(prog[-1][1] - 1.0) <= 0.05) else None,
            "final_err_m": round(abs(prog[-1][1] - 1.0) * dist, 3), "seconds": round(prog[-1][0], 2)})

    # ---------- 그 밖의 판정 ----------
    def check_corridor(self, p):
        """바람 구역 안에서, from 게이트를 지난 뒤 to 게이트를 지나기 전까지 기준 경로에서 벗어난 최대 거리.
        기준 경로 = from 부터 to 까지의 게이트와 제자리 유지 지점을 순서대로 이은 꺾은선."""
        pts_all = [i for i in self.seq if i["type"] in ("gate", "hold")]
        ids = [i["id"] for i in pts_all]
        for z in self.course.get("wind_zones", []) or []:
            if "from" not in z or "to" not in z:
                continue
            i0, i1 = ids.index(z["from"]), ids.index(z["to"])
            if not (z["from"] in self.gate_res and z["to"] not in self.gate_res):
                continue
            if not (z["xmin"] <= p[0] <= z["xmax"] and z["ymin"] <= p[1] <= z["ymax"]):
                continue
            pts = [(pts_all[i]["x"], pts_all[i]["y"]) for i in range(i0, i1 + 1)]
            d = min(point_seg_dist(p, pts[i], pts[i + 1]) for i in range(len(pts) - 1))
            self.corr[z["id"]] = max(self.corr[z["id"]], d)

    def check_limits(self, t, vh, vz, tilt):
        """코스의 한도 값을 넘긴 채 LIMIT_HOLD_S 넘게 이어지면 위반 사유를 돌려준다."""
        tests = []
        if self.limits.get("MPC_XY_VEL_MAX") is not None:
            lim = float(self.limits["MPC_XY_VEL_MAX"])
            tests.append(("speed", vh > LIMIT_SPEED_FACTOR * lim, "수평 속도 %.1f m/s (한도 %.1f m/s)" % (vh, lim)))
        if self.limits.get("MPC_Z_VEL_MAX_UP") is not None:
            lim = float(self.limits["MPC_Z_VEL_MAX_UP"])
            tests.append(("up", vz > LIMIT_UP_FACTOR * lim, "상승 속도 %.1f m/s (한도 %.1f m/s)" % (vz, lim)))
        if self.limits.get("MPC_TILTMAX_AIR") is not None:
            lim = float(self.limits["MPC_TILTMAX_AIR"])
            tests.append(("tilt", tilt > lim + LIMIT_TILT_EXTRA_DEG, "기울기 %.0f도 (한도 %.0f도)" % (tilt, lim)))
        for key, over, text in tests:
            if not over:
                self.over[key] = None
            elif self.over[key] is None:
                self.over[key] = t
            elif t - self.over[key] > LIMIT_HOLD_S:
                return "한도 위반: " + text
        return None

    def power_w(self):
        if self.links is None:
            return self.v["avionics_power_w"]
        v = self.v
        i_sum = 0.0
        p_sum = 0.0
        for name, tw in zip(self.links.name, self.links.twist):
            if not name.startswith("iris::rotor_"):
                continue
            w_g = abs(tw.angular.z) * SLOWDOWN
            thrust = v["motor_const"] * w_g * w_g
            w = math.sqrt(thrust / (v["eta_inst"] * v["kt_prop"]))
            i_m = v["cq"] * w * w / v["kt_m"] + (v["i0"] if w > 1.0 else 0.0)
            p_sum += (w / v["kvr"] + v["r_m"] * i_m) * i_m
            i_sum += i_m
        i_tot = i_sum + v["i_av"]
        return p_sum / v["esc_efficiency"] + v["avionics_power_w"] + i_tot * i_tot * v["r_pack"]

    def marker_center(self):
        if not self.landing:
            return None
        try:
            i = self.model.name.index("pad_marker")
        except (ValueError, AttributeError):
            m = self.landing["marker"]
            return (m["x"], m["y"])
        p = self.model.pose[i].position
        return (p.x - MARKER_BOARD_HALF, p.y)

    def runner_gone(self):
        return bool(self.runner_flag) and os.path.exists(self.runner_flag)

    # ---------- main ----------
    def run(self):
        rate = rospy.Rate(RATE_HZ)
        timeout = float(self.course.get("timeout_s", 180.0))
        t_ref = None
        n = 0
        while not rospy.is_shutdown() and self.status == "RUNNING":
            rate.sleep()
            if self.model is None:
                continue
            try:
                i = self.model.name.index("iris")
            except ValueError:
                continue
            t = rospy.get_time()
            pose, tw = self.model.pose[i], self.model.twist[i]
            p = (pose.position.x, pose.position.y, pose.position.z)
            if self.ground_z is None:
                self.ground_z = p[2]                 # 출발 전 땅 위 높이 (기체가 서 있을 때의 값)
                t_ref = t
            if self.t_start is None:
                if p[2] - self.ground_z >= LIFTOFF_DZ:
                    self.t_start = t
                    self.note(t, "TAKEOFF")
                    self.advance(t, 0, p)
                    self.p_prev = p
                    self.t_prev = t
                elif self.runner_gone() or t - t_ref > NO_LIFTOFF_S:
                    self.status, self.reason = "DNF", "이륙하지 못함"
                continue
            dt = min(max(t - self.t_prev, 0.0), 0.2)   # 앞 측정부터 지난 시간 (시뮬레이션 시간)
            self.t_prev = t
            vh = math.hypot(tw.linear.x, tw.linear.y)
            speed = math.sqrt(vh * vh + tw.linear.z ** 2)
            tilt = quat_tilt_deg(pose.orientation)
            # 한도와 대조할 속도는 실제로 옮겨 간 거리로 구한다 (Gazebo 가 알려 주는 속도 값에 기대지 않음)
            self.hist.append((t, p))
            while t - self.hist[0][0] > SPEED_WINDOW_S:
                self.hist.popleft()
            t_old, p_old = self.hist[0]
            if t - t_old >= 0.5 * SPEED_WINDOW_S:
                vh_lim = math.hypot(p[0] - p_old[0], p[1] - p_old[1]) / (t - t_old)
                vz_lim = (p[2] - p_old[2]) / (t - t_old)
            else:
                vh_lim, vz_lim = vh, tw.linear.z
            self.max_speed = max(self.max_speed, speed)
            self.max_tilt = max(self.max_tilt, tilt)
            if p[2] > self.ground_z + 0.5:
                self.was_air = True
            self.energy_wh += self.power_w() * dt / 3600.0
            jump = math.sqrt(sum((p[k] - self.p_prev[k]) ** 2 for k in range(3)))
            self.check_sequence(p, t)
            self.check_corridor(p)
            self.step_sample(p, t)
            self.p_prev = p
            n += 1
            item = self.cur()
            tag = item.get("tag", "") if item is not None else ""
            if n % 5 == 0:
                self.traj.append((round(t - self.t_start, 3), round(p[0], 3), round(p[1], 3), round(p[2], 3),
                                  round(speed, 3), round(tilt, 2), tag,
                                  "" if item is None else item["type"].upper(), "" if item is None else item["id"]))
            lim = self.check_limits(t, vh_lim, vz_lim, tilt)
            if self.t_runner_gone is None and self.runner_gone():
                self.t_runner_gone = t
            if tilt > TILT_CRASH_DEG:
                self.status, self.reason = "DNF", "전복 (기울기 %.0f도)" % tilt
            elif jump > JUMP_M + JUMP_SPEED * dt:
                self.status, self.reason = "DNF", "비정상 이동 (%.1f m 순간 이동)" % jump
            elif lim:
                self.status, self.reason = "DNF", lim
            elif self.param_violation:
                self.status, self.reason = "DNF", self.param_violation
            elif t - self.t_start > timeout:
                self.status, self.reason = "DNF", "시간 초과 (%.0f초)" % timeout
            elif self.energy_wh > self.v["usable_wh"]:
                self.status, self.reason = "DNF", "배터리 소진"
            elif self.was_air and p[2] <= self.ground_z + TOUCH_Z:
                # 처음 땅에 닿은 순간이 기록 시각이고 그 자리가 착륙 지점이다 (그 뒤의 튐은 보지 않음)
                self.p_touch = p
                self.t_end = t
                left = [k for k in range(self.idx, len(self.seq)) if self.seq[k]["type"] != "land"]
                mc = self.marker_center()
                near_pad = mc is not None and math.hypot(p[0] - mc[0], p[1] - mc[1]) <= PAD_NEAR_M
                if left and not near_pad:
                    self.status = "DNF"
                    self.reason = "코스 중간에 지면에 닿음" if self.t_runner_gone is None else "실행 노드가 비행 중에 끝난 뒤 지면에 닿음"
                elif speed > TOUCH_SPEED_MAX:
                    self.status, self.reason = "DNF", "충돌 착지 (속도 %.1f m/s)" % speed
                else:
                    self.skip_before(len(self.seq))
                    self.status = "FINISHED"
                    self.note(t, "DONE")
            elif self.t_runner_gone is not None and t - self.t_runner_gone > RUNNER_GONE_S:
                self.status, self.reason = "DNF", "실행 노드가 비행 중에 끝남"
        self.step_close(rospy.get_time())
        if self.status == "DNF":
            self.note(rospy.get_time(), "DNF", sub=self.reason)
        return self.finish()

    def finish(self):
        if self.status == "RUNNING":
            self.status, self.reason = "DNF", "중단"
        pen = []
        for g in self.gates:
            r = self.gate_res.get(g["id"])
            if r is None:
                self.gate_res[g["id"]] = {"passed": False, "lateral_m": None, "vertical_m": None, "how": "not reached"}
                r = self.gate_res[g["id"]]
            if not r["passed"]:
                pen.append({"what": "gate %s miss" % g["id"], "seconds": float(self.pen.get("gate_miss_s", 15.0))})
        for z in self.course.get("wind_zones", []) or []:
            if self.corr.get(z["id"], 0.0) > float(z.get("corridor_half_width", 1e9)):
                pen.append({"what": "wind corridor %s (%.2f m)" % (z["id"], self.corr[z["id"]]), "seconds": float(self.pen.get("corridor_s", 5.0))})
        for hd in self.holds:
            ok = bool(self.hold_res.get(hd["id"], False))
            self.hold_res[hd["id"]] = ok
            if not ok:
                pen.append({"what": "hold %s fail" % hd["id"], "seconds": float(self.pen.get("hold_fail_s", 10.0))})
        land_err = None
        mc = self.marker_center()
        if self.status == "FINISHED" and self.p_touch is not None and mc is not None:
            land_err = math.hypot(self.p_touch[0] - mc[0], self.p_touch[1] - mc[1])
            free = float(self.pen.get("landing_free_m", 0.1))
            if land_err > float(self.pen.get("off_pad_m", 0.7)):
                pen.append({"what": "landing off pad (%.2f m)" % land_err, "seconds": float(self.pen.get("off_pad_s", 15.0))})
            elif land_err > free:
                pen.append({"what": "landing error (%.2f m)" % land_err,
                            "seconds": round((land_err - free) * float(self.pen.get("landing_s_per_m", 20.0)), 2)})
        time_s = None if (self.t_end is None or self.t_start is None) else round(self.t_end - self.t_start, 2)
        pen_total = round(sum(x["seconds"] for x in pen), 2)
        score = None if (self.status != "FINISHED" or time_s is None) else round(time_s + pen_total, 2)
        res = {"label": self.label, "course": self.course["name"], "status": self.status, "reason": self.reason,
               "time_s": time_s, "penalty_s": pen_total, "score": score, "penalties": pen,
               "gates": self.gate_res, "wind_corridor_max_m": {k: round(v, 3) for k, v in self.corr.items()},
               "holds": self.hold_res, "hold_best_s": {k: round(v, 2) for k, v in self.hold_best.items()},
               "landing_error_m": None if land_err is None else round(land_err, 3),
               "energy_used_wh": round(self.energy_wh, 3), "usable_wh": round(self.v["usable_wh"], 2),
               "max_speed_mps": round(self.max_speed, 2), "max_tilt_deg": round(self.max_tilt, 1),
               "design": self.v.get("design"), "mass_kg": round(self.v["mass"], 3),
               "thrust_to_weight": round(self.v["thrust_to_weight"], 2), "steps": self.steps, "events": self.events}
        os.makedirs(self.out, exist_ok=True)
        with open(os.path.join(self.out, "result.json"), "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=1)
        with open(os.path.join(self.out, "traj.csv"), "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["t", "x", "y", "z", "speed", "tilt_deg", "tag", "phase", "item"])
            w.writerows(self.traj)
        try:
            self.plot(res)
        except Exception as e:                       # 그림 실패가 채점을 막지 않게
            rospy.logwarn("plot failed: %s" % e)
        print("RESULT status=%s time=%s penalty=%s score=%s landing_err=%s energy=%.2fWh %s" % (
            res["status"], res["time_s"], res["penalty_s"], res["score"], res["landing_error_m"], self.energy_wh, self.reason))
        for x in pen:
            print("  penalty +%.1fs  %s" % (x["seconds"], x["what"]))
        return 0

    def plot(self, res):
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        from matplotlib.patches import Rectangle
        colors = {"cruise": "tab:blue", "wind": "tab:orange", "precision": "tab:olive", "landing": "tab:green", "": "gray"}
        fig, ax = plt.subplots(1, 2, figsize=(13, 5.2), gridspec_kw={"width_ratios": [1.5, 1.0]})
        a = ax[0]
        for z in self.course.get("wind_zones", []) or []:
            a.add_patch(Rectangle((z["xmin"], z["ymin"]), z["xmax"] - z["xmin"], z["ymax"] - z["ymin"], color="tab:cyan", alpha=0.15))
            a.annotate("", xy=((z["xmin"] + z["xmax"]) / 2 + z["wind"][0] * 0.4, (z["ymin"] + z["ymax"]) / 2 + z["wind"][1] * 0.4),
                       xytext=((z["xmin"] + z["xmax"]) / 2, (z["ymin"] + z["ymax"]) / 2), arrowprops=dict(arrowstyle="->", color="tab:cyan", lw=2))
        for g in self.gates:
            yaw = math.radians(float(g.get("yaw_deg", 0.0)))
            hx, hy = -math.sin(yaw) * g["w"] / 2, math.cos(yaw) * g["w"] / 2
            ok = self.gate_res.get(g["id"], {}).get("passed", False)
            a.plot([g["x"] - hx, g["x"] + hx], [g["y"] - hy, g["y"] + hy], color="k" if ok else "red", lw=3)
            a.text(g["x"], g["y"] + 1.0, g["id"], ha="center", fontsize=9)
        for hd in self.holds:
            a.add_patch(plt.Circle((hd["x"], hd["y"]), hd["radius"] * 2.5, color="gold", alpha=0.6))
            a.text(hd["x"], hd["y"] + 1.0, hd["id"], ha="center", fontsize=9)
        mc = self.marker_center()
        if mc is not None:
            a.add_patch(Rectangle((mc[0] - 0.5, mc[1] - 0.5), 1.0, 1.0, color="k", alpha=0.7))
            a.text(mc[0], mc[1] - 1.6, "pad", ha="center", fontsize=9)
        if self.traj:
            for k in range(1, len(self.traj)):
                p0, p1 = self.traj[k - 1], self.traj[k]
                a.plot([p0[1], p1[1]], [p0[2], p1[2]], color=colors.get(p1[6], "gray"), lw=1.6)
        for tag, c in colors.items():
            if tag:
                a.plot([], [], color=c, lw=2, label=tag)
        a.set_aspect("equal")
        a.set_xlabel("x east (m)")
        a.set_ylabel("y north (m)")
        a.grid(alpha=0.3)
        a.legend(loc="upper center", bbox_to_anchor=(0.5, -0.12), ncol=4, frameon=False)
        a.set_title("%s  |  %s  |  time %s s + penalty %s s = score %s" % (
            res["course"], res["status"], res["time_s"], res["penalty_s"], res["score"]), fontsize=10)
        b = ax[1]
        if self.traj:
            t = [r[0] for r in self.traj]
            b.plot(t, [r[3] for r in self.traj], label="altitude (m)")
            b.plot(t, [r[4] for r in self.traj], label="speed (m/s)")
        b.set_xlabel("simulation time (s)")
        b.grid(alpha=0.3)
        b.legend(loc="upper center", bbox_to_anchor=(0.5, -0.12), ncol=2, frameon=False)
        b.set_title("landing error %s m  |  energy %.1f / %.1f Wh" % (res["landing_error_m"], res["energy_used_wh"], res["usable_wh"]), fontsize=10)
        fig.tight_layout()
        fig.savefig(os.path.join(self.out, "plot.png"), dpi=130)
        plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--course", required=True)
    ap.add_argument("--vehicle", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--label", default="run")
    ap.add_argument("--runner-flag", default="", help="실행 노드가 끝나면 race.sh 가 만드는 파일")
    a = ap.parse_args(rospy.myargv()[1:])
    with open(a.course, encoding="utf-8") as f:
        course = yaml.safe_load(f)
    with open(a.vehicle, encoding="utf-8") as f:
        vehicle = yaml.safe_load(f)
    rospy.init_node("race_referee")
    return Referee(course, vehicle, a.out, a.label, a.runner_flag).run()


if __name__ == "__main__":
    sys.exit(main())
