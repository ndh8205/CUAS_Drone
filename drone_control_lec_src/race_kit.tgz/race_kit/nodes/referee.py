#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""심판 노드 (학생이 고치지 않는 파일). Gazebo 참값으로 채점한다. 시간은 모두 시뮬레이션 시간이다.

점수 = 완주 시간 + 벌점. 전복·시간 초과·배터리 소진·미착륙은 완주 실패(DNF).
결과: <out>/result.json, traj.csv, plot.png
"""
import argparse
import csv
import json
import math
import os
import sys

import rospy
import yaml
from gazebo_msgs.msg import LinkStates, ModelStates
from mavros_msgs.msg import State
from std_msgs.msg import String

RATE_HZ = 50.0
MARKER_BOARD_HALF = 0.7
SLOWDOWN = 10.0             # iris 모델의 rotorVelocitySlowdownSim
TILT_CRASH_DEG = 70.0
TOUCH_Z = 0.05              # 출발 때 높이보다 이만큼 안으로 내려오면 접지 (m)
TOUCH_SPEED_MAX = 2.5       # 접지 순간 속도가 이보다 크면 충돌로 봄 (m/s)


def quat_tilt_deg(q):
    """기체 z 축이 연직에서 기운 각."""
    zz = 1.0 - 2.0 * (q.x * q.x + q.y * q.y)
    return math.degrees(math.acos(max(-1.0, min(1.0, zz))))


def point_seg_dist(p, a, b):
    ax, ay, bx, by = a[0], a[1], b[0], b[1]
    dx, dy = bx - ax, by - ay
    l2 = dx * dx + dy * dy
    if l2 < 1e-9:
        return math.hypot(p[0] - ax, p[1] - ay)
    t = max(0.0, min(1.0, ((p[0] - ax) * dx + (p[1] - ay) * dy) / l2))
    return math.hypot(p[0] - (ax + t * dx), p[1] - (ay + t * dy))


class Referee(object):
    def __init__(self, course, vehicle, out_dir, label):
        self.course = course
        self.v = vehicle
        self.out = out_dir
        self.label = label
        self.pen = course.get("penalties", {})
        self.seq = course["sequence"]
        self.gates = [i for i in self.seq if i["type"] == "gate"]
        self.model = None
        self.links = None
        self.mav = State()
        self.race = {"phase": "", "item": "", "sub": ""}
        self.events = []
        self.t_start = None
        self.t_end = None
        self.status = "RUNNING"
        self.reason = ""
        self.gate_idx = 0
        self.gate_res = {}
        self.s_prev = None
        self.p_prev = None
        self.corr = {z["id"]: 0.0 for z in course.get("wind_zones", []) or []}
        self.hold_res = {}
        self.hold_in = None
        self.hold_best = {}
        self.energy_wh = 0.0
        self.max_speed = 0.0
        self.max_tilt = 0.0
        self.traj = []
        self.t_touch = None
        self.p_touch = None
        self.ground_z = None
        self.was_air = False
        rospy.Subscriber("/gazebo/model_states", ModelStates, self.on_model, queue_size=1)
        rospy.Subscriber("/gazebo/link_states", LinkStates, self.on_links, queue_size=1)
        rospy.Subscriber("/mavros/state", State, self.on_mav, queue_size=5)
        rospy.Subscriber("/race/state", String, self.on_race, queue_size=50)

    def on_model(self, msg):
        self.model = msg

    def on_links(self, msg):
        self.links = msg

    def on_mav(self, msg):
        self.mav = msg

    def on_race(self, msg):
        try:
            d = json.loads(msg.data)
        except ValueError:
            return
        self.race = d
        self.events.append(d)
        if d.get("phase") == "TAKEOFF" and self.t_start is None:
            self.t_start = float(d["t"])             # 기록 시작 = 기체가 땅에서 뜬 순간 (실행 노드가 참값 높이로 알림)
        if d.get("phase") == "ABORT" and self.status == "RUNNING":
            self.status, self.reason = "DNF", "시작 실패(%s)" % d.get("sub", "")
        if d.get("phase") == "HOLD_DONE":
            self.hold_res[d.get("item")] = (d.get("sub") == "ok")
        if d.get("phase") == "GATE_DONE" and d.get("sub") == "skipped":
            self.mark_gate(d.get("item"), False, None, None, "skipped")

    # ---------- checks ----------
    def mark_gate(self, gid, passed, lat, vert, how):
        if gid in self.gate_res:
            return
        self.gate_res[gid] = {"passed": bool(passed), "lateral_m": None if lat is None else round(lat, 3),
                              "vertical_m": None if vert is None else round(vert, 3), "how": how}
        while self.gate_idx < len(self.gates) and self.gates[self.gate_idx]["id"] in self.gate_res:
            self.gate_idx += 1
        self.s_prev = None

    def check_gate(self, p):
        if self.gate_idx >= len(self.gates):
            return
        g = self.gates[self.gate_idx]
        yaw = math.radians(float(g.get("yaw_deg", 0.0)))
        nx, ny = math.cos(yaw), math.sin(yaw)
        s = (p[0] - g["x"]) * nx + (p[1] - g["y"]) * ny
        if self.s_prev is not None and self.s_prev < 0.0 <= s and self.p_prev is not None:
            k = -self.s_prev / (s - self.s_prev) if s != self.s_prev else 0.0
            cx = self.p_prev[0] + k * (p[0] - self.p_prev[0])
            cy = self.p_prev[1] + k * (p[1] - self.p_prev[1])
            cz = self.p_prev[2] + k * (p[2] - self.p_prev[2])
            lat = -(cx - g["x"]) * ny + (cy - g["y"]) * nx
            vert = cz - g["z"]
            if abs(lat) < 6.0:                      # 게이트 근처에서 면을 지난 경우만 판정
                ok = abs(lat) <= g["w"] / 2.0 and abs(vert) <= g["h"] / 2.0
                self.mark_gate(g["id"], ok, lat, vert, "crossed")
                return
        self.s_prev = s

    def check_corridor(self, p):
        """바람 구역 안에서, from 게이트를 지난 뒤 to 게이트를 지나기 전까지 기준 경로에서 벗어난 최대 거리.
        기준 경로 = from 부터 to 까지의 게이트와 제자리 유지 지점을 순서대로 이은 꺾은선."""
        pts_all = [i for i in self.seq if i["type"] in ("gate", "hold")]
        ids = [i["id"] for i in pts_all]
        for z in self.course.get("wind_zones", []) or []:
            if "from" not in z or "to" not in z:
                continue
            i0, i1 = ids.index(z["from"]), ids.index(z["to"])
            if not (z["from"] in self.gate_res and z["to"] not in self.gate_res):
                continue
            if not (z["xmin"] <= p[0] <= z["xmax"] and z["ymin"] <= p[1] <= z["ymax"]):
                continue
            pts = [(pts_all[i]["x"], pts_all[i]["y"]) for i in range(i0, i1 + 1)]
            d = min(point_seg_dist(p, pts[i], pts[i + 1]) for i in range(len(pts) - 1))
            self.corr[z["id"]] = max(self.corr[z["id"]], d)

    def check_hold(self, p, t):
        if self.race.get("phase") != "HOLD":
            self.hold_in = None
            return
        hd = next((i for i in self.seq if i["type"] == "hold" and i["id"] == self.race.get("item")), None)
        if hd is None:
            return
        d = math.sqrt((p[0] - hd["x"]) ** 2 + (p[1] - hd["y"]) ** 2 + (p[2] - hd["z"]) ** 2)
        if d <= hd["radius"] + 0.15:                # 추정 위치 오차를 감안한 여유
            self.hold_in = t if self.hold_in is None else self.hold_in
            self.hold_best[hd["id"]] = max(self.hold_best.get(hd["id"], 0.0), t - self.hold_in)
        else:
            self.hold_in = None

    def power_w(self):
        if self.links is None:
            return self.v["avionics_power_w"]
        v = self.v
        i_sum = 0.0
        p_sum = 0.0
        for name, tw in zip(self.links.name, self.links.twist):
            if not name.startswith("iris::rotor_"):
                continue
            w_g = abs(tw.angular.z) * SLOWDOWN
            thrust = v["motor_const"] * w_g * w_g
            w = math.sqrt(thrust / (v["eta_inst"] * v["kt_prop"]))
            i_m = v["cq"] * w * w / v["kt_m"] + (v["i0"] if w > 1.0 else 0.0)
            p_sum += (w / v["kvr"] + v["r_m"] * i_m) * i_m
            i_sum += i_m
        i_tot = i_sum + v["i_av"]
        return p_sum / v["esc_efficiency"] + v["avionics_power_w"] + i_tot * i_tot * v["r_pack"]

    def marker_center(self):
        try:
            i = self.model.name.index("pad_marker")
        except (ValueError, AttributeError):
            m = self.course["landing"]["marker"]
            return (m["x"], m["y"])
        p = self.model.pose[i].position
        return (p.x - MARKER_BOARD_HALF, p.y)

    # ---------- main ----------
    def run(self):
        rate = rospy.Rate(RATE_HZ)
        dt = 1.0 / RATE_HZ
        timeout = float(self.course.get("timeout_s", 180.0))
        n = 0
        while not rospy.is_shutdown() and self.status == "RUNNING":
            rate.sleep()
            if self.model is None:
                continue
            try:
                i = self.model.name.index("iris")
            except ValueError:
                continue
            t = rospy.get_time()
            pose, tw = self.model.pose[i], self.model.twist[i]
            p = (pose.position.x, pose.position.y, pose.position.z)
            if self.ground_z is None:
                self.ground_z = p[2]                 # 출발 전 땅 위 높이 (기록 시작 전, 기체가 서 있을 때의 값)
            if self.t_start is None:
                continue
            speed = math.sqrt(tw.linear.x ** 2 + tw.linear.y ** 2 + tw.linear.z ** 2)
            tilt = quat_tilt_deg(pose.orientation)
            self.max_speed = max(self.max_speed, speed)
            self.max_tilt = max(self.max_tilt, tilt)
            if p[2] > self.ground_z + 0.5:
                self.was_air = True
            self.energy_wh += self.power_w() * dt / 3600.0
            self.check_gate(p)
            self.check_corridor(p)
            self.check_hold(p, t)
            self.p_prev = p
            n += 1
            if n % 5 == 0:
                self.traj.append((round(t - self.t_start, 3), round(p[0], 3), round(p[1], 3), round(p[2], 3),
                                  round(speed, 3), round(tilt, 2), self.race.get("tag", ""), self.race.get("phase", "")))
            if tilt > TILT_CRASH_DEG:
                self.status, self.reason = "DNF", "전복(기울기 %.0f도)" % tilt
            elif t - self.t_start > timeout:
                self.status, self.reason = "DNF", "시간 초과(%.0f초)" % timeout
            elif self.energy_wh > self.v["usable_wh"]:
                self.status, self.reason = "DNF", "배터리 소진"
            elif self.was_air and p[2] <= self.ground_z + TOUCH_Z:
                # 처음 땅에 닿은 순간이 기록 시각이고 그 자리가 착륙 지점이다 (그 뒤의 튐은 보지 않음)
                self.t_touch, self.p_touch = t, p
                self.t_end = t
                if self.race.get("phase") not in ("LAND", "DONE"):
                    self.status, self.reason = "DNF", "코스 중간에 지면에 닿음"
                elif speed > TOUCH_SPEED_MAX:
                    self.status, self.reason = "DNF", "충돌 착지(속도 %.1f m/s)" % speed
                else:
                    self.status = "FINISHED"
            if self.race.get("phase") in ("ABORT",):
                self.status, self.reason = "DNF", "시작 실패(%s)" % self.race.get("sub", "")
        return self.finish()

    def finish(self):
        if self.status == "RUNNING":
            self.status, self.reason = "DNF", "중단"
        pen = []
        for g in self.gates:
            r = self.gate_res.get(g["id"])
            if r is None:
                self.gate_res[g["id"]] = {"passed": False, "lateral_m": None, "vertical_m": None, "how": "not reached"}
                r = self.gate_res[g["id"]]
            if not r["passed"]:
                pen.append({"what": "gate %s miss" % g["id"], "seconds": float(self.pen.get("gate_miss_s", 15.0))})
        for z in self.course.get("wind_zones", []) or []:
            if self.corr.get(z["id"], 0.0) > float(z.get("corridor_half_width", 1e9)):
                pen.append({"what": "wind corridor %s (%.2f m)" % (z["id"], self.corr[z["id"]]), "seconds": float(self.pen.get("corridor_s", 5.0))})
        for hd in [i for i in self.seq if i["type"] == "hold"]:
            ok = self.hold_res.get(hd["id"], False) and self.hold_best.get(hd["id"], 0.0) >= 0.8 * float(hd["seconds"])
            self.hold_res[hd["id"]] = bool(ok)
            if not ok:
                pen.append({"what": "hold %s fail" % hd["id"], "seconds": float(self.pen.get("hold_fail_s", 10.0))})
        land_err = None
        if self.status == "FINISHED" and self.p_touch is not None:
            mc = self.marker_center()
            land_err = math.hypot(self.p_touch[0] - mc[0], self.p_touch[1] - mc[1])
            free = float(self.pen.get("landing_free_m", 0.1))
            if land_err > float(self.pen.get("off_pad_m", 0.7)):
                pen.append({"what": "landing off pad (%.2f m)" % land_err, "seconds": float(self.pen.get("off_pad_s", 15.0))})
            elif land_err > free:
                pen.append({"what": "landing error (%.2f m)" % land_err,
                            "seconds": round((land_err - free) * float(self.pen.get("landing_s_per_m", 20.0)), 2)})
        time_s = None if self.t_end is None else round(self.t_end - self.t_start, 2)
        pen_total = round(sum(x["seconds"] for x in pen), 2)
        score = None if (self.status != "FINISHED" or time_s is None) else round(time_s + pen_total, 2)
        res = {"label": self.label, "course": self.course["name"], "status": self.status, "reason": self.reason,
               "time_s": time_s, "penalty_s": pen_total, "score": score, "penalties": pen,
               "gates": self.gate_res, "wind_corridor_max_m": {k: round(v, 3) for k, v in self.corr.items()},
               "holds": self.hold_res, "hold_best_s": {k: round(v, 2) for k, v in self.hold_best.items()},
               "landing_error_m": None if land_err is None else round(land_err, 3),
               "energy_used_wh": round(self.energy_wh, 3), "usable_wh": round(self.v["usable_wh"], 2),
               "max_speed_mps": round(self.max_speed, 2), "max_tilt_deg": round(self.max_tilt, 1),
               "design": self.v.get("design"), "mass_kg": round(self.v["mass"], 3),
               "thrust_to_weight": round(self.v["thrust_to_weight"], 2), "events": self.events}
        os.makedirs(self.out, exist_ok=True)
        with open(os.path.join(self.out, "result.json"), "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=1)
        with open(os.path.join(self.out, "traj.csv"), "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["t", "x", "y", "z", "speed", "tilt_deg", "tag", "phase"])
            w.writerows(self.traj)
        try:
            self.plot(res)
        except Exception as e:                       # 그림 실패가 채점을 막지 않게
            rospy.logwarn("plot failed: %s" % e)
        print("RESULT status=%s time=%s penalty=%s score=%s landing_err=%s energy=%.2fWh %s" % (
            res["status"], res["time_s"], res["penalty_s"], res["score"], res["landing_error_m"], self.energy_wh, self.reason))
        for x in pen:
            print("  penalty +%.1fs  %s" % (x["seconds"], x["what"]))
        return 0

    def plot(self, res):
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        from matplotlib.patches import Rectangle
        colors = {"cruise": "tab:blue", "wind": "tab:orange", "precision": "tab:olive", "landing": "tab:green", "": "gray"}
        fig, ax = plt.subplots(1, 2, figsize=(13, 5.2), gridspec_kw={"width_ratios": [1.5, 1.0]})
        a = ax[0]
        for z in self.course.get("wind_zones", []) or []:
            a.add_patch(Rectangle((z["xmin"], z["ymin"]), z["xmax"] - z["xmin"], z["ymax"] - z["ymin"], color="tab:cyan", alpha=0.15))
            a.annotate("", xy=((z["xmin"] + z["xmax"]) / 2 + z["wind"][0] * 0.4, (z["ymin"] + z["ymax"]) / 2 + z["wind"][1] * 0.4),
                       xytext=((z["xmin"] + z["xmax"]) / 2, (z["ymin"] + z["ymax"]) / 2), arrowprops=dict(arrowstyle="->", color="tab:cyan", lw=2))
        for g in self.gates:
            yaw = math.radians(float(g.get("yaw_deg", 0.0)))
            hx, hy = -math.sin(yaw) * g["w"] / 2, math.cos(yaw) * g["w"] / 2
            ok = self.gate_res.get(g["id"], {}).get("passed", False)
            a.plot([g["x"] - hx, g["x"] + hx], [g["y"] - hy, g["y"] + hy], color="k" if ok else "red", lw=3)
            a.text(g["x"], g["y"] + 1.0, g["id"], ha="center", fontsize=9)
        for hd in [i for i in self.seq if i["type"] == "hold"]:
            a.add_patch(plt.Circle((hd["x"], hd["y"]), hd["radius"] * 2.5, color="gold", alpha=0.6))
            a.text(hd["x"], hd["y"] + 1.0, hd["id"], ha="center", fontsize=9)
        mc = self.marker_center()
        a.add_patch(Rectangle((mc[0] - 0.5, mc[1] - 0.5), 1.0, 1.0, color="k", alpha=0.7))
        a.text(mc[0], mc[1] - 1.6, "pad", ha="center", fontsize=9)
        if self.traj:
            for k in range(1, len(self.traj)):
                p0, p1 = self.traj[k - 1], self.traj[k]
                a.plot([p0[1], p1[1]], [p0[2], p1[2]], color=colors.get(p1[6], "gray"), lw=1.6)
        for tag, c in colors.items():
            if tag:
                a.plot([], [], color=c, lw=2, label=tag)
        a.set_aspect("equal")
        a.set_xlabel("x east (m)")
        a.set_ylabel("y north (m)")
        a.grid(alpha=0.3)
        a.legend(loc="upper center", bbox_to_anchor=(0.5, -0.12), ncol=4, frameon=False)
        a.set_title("%s  |  %s  |  time %s s + penalty %s s = score %s" % (
            res["course"], res["status"], res["time_s"], res["penalty_s"], res["score"]), fontsize=10)
        b = ax[1]
        if self.traj:
            t = [r[0] for r in self.traj]
            b.plot(t, [r[3] for r in self.traj], label="altitude (m)")
            b.plot(t, [r[4] for r in self.traj], label="speed (m/s)")
        b.set_xlabel("simulation time (s)")
        b.grid(alpha=0.3)
        b.legend(loc="upper center", bbox_to_anchor=(0.5, -0.12), ncol=2, frameon=False)
        b.set_title("landing error %s m  |  energy %.1f / %.1f Wh" % (res["landing_error_m"], res["energy_used_wh"], res["usable_wh"]), fontsize=10)
        fig.tight_layout()
        fig.savefig(os.path.join(self.out, "plot.png"), dpi=130)
        plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--course", required=True)
    ap.add_argument("--vehicle", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--label", default="run")
    a = ap.parse_args(rospy.myargv()[1:])
    with open(a.course, encoding="utf-8") as f:
        course = yaml.safe_load(f)
    with open(a.vehicle, encoding="utf-8") as f:
        vehicle = yaml.safe_load(f)
    rospy.init_node("race_referee")
    return Referee(course, vehicle, a.out, a.label).run()


if __name__ == "__main__":
    sys.exit(main())
