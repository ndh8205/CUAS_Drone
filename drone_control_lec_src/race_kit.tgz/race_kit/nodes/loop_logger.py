#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""루프 기록 노드 (고치지 않는 파일). 제어 루프마다 목표값과 실제값을 기록해 loops.csv 와 plot_loops.png 를 남긴다.

읽는 토픽 (모두 MAVROS 가 PX4 에서 받아 내보내는 값)
- 각속도 루프: 목표 = /mavros/setpoint_raw/target_attitude 의 body_rate   · 실제 = /mavros/imu/data 의 angular_velocity
- 자세 루프  : 목표 = /mavros/setpoint_raw/target_attitude 의 orientation · 실제 = /mavros/imu/data 의 orientation
- 속도 루프  : 목표 = /mavros/setpoint_raw/target_local 의 velocity       · 실제 = /mavros/local_position/velocity_local
- 위치 루프  : 목표 = /mavros/setpoint_raw/target_local 의 position       · 실제 = /mavros/local_position/pose
위치와 속도는 PX4 가 추정한 값이다 (출발한 자리가 원점). 코스 파일의 좌표와는 출발 위치만큼 다르다.
시각 0 은 심판이 기록을 시작한 순간(기체가 땅에서 뜬 순간)이다. 그림 맨 위의 띠는 요소마다 걸린 시간과 그때 쓰인 게인 조다.
race.sh 가 끝낼 때 보내는 신호를 받으면 파일을 쓰고 끝난다. 그림은 tools/plot_loops.py 로 다시 그리거나 다른 실행과 겹쳐 그릴 수 있다.
"""
import argparse
import csv
import json
import math
import os
import signal
import sys

import rospy
import yaml
from gazebo_msgs.msg import ModelStates
from geometry_msgs.msg import PoseStamped, TwistStamped
from mavros_msgs.msg import AttitudeTarget, PositionTarget
from mavros_msgs.srv import MessageInterval
from sensor_msgs.msg import Imu

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "tools"))
import plot_loops  # noqa: E402  (그림 그리기. 같은 함수로 나중에 다시 그릴 수 있음: tools/plot_loops.py)

RATE_HZ = 50.0
LIFTOFF_DZ = 0.10
STREAMS = (83, 85, 30, 31, 32)      # ATTITUDE_TARGET, POSITION_TARGET_LOCAL_NED, ATTITUDE, ATTITUDE_QUATERNION, LOCAL_POSITION_NED
NAN = float("nan")
COLS = plot_loops.COLS


def euler_deg(q):
    """쿼터니언을 롤·피치·요 (도) 로 바꾼다."""
    roll = math.atan2(2.0 * (q.w * q.x + q.y * q.z), 1.0 - 2.0 * (q.x * q.x + q.y * q.y))
    pitch = math.asin(max(-1.0, min(1.0, 2.0 * (q.w * q.y - q.z * q.x))))
    yaw = math.atan2(2.0 * (q.w * q.z + q.x * q.y), 1.0 - 2.0 * (q.y * q.y + q.z * q.z))
    return math.degrees(roll), math.degrees(pitch), math.degrees(yaw)


def load_marks(out_dir, course_path):
    """심판 결과에서 기록 시작 시각, 접지 시각, 요소마다의 (시작, 끝, 이름, 게인 조) 를 읽는다."""
    marks = {"t0": None, "t_end": None, "spans": []}
    try:
        with open(os.path.join(out_dir, "result.json"), encoding="utf-8") as f:
            res = json.load(f)
        with open(course_path, encoding="utf-8") as f:
            seq = yaml.safe_load(f).get("sequence", [])
    except (OSError, ValueError, yaml.YAMLError, AttributeError):
        return marks
    tags = {i["id"]: i.get("tag", "cruise") for i in seq}
    done, t_prev, t_last = [], None, None
    for e in res.get("events") or []:
        ph, item = e.get("phase"), e.get("item", "")
        t_last = e["t"]
        if ph == "TAKEOFF":
            marks["t0"] = t_prev = e["t"]
        elif ph in ("GATE_DONE", "HOLD_DONE") and t_prev is not None:
            done.append(item)
            if e["t"] - t_prev > 0.05:
                marks["spans"].append((t_prev, e["t"], item, tags.get(item, "")))
            t_prev = e["t"]
        elif ph == "DONE" and t_prev is not None:
            land = next((i for i in seq if i["type"] == "land"), None)
            marks["spans"].append((t_prev, e["t"], land["id"] if land else "land", (land or {}).get("tag", "landing")))
            marks["t_end"] = e["t"]
            t_prev = None
    if t_prev is not None and t_last is not None:     # 완주하지 못한 실행: 하던 요소를 끝까지 이어 그림
        nxt = next((i for i in seq if i["id"] not in done), None)
        if nxt is not None and t_last - t_prev > 0.05:
            marks["spans"].append((t_prev, t_last, nxt["id"], nxt.get("tag", "")))
    return marks


class Logger(object):
    def __init__(self):
        self.att_sp = None
        self.loc_sp = None
        self.imu = None
        self.pose = None
        self.vel = None
        self.truth_z = None
        self.ground_z = None
        self.t_lift = None
        self.rows = []
        self.stop = False
        rospy.Subscriber("/mavros/setpoint_raw/target_attitude", AttitudeTarget, lambda m: setattr(self, "att_sp", m), queue_size=5)
        rospy.Subscriber("/mavros/setpoint_raw/target_local", PositionTarget, lambda m: setattr(self, "loc_sp", m), queue_size=5)
        rospy.Subscriber("/mavros/imu/data", Imu, lambda m: setattr(self, "imu", m), queue_size=5)
        rospy.Subscriber("/mavros/local_position/pose", PoseStamped, lambda m: setattr(self, "pose", m), queue_size=5)
        rospy.Subscriber("/mavros/local_position/velocity_local", TwistStamped, lambda m: setattr(self, "vel", m), queue_size=5)
        rospy.Subscriber("/gazebo/model_states", ModelStates, self.on_models, queue_size=1)

    def on_models(self, msg):
        try:
            i = msg.name.index("iris")
        except ValueError:
            return
        self.truth_z = msg.pose[i].position.z

    def faster_streams(self):
        """PX4 가 목표값과 상태를 50 Hz 로 내보내게 한다 (기본 주기로는 각속도와 자세의 움직임이 잘 보이지 않음)."""
        try:
            rospy.wait_for_service("/mavros/set_message_interval", timeout=20.0)
            srv = rospy.ServiceProxy("/mavros/set_message_interval", MessageInterval)
            for mid in STREAMS:
                srv(message_id=mid, message_rate=RATE_HZ)
        except (rospy.ROSException, rospy.ServiceException) as e:
            rospy.logwarn("stream rate not changed: %s" % e)

    def sample(self):
        if self.imu is None or self.pose is None or self.vel is None:
            return
        t = rospy.get_time()
        if self.truth_z is not None:
            if self.ground_z is None:
                self.ground_z = self.truth_z
            elif self.t_lift is None and self.truth_z - self.ground_z >= LIFTOFF_DZ:
                self.t_lift = t
        w = self.imu.angular_velocity
        roll, pitch, yaw = euler_deg(self.imu.orientation)
        if self.att_sp is not None:
            br = self.att_sp.body_rate
            r_sp = (math.degrees(br.x), math.degrees(br.y), math.degrees(br.z))
            a_sp = euler_deg(self.att_sp.orientation)
        else:
            r_sp, a_sp = (NAN, NAN, NAN), (NAN, NAN, NAN)
        if self.loc_sp is not None:
            v_sp = (self.loc_sp.velocity.x, self.loc_sp.velocity.y, self.loc_sp.velocity.z)
            p_sp = (self.loc_sp.position.x, self.loc_sp.position.y, self.loc_sp.position.z)
        else:
            v_sp, p_sp = (NAN, NAN, NAN), (NAN, NAN, NAN)
        v, p = self.vel.twist.linear, self.pose.pose.position
        self.rows.append((t, r_sp[0], math.degrees(w.x), r_sp[1], math.degrees(w.y), r_sp[2], math.degrees(w.z),
                          a_sp[0], roll, a_sp[1], pitch, a_sp[2], yaw,
                          v_sp[0], v.x, v_sp[1], v.y, v_sp[2], v.z, p_sp[0], p.x, p_sp[1], p.y, p_sp[2], p.z))

    def save(self, out_dir, course_path):
        csv_path, png_path = os.path.join(out_dir, "loops.csv"), os.path.join(out_dir, "plot_loops.png")
        if not self.rows:
            print("no samples")
            return
        marks = load_marks(out_dir, course_path) if course_path else {"t0": None, "t_end": None, "spans": []}
        lifted = marks["t0"] is not None or self.t_lift is not None
        t0 = marks["t0"] if marks["t0"] is not None else (self.t_lift if self.t_lift is not None else self.rows[0][0])
        t_cut = (marks["t_end"] - t0 + 1.0) if marks["t_end"] is not None else float("inf")    # 접지 1초 뒤까지만
        rows = [(r[0] - t0,) + r[1:] for r in self.rows if -1.0 <= r[0] - t0 <= t_cut]
        with open(csv_path, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(COLS)
            for r in rows:
                w.writerow(["%.3f" % r[0]] + ["" if (isinstance(x, float) and math.isnan(x)) else "%.4f" % x for x in r[1:]])
        print("saved %s (%d rows)" % (csv_path, len(rows)))
        spans = [(round(a - t0, 3), round(b - t0, 3), name, tag) for a, b, name, tag in marks["spans"]]
        with open(os.path.join(out_dir, "loops_meta.json"), "w", encoding="utf-8") as f:      # 그림을 다시 그릴 때 쓰는 요소 구간
            json.dump({"lifted": lifted, "spans": spans}, f, ensure_ascii=False)
        try:
            plot_loops.plot_one(rows, spans, lifted, png_path)
            print("saved %s" % png_path)
        except Exception as e:                        # 그림 실패가 실행을 막지 않게
            print("plot failed: %s" % e)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True, help="결과 폴더")
    ap.add_argument("--course", default="", help="코스 파일 (요소 이름과 게인 조를 그림에 표시)")
    a = ap.parse_args(rospy.myargv()[1:])
    rospy.init_node("race_loop_logger", disable_signals=True)
    lg = Logger()

    def on_signal(signum, frame):
        lg.stop = True
    signal.signal(signal.SIGINT, on_signal)
    signal.signal(signal.SIGTERM, on_signal)
    lg.faster_streams()
    rate = rospy.Rate(RATE_HZ)
    while not lg.stop and not rospy.is_shutdown():
        try:
            rate.sleep()
        except rospy.ROSInterruptException:
            break
        except rospy.ROSTimeMovedBackwardsException:
            continue
        lg.sample()
    lg.save(a.out, a.course)
    return 0


if __name__ == "__main__":
    sys.exit(main())
