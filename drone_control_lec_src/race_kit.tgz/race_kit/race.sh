#!/bin/bash
# 레이스 한 번 실행.
#   사용법: ./race.sh [코스] [--gui] [--follow] [--design 파일] [--gains 파일] [--runner 파일] [--name 이름] [--sim-only]
#   코스       : courses 폴더의 코스 이름 (기본 practice · 조절용 시험 비행은 tune) 또는 코스 yaml 경로
#   --gui      : Gazebo 화면과 드론 카메라 창을 띄움 (기본은 화면 없이 실행)
#   --follow   : --gui 와 함께 쓰면 Gazebo 화면이 기체를 따라감
#   --runner   : 실행 노드 파일. 주지 않으면 my_code/my_runner.py 가 있을 때 그 파일, 없으면 nodes/race_runner.py
#   --sim-only : 시뮬레이터만 켜고 기다림 (ROS 명령을 써 보거나 내 노드를 직접 실행할 때). Ctrl+C 로 끝냄
# 새 터미널에서 실행한다 (ROS 환경은 ~/.bashrc 가 준비함).
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COURSE="$KIT/courses/practice.yaml"
GUI=false
FOLLOW=false
SIMONLY=false
DESIGN="$KIT/design/my_design.yaml"
GAINS="$KIT/gains/my_gains.yaml"
RUNNER=""
NAME="$(date +%m%d_%H%M%S)"
while [ $# -gt 0 ]; do
  case "$1" in
    --gui) GUI=true ;;
    --follow) FOLLOW=true ;;
    --sim-only) SIMONLY=true ;;
    --design) DESIGN="$(realpath "$2" 2>/dev/null)"; [ -n "$DESIGN" ] || DESIGN="$2"; shift ;;
    --gains) GAINS="$(realpath "$2" 2>/dev/null)"; [ -n "$GAINS" ] || GAINS="$2"; shift ;;
    --runner) RUNNER="$(realpath "$2" 2>/dev/null)"; [ -n "$RUNNER" ] || RUNNER="$2"; shift ;;
    --name) NAME="$2"; shift ;;
    *.yaml) COURSE="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")" ;;
    *) if [ -f "$KIT/courses/$1.yaml" ]; then COURSE="$KIT/courses/$1.yaml"; else echo "모르는 인자 또는 없는 코스: $1"; exit 1; fi ;;
  esac
  shift
done
if ! command -v roslaunch >/dev/null 2>&1 || ! rospack find px4 >/dev/null 2>&1; then
  echo "ROS 와 PX4 환경이 잡혀 있지 않음. 새 터미널을 열어 다시 실행할 것 (~/.bashrc 확인)"; exit 1
fi
case "$NAME" in
  ""|*/*|.*|-*) echo "결과 이름으로 사용할 수 없음: '$NAME'  (빗금 없이 · 점이나 줄표로 시작하지 않게)"; exit 1 ;;
esac
[ -f "$COURSE" ] || { echo "코스 파일이 없음: $COURSE"; exit 1; }
if [ -z "$RUNNER" ]; then
  if [ -f "$KIT/my_code/my_runner.py" ]; then RUNNER="$KIT/my_code/my_runner.py"; else RUNNER="$KIT/nodes/race_runner.py"; fi
fi
[ -f "$RUNNER" ] || { echo "실행 노드 파일이 없음: $RUNNER"; exit 1; }
OUT="$KIT/results/$NAME"
# 설계 파일과 게인 파일의 형식 점검 (시뮬레이터를 켜기 전에 오타를 알려 줌)
python3 "$KIT/tools/check_inputs.py" --design "$DESIGN" --gains "$GAINS" || exit 2
# 내 실행 노드를 쓸 때는 문법도 먼저 점검
if [ "$RUNNER" != "$KIT/nodes/race_runner.py" ]; then
  python3 "$KIT/tools/check_inputs.py" --runner "$RUNNER" || exit 2
fi
# 같은 이름으로 다시 실행할 때 앞 실행의 결과와 기록이 남지 않게
rm -f "$OUT/result.json" "$OUT/plot.png" "$OUT/traj.csv" "$OUT/runner.log" "$OUT/referee.log" "$OUT/wind.log" "$OUT/camview.log" \
      "$OUT/loops.csv" "$OUT/loops_meta.json" "$OUT/plot_loops.png" "$OUT/compare_loops.png" "$OUT/loops.log" "$OUT/runner_exit" "$OUT/runner_used.py"
mkdir -p "$OUT" "$KIT/build"
cd "$KIT" || exit 1
RUN=""; LOG=""

cleanup() {
  [ -n "$RUN" ] && kill $RUN 2>/dev/null
  pkill -INT -x roslaunch 2>/dev/null
  for i in $(seq 1 16); do pgrep -x roslaunch >/dev/null || break; sleep 0.5; done
  for p in px4 gzserver gzclient; do pkill -x $p 2>/dev/null; done
  for i in $(seq 1 10); do pgrep -x gzserver >/dev/null || break; sleep 0.5; done
  for p in px4 gzserver gzclient roslaunch; do pkill -9 -x $p 2>/dev/null; done
  # 이 스크립트가 띄운 노드만 끝낸다. 명령 줄의 앞부분까지 맞춰 보므로 같은 파일을 편집기로 열어 둔 창은 그대로 남는다
  pkill -f "^python3 nodes/(wind_node|referee|loop_logger)\.py" 2>/dev/null
  pkill -f "^python3 .* --px4-params " 2>/dev/null     # 실행 노드 (내 실행 노드 포함)
  pkill -INT -f "^python3 tools/nav_logger\.py" 2>/dev/null
  pkill -f "^python3 tools/cam_view\.py" 2>/dev/null
  pkill -x rosmaster 2>/dev/null; pkill -x rosout 2>/dev/null     # roslaunch 가 띄운 것이 남지 않게
}

echo "== 1. 기체 만들기 =="
python3 design/build_vehicle.py --design "$DESIGN" --out "$KIT/build" $RACE_BUILD_ARGS | tee "$OUT/design_report.txt"
if [ "${PIPESTATUS[0]}" -ne 0 ]; then echo "설계가 조건을 만족하지 않아 중단함"; exit 2; fi
echo "== 2. 코스 만들기 =="
WORLD_ARGS=""
if [ "$GUI" = true ]; then WORLD_ARGS="--gui-view"; [ "$FOLLOW" = true ] && WORLD_ARGS="--follow"; fi
python3 tools/make_world.py --course "$COURSE" --base-world "$(rospack find mavlink_sitl_gazebo)/worlds/empty.world" --out "$KIT/build/race.world" $WORLD_ARGS || exit 2
cp "$GAINS" "$OUT/gains.yaml"; cp "$DESIGN" "$OUT/design.yaml"
[ "$RUNNER" != "$KIT/nodes/race_runner.py" ] && cp "$RUNNER" "$OUT/runner_used.py"

echo "== 3. 시뮬레이터 시작 =="
# 화면 없이 실행할 때는 전용 가상 화면(Xvfb)에서 카메라 영상을 그린다 (WSL 그래픽 창 상태와 무관하게 동작).
# Xvfb 가 없으면 현재 화면(DISPLAY)을 그대로 쓴다. 설치: sudo apt install -y xvfb
XVFB_PID=""
if [ "$GUI" = false ] && [ -z "$RACE_USE_DISPLAY" ] && command -v Xvfb >/dev/null 2>&1; then
  for d in 97 98 99 96 95; do
    [ -e /tmp/.X11-unix/X$d ] && continue
    Xvfb :$d -screen 0 1280x720x24 -nolisten tcp > "$OUT/xvfb.log" 2>&1 &
    XVFB_PID=$!
    sleep 1
    if kill -0 $XVFB_PID 2>/dev/null; then export DISPLAY=:$d; break; fi
    XVFB_PID=""
  done
fi
stop_display() { [ -n "$XVFB_PID" ] && kill $XVFB_PID 2>/dev/null; }
# Ctrl+C 로 멈추면 시뮬레이터와 노드를 모두 끝내고 나간다
trap 'echo; echo "중단함 · 시뮬레이터 끝내는 중"; cleanup >/dev/null 2>&1; stop_display; rm -f "$HOME"/.ros/parameters*.bson; exit 130' INT TERM
cleanup >/dev/null 2>&1; sleep 1
rm -f "$HOME"/.ros/parameters*.bson          # PX4 파라미터를 기본값에서 시작
export GAZEBO_MODEL_PATH="$KIT/models:$(dirname "$COURSE")/../models:$GAZEBO_MODEL_PATH"   # 키트의 GPS·착륙 표식 모형
# interactive:=false = PX4 대화형 셸을 끔 (화면 없는 실행에서 프롬프트가 로그를 가득 채우는 것을 막음)
start_sim() {
  : > "$OUT/sim.log"           # 빈 기록 파일에서 시작 (앞 실행의 "home set" 줄을 읽지 않게)
  roslaunch px4 mavros_posix_sitl.launch world:="$KIT/build/race.world" sdf:="$KIT/build/iris_race.sdf" gui:=$GUI interactive:=false >> "$OUT/sim.log" 2>&1 &
  for i in $(seq 1 120); do grep -q "home set" "$OUT/sim.log" 2>/dev/null && break; sleep 1; done
  grep -q "home set" "$OUT/sim.log" || return 1
  # 아래 방향 카메라 영상이 나오는지 확인 (비전 착륙에 필요)
  timeout 30 rostopic echo -n 1 --noarr /iris/usb_cam/image_raw/compressed > /dev/null 2>&1 || return 2
  return 0
}
READY=0
for try in 1 2 3; do
  if start_sim; then READY=1; break; fi
  echo "시뮬레이터 준비 실패 (시도 $try/3: PX4 시작 또는 카메라 영상). 다시 시작함"
  cleanup >/dev/null 2>&1; sleep 5
done
if [ $READY -ne 1 ]; then echo "시뮬레이터가 준비되지 않음 ($OUT/sim.log 확인)"; cleanup; stop_display; rm -f "$HOME"/.ros/parameters*.bson; exit 3; fi
export PYTHONUNBUFFERED=1

if [ "$SIMONLY" = true ]; then
  # 시뮬레이터만 켜 둔다. 바람은 레이스와 같게 불고, 실행 노드와 심판은 켜지 않는다.
  # 한도 값, 기체 파라미터, 게인 파일의 base 값은 레이스와 같게 PX4 에 넣어 둔다.
  python3 tools/apply_params.py --course "$COURSE" --gains "$GAINS" --px4-params "$KIT/build/px4_params.yaml" 2>> "$OUT/sim.log"
  python3 nodes/wind_node.py --course "$COURSE" --vehicle "$KIT/build/vehicle.yaml" > "$OUT/wind.log" 2>&1 &
  if [ "$GUI" = true ]; then python3 tools/cam_view.py > "$OUT/camview.log" 2>&1 & fi
  echo "== 시뮬레이터만 실행 중 =="
  echo "다른 터미널에서 ROS 명령과 내 노드 실행 가능 · 끝내려면 이 창에서 Ctrl+C"
  echo "실행 노드를 직접 실행하는 명령 (다른 터미널, race_kit 폴더에서):"
  echo "  python3 ${RUNNER#$KIT/} --course ${COURSE#$KIT/} --gains ${GAINS#$KIT/} --px4-params build/px4_params.yaml"
  trap 'echo; echo "시뮬레이터 끝내는 중"; cleanup >/dev/null 2>&1; stop_display; rm -f "$HOME"/.ros/parameters*.bson; exit 0' INT TERM
  while pgrep -x roslaunch >/dev/null; do sleep 1; done
  cleanup >/dev/null 2>&1; stop_display; rm -f "$HOME"/.ros/parameters*.bson
  exit 0
fi

echo "== 4. 레이스 =="
[ "$RUNNER" != "$KIT/nodes/race_runner.py" ] && echo "실행 노드: ${RUNNER#$KIT/}"
if [ -n "$RACE_NAVLOG" ]; then python3 tools/nav_logger.py --out "$OUT/nav.csv" ${RACE_SAVECAM:+--cam-dir "$OUT/cam"} > "$OUT/navlog.log" 2>&1 & fi
if [ "$GUI" = true ]; then python3 tools/cam_view.py > "$OUT/camview.log" 2>&1 & fi      # 아래 방향 카메라 창
python3 nodes/wind_node.py --course "$COURSE" --vehicle "$KIT/build/vehicle.yaml" > "$OUT/wind.log" 2>&1 &
python3 nodes/loop_logger.py --out "$OUT" --course "$COURSE" > "$OUT/loops.log" 2>&1 &
LOG=$!
# 빈 기록 파일 두 개를 먼저 만들어 둠 (아래 tail 이 파일이 생기기 전에 열어 심판의 진행 줄을 놓치지 않게, 앞 실행의 기록을 읽지 않게)
: > "$OUT/referee.log"; : > "$OUT/runner.log"
python3 nodes/referee.py --course "$COURSE" --vehicle "$KIT/build/vehicle.yaml" --out "$OUT" --label "$NAME" --runner-flag "$OUT/runner_exit" >> "$OUT/referee.log" 2>&1 &
REF=$!
python3 "$RUNNER" --course "$COURSE" --gains "$GAINS" --px4-params "$KIT/build/px4_params.yaml" >> "$OUT/runner.log" 2>&1 &
RUN=$!
# 심판이 판정을 끝내면 실행 노드를 8초 뒤에 끝낸다 (완주 실패 뒤에 실행 노드가 남은 요소를 계속 기다리지 않게)
( while kill -0 $REF 2>/dev/null; do sleep 0.5; done; sleep 8; kill $RUN 2>/dev/null ) &
# 진행 줄: 이륙·게이트·제자리 유지·접지는 심판 기록에서, 게인 조와 착륙 단계는 실행 노드 기록에서 읽는다
tail -q -n +1 -f "$OUT/runner.log" "$OUT/referee.log" --pid=$RUN 2>/dev/null | python3 -u tools/show_progress.py
touch "$OUT/runner_exit"       # 실행 노드가 끝났음을 심판에게 알림
for i in $(seq 1 90); do kill -0 $REF 2>/dev/null || break; sleep 0.5; done
kill -INT $LOG 2>/dev/null     # 루프 기록을 파일로 쓰게 함
for i in $(seq 1 30); do kill -0 $LOG 2>/dev/null || break; sleep 0.5; done
RUN=""
cleanup >/dev/null 2>&1
stop_display
rm -f "$HOME"/.ros/parameters*.bson          # 레이스에서 바꾼 PX4 파라미터가 다른 시뮬레이션 실행에 남지 않게
# PX4 비행 기록(ulg)은 실행마다 약 20 MB 라 쌓이면 디스크를 많이 차지한다. 이번 실행에서 생긴 것만 지운다.
# 남기려면 RACE_KEEP_ULOG=1 ./race.sh ...   (기록 위치: ~/.ros/log/<날짜>/)
if [ -z "$RACE_KEEP_ULOG" ] && [ -d "$HOME/.ros/log" ]; then
  find "$HOME/.ros/log" -name '*.ulg' -newer "$OUT/design.yaml" -delete 2>/dev/null
fi

echo "== 5. 결과 =="
if python3 tools/show_result.py --crashed "$OUT"; then      # 실행 노드가 스스로 오류로 끝난 경우에만 (키트가 끝낸 경우는 제외)
  echo "실행 노드가 오류로 끝남 · runner.log 의 끝부분:"
  tail -n 6 "$OUT/runner.log" | sed 's/^/    /'
fi
python3 tools/show_result.py "$OUT"
echo "결과 폴더: $OUT"
if command -v wslpath >/dev/null 2>&1; then
  [ -f "$OUT/plot.png" ] && echo "그림 보기: explorer.exe \"$(wslpath -w "$OUT/plot.png")\""
  [ -f "$OUT/plot_loops.png" ] && echo "루프 그림: explorer.exe \"$(wslpath -w "$OUT/plot_loops.png")\""
fi
exit 0
