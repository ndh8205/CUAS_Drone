#!/bin/bash
# 레이스 한 번 실행.
#   사용법: ./race.sh [코스] [--gui] [--design 파일] [--gains 파일] [--name 이름]
#   코스  : courses 폴더의 코스 이름 (기본 practice) 또는 코스 yaml 경로
#   --gui : Gazebo 화면과 드론 카메라 창을 띄움 (기본은 화면 없이 실행)
#   --follow : --gui 와 함께 쓰면 Gazebo 화면이 기체를 따라감
# 새 터미널에서 실행한다 (ROS 환경은 ~/.bashrc 가 준비함).
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COURSE="$KIT/courses/practice.yaml"
GUI=false
FOLLOW=false
DESIGN="$KIT/design/my_design.yaml"
GAINS="$KIT/gains/my_gains.yaml"
NAME="$(date +%m%d_%H%M%S)"
while [ $# -gt 0 ]; do
  case "$1" in
    --gui) GUI=true ;;
    --follow) FOLLOW=true ;;
    --design) DESIGN="$(realpath "$2" 2>/dev/null)"; [ -n "$DESIGN" ] || DESIGN="$2"; shift ;;
    --gains) GAINS="$(realpath "$2" 2>/dev/null)"; [ -n "$GAINS" ] || GAINS="$2"; shift ;;
    --name) NAME="$2"; shift ;;
    *.yaml) COURSE="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")" ;;
    *) if [ -f "$KIT/courses/$1.yaml" ]; then COURSE="$KIT/courses/$1.yaml"; else echo "모르는 인자 또는 없는 코스: $1"; exit 1; fi ;;
  esac
  shift
done
if ! command -v roslaunch >/dev/null 2>&1 || ! rospack find px4 >/dev/null 2>&1; then
  echo "ROS 와 PX4 환경이 잡혀 있지 않음. 새 터미널을 열어 다시 실행할 것 (~/.bashrc 확인)"; exit 1
fi
case "$NAME" in
  ""|*/*|.*|-*) echo "결과 이름으로 쓸 수 없음: '$NAME'  (빗금 없이 · 점이나 줄표로 시작하지 않게)"; exit 1 ;;
esac
[ -f "$COURSE" ] || { echo "코스 파일이 없음: $COURSE"; exit 1; }
OUT="$KIT/results/$NAME"
# 설계 파일과 게인 파일의 형식 점검 (시뮬레이터를 켜기 전에 오타를 알려 줌)
python3 "$KIT/tools/check_inputs.py" --design "$DESIGN" --gains "$GAINS" || exit 2
# 같은 이름으로 다시 실행할 때 앞 실행의 결과와 기록이 남지 않게
rm -f "$OUT/result.json" "$OUT/plot.png" "$OUT/traj.csv" "$OUT/runner.log" "$OUT/referee.log" "$OUT/wind.log" "$OUT/camview.log"
mkdir -p "$OUT" "$KIT/build"
cd "$KIT" || exit 1

cleanup() {
  pkill -INT -x roslaunch 2>/dev/null
  for i in $(seq 1 16); do pgrep -x roslaunch >/dev/null || break; sleep 0.5; done
  for p in px4 gzserver gzclient; do pkill -x $p 2>/dev/null; done
  for i in $(seq 1 10); do pgrep -x gzserver >/dev/null || break; sleep 0.5; done
  for p in px4 gzserver gzclient roslaunch; do pkill -9 -x $p 2>/dev/null; done
  pkill -f "nodes/wind_node.py" 2>/dev/null; pkill -f "nodes/referee.py" 2>/dev/null; pkill -f "nodes/race_runner.py" 2>/dev/null
  pkill -INT -f "tools/nav_logger.py" 2>/dev/null
  pkill -f "tools/cam_view.py" 2>/dev/null
}

echo "== 1. 기체 만들기 =="
python3 design/build_vehicle.py --design "$DESIGN" --out "$KIT/build" $RACE_BUILD_ARGS | tee "$OUT/design_report.txt"
if [ "${PIPESTATUS[0]}" -ne 0 ]; then echo "설계가 조건을 만족하지 않아 중단함"; exit 2; fi
echo "== 2. 코스 만들기 =="
WORLD_ARGS=""
if [ "$GUI" = true ]; then WORLD_ARGS="--gui-view"; [ "$FOLLOW" = true ] && WORLD_ARGS="--follow"; fi
python3 tools/make_world.py --course "$COURSE" --base-world "$(rospack find mavlink_sitl_gazebo)/worlds/empty.world" --out "$KIT/build/race.world" $WORLD_ARGS || exit 2
cp "$GAINS" "$OUT/gains.yaml"; cp "$DESIGN" "$OUT/design.yaml"

echo "== 3. 시뮬레이터 시작 =="
# 화면 없이 실행할 때는 전용 가상 화면(Xvfb)에서 카메라 영상을 그린다 (WSL 그래픽 창 상태와 무관하게 동작).
# Xvfb 가 없으면 현재 화면(DISPLAY)을 그대로 쓴다. 설치: sudo apt install -y xvfb
XVFB_PID=""
if [ "$GUI" = false ] && [ -z "$RACE_USE_DISPLAY" ] && command -v Xvfb >/dev/null 2>&1; then
  for d in 97 98 99 96 95; do
    [ -e /tmp/.X11-unix/X$d ] && continue
    Xvfb :$d -screen 0 1280x720x24 -nolisten tcp > "$OUT/xvfb.log" 2>&1 &
    XVFB_PID=$!
    sleep 1
    if kill -0 $XVFB_PID 2>/dev/null; then export DISPLAY=:$d; break; fi
    XVFB_PID=""
  done
fi
stop_display() { [ -n "$XVFB_PID" ] && kill $XVFB_PID 2>/dev/null; }
cleanup >/dev/null 2>&1; sleep 1
rm -f "$HOME"/.ros/parameters*.bson          # PX4 파라미터를 기본값에서 시작
export GAZEBO_MODEL_PATH="$KIT/models:$(dirname "$COURSE")/../models:$GAZEBO_MODEL_PATH"   # 키트의 GPS·착륙 표식 모형
# interactive:=false = PX4 대화형 셸을 끔 (화면 없는 실행에서 프롬프트가 로그를 가득 채우는 것을 막음)
start_sim() {
  : > "$OUT/sim.log"           # 빈 기록 파일에서 시작 (앞 실행의 "home set" 줄을 읽지 않게)
  roslaunch px4 mavros_posix_sitl.launch world:="$KIT/build/race.world" sdf:="$KIT/build/iris_race.sdf" gui:=$GUI interactive:=false >> "$OUT/sim.log" 2>&1 &
  for i in $(seq 1 120); do grep -q "home set" "$OUT/sim.log" 2>/dev/null && break; sleep 1; done
  grep -q "home set" "$OUT/sim.log" || return 1
  # 아래 방향 카메라 영상이 나오는지 확인 (비전 착륙에 필요)
  timeout 30 rostopic echo -n 1 --noarr /iris/usb_cam/image_raw/compressed > /dev/null 2>&1 || return 2
  return 0
}
READY=0
for try in 1 2 3; do
  if start_sim; then READY=1; break; fi
  echo "시뮬레이터 준비 실패 (시도 $try/3: PX4 시작 또는 카메라 영상). 다시 시작함"
  cleanup >/dev/null 2>&1; sleep 5
done
if [ $READY -ne 1 ]; then echo "시뮬레이터가 준비되지 않음 ($OUT/sim.log 확인)"; cleanup; stop_display; rm -f "$HOME"/.ros/parameters*.bson; exit 3; fi

echo "== 4. 레이스 =="
export PYTHONUNBUFFERED=1
if [ -n "$RACE_NAVLOG" ]; then python3 tools/nav_logger.py --out "$OUT/nav.csv" ${RACE_SAVECAM:+--cam-dir "$OUT/cam"} > "$OUT/navlog.log" 2>&1 & fi
if [ "$GUI" = true ]; then python3 tools/cam_view.py > "$OUT/camview.log" 2>&1 & fi      # 아래 방향 카메라 창
python3 nodes/wind_node.py --course "$COURSE" --vehicle "$KIT/build/vehicle.yaml" > "$OUT/wind.log" 2>&1 &
python3 nodes/referee.py --course "$COURSE" --vehicle "$KIT/build/vehicle.yaml" --out "$OUT" --label "$NAME" > "$OUT/referee.log" 2>&1 &
REF=$!
: > "$OUT/runner.log"          # 빈 기록 파일을 먼저 만들어 둠 (아래 tail 이 앞 실행의 기록을 읽지 않게)
python3 nodes/race_runner.py --course "$COURSE" --gains "$GAINS" --px4-params "$KIT/build/px4_params.yaml" >> "$OUT/runner.log" 2>&1 &
RUN=$!
tail -n +1 -f "$OUT/runner.log" --pid=$RUN 2>/dev/null | python3 -u tools/show_progress.py
for i in $(seq 1 60); do kill -0 $REF 2>/dev/null || break; sleep 0.5; done
cleanup >/dev/null 2>&1
stop_display
rm -f "$HOME"/.ros/parameters*.bson          # 레이스에서 바꾼 PX4 파라미터가 다른 시뮬레이션 실행에 남지 않게
# PX4 비행 기록(ulg)은 실행마다 약 20 MB 라 쌓이면 디스크를 많이 차지한다. 이번 실행에서 생긴 것만 지운다.
# 남기려면 RACE_KEEP_ULOG=1 ./race.sh ...   (기록 위치: ~/.ros/log/<날짜>/)
if [ -z "$RACE_KEEP_ULOG" ] && [ -d "$HOME/.ros/log" ]; then
  find "$HOME/.ros/log" -name '*.ulg' -newer "$OUT/design.yaml" -delete 2>/dev/null
fi

echo "== 5. 결과 =="
python3 tools/show_result.py "$OUT"
echo "결과 폴더: $OUT"
if command -v wslpath >/dev/null 2>&1 && [ -f "$OUT/plot.png" ]; then echo "그림 보기: explorer.exe \"$(wslpath -w "$OUT/plot.png")\""; fi
