#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ROS 노드 예제: 이륙해 한 자리에 머문 뒤 착륙.

실행 (시뮬레이터만 실행한 상태에서 다른 터미널로)
  터미널 1:  ./race.sh tune --sim-only
  터미널 2:  python3 examples/hover_node.py --alt 2.0 --seconds 10

노드가 하는 일
1. /mavros/state 와 /mavros/local_position/pose 구독 (PX4 의 상태와 위치)
2. /mavros/setpoint_position/local 로 목표 위치를 20 Hz 로 발행
3. /mavros/set_mode 로 OFFBOARD 모드 요청, /mavros/cmd/arming 으로 시동
4. 목표 높이에 닿은 뒤 정해진 시간 동안 유지, AUTO.LAND 모드로 착륙

참고
- PX4 는 목표 위치가 0.5초 넘게 끊기면 OFFBOARD 모드에서 벗어남. 그래서 목표를 계속 발행
- 게인은 변경하지 않음. race.sh --sim-only 가 게인 파일의 base 값을 PX4 에 적용해 둔 상태로 비행
"""
import argparse
import sys

import rospy
from geometry_msgs.msg import PoseStamped
from mavros_msgs.msg import State
from mavros_msgs.srv import CommandBool, SetMode


class Hover(object):
    def __init__(self):
        self.state = State()
        self.pose = None
        rospy.Subscriber("/mavros/state", State, self.on_state, queue_size=5)
        rospy.Subscriber("/mavros/local_position/pose", PoseStamped, self.on_pose, queue_size=5)
        self.pub = rospy.Publisher("/mavros/setpoint_position/local", PoseStamped, queue_size=5)
        self.set_mode = rospy.ServiceProxy("/mavros/set_mode", SetMode)
        self.arming = rospy.ServiceProxy("/mavros/cmd/arming", CommandBool)
        self.rate = rospy.Rate(20.0)
        self.target = PoseStamped()

    def on_state(self, msg):
        self.state = msg

    def on_pose(self, msg):
        self.pose = msg

    def send(self, seconds):
        """목표 위치를 seconds 초 동안 보낸다."""
        end = rospy.get_time() + seconds
        while not rospy.is_shutdown() and rospy.get_time() < end:
            self.target.header.stamp = rospy.Time.now()
            self.pub.publish(self.target)
            self.rate.sleep()

    def run(self, alt, seconds):
        while not rospy.is_shutdown() and not (self.state.connected and self.pose is not None):
            self.rate.sleep()
        p = self.pose.pose.position
        print("PX4 연결됨 · 지금 위치 x %.2f  y %.2f  z %.2f" % (p.x, p.y, p.z))
        self.target.pose.position.x = p.x
        self.target.pose.position.y = p.y
        self.target.pose.position.z = alt
        self.target.pose.orientation = self.pose.pose.orientation
        self.send(2.0)                               # 모드를 바꾸기 전에 목표를 먼저 보내 둔다
        for _ in range(30):
            if self.state.mode != "OFFBOARD":
                self.set_mode(base_mode=0, custom_mode="OFFBOARD")
            elif not self.state.armed:
                self.arming(value=True)
            else:
                break
            self.send(0.5)
        print("모드 %s · 시동 %s" % (self.state.mode, "걸림" if self.state.armed else "안 걸림"))
        t0 = rospy.get_time()
        t_reach = None
        while not rospy.is_shutdown():
            self.send(1.0)
            now, z = rospy.get_time(), self.pose.pose.position.z
            if t_reach is None and abs(z - alt) < 0.2:
                t_reach = now
            print("  %5.1f s  높이 %.2f m (목표 %.2f m)%s" % (now - t0, z, alt, "" if t_reach is None else "  머무는 중"))
            if t_reach is not None and now - t_reach >= seconds:
                break
            if now - t0 > seconds + 30.0:
                print("목표 높이에 닿지 못함")
                break
        self.set_mode(base_mode=0, custom_mode="AUTO.LAND")
        print("착륙 모드로 바꿈")
        t1 = rospy.get_time()
        while not rospy.is_shutdown() and self.state.armed and rospy.get_time() - t1 < 40.0:
            self.rate.sleep()
        print("끝")
        return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--alt", type=float, default=2.0, help="머물 높이 (m)")
    ap.add_argument("--seconds", type=float, default=10.0, help="머무는 시간 (초)")
    a = ap.parse_args(rospy.myargv()[1:])
    rospy.init_node("hover_node")
    return Hover().run(a.alt, a.seconds)


if __name__ == "__main__":
    sys.exit(main())
