#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""코스의 한도 값, 기체 파라미터, 게인 파일의 base 값을 PX4 에 넣는다 (race.sh --sim-only 가 씀).

레이스에서는 실행 노드가 같은 일을 한다. 시뮬레이터만 켰을 때도 PX4 가 같은 값으로 돌게 하려고 따로 둔다.
게인 파일에 없는 게인은 허용 범위의 최솟값으로 넣는다.
"""
import argparse
import os
import sys

import rospy
import yaml
from mavros_msgs.msg import ParamValue
from mavros_msgs.srv import ParamGet, ParamSet

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import check_inputs  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--course", required=True)
    ap.add_argument("--gains", required=True)
    ap.add_argument("--px4-params", required=True)
    a = ap.parse_args(rospy.myargv()[1:])
    with open(a.course, encoding="utf-8") as f:
        course = yaml.safe_load(f)
    with open(a.gains, encoding="utf-8") as f:
        gains = yaml.safe_load(f) or {}
    with open(a.px4_params, encoding="utf-8") as f:
        px4_params = yaml.safe_load(f) or {}
    rospy.init_node("race_apply_params", anonymous=True)
    rospy.wait_for_service("/mavros/param/set", timeout=60.0)
    srv_set = rospy.ServiceProxy("/mavros/param/set", ParamSet)
    srv_get = rospy.ServiceProxy("/mavros/param/get", ParamGet)
    t0 = rospy.get_time()                             # MAVROS 가 PX4 파라미터 목록을 받을 때까지 대기
    while not rospy.is_shutdown() and rospy.get_time() - t0 < 60.0:
        try:
            if srv_get(param_id="MPC_XY_P").success:
                break
        except rospy.ServiceException:
            pass
        rospy.sleep(0.2)
    table = check_inputs.allowed_table()
    base = gains.get("base") if isinstance(gains.get("base"), dict) else {}
    values = {}
    values.update({k: float(v) for k, v in (course.get("limits", {}) or {}).items()})
    values.update({k: float(v) for k, v in px4_params.items()})
    n_gain = 0
    for k, (lo, hi) in table.items():
        try:
            x = float(base.get(k, lo))
        except (TypeError, ValueError):
            x = lo
        values[k] = min(max(x, lo), hi)
        n_gain += 1
    failed = []
    for k, v in sorted(values.items()):
        ok = False
        for _ in range(3):
            try:
                if srv_set(param_id=k, value=ParamValue(integer=0, real=v)).success:
                    ok = True
                    break
            except rospy.ServiceException:
                pass
            rospy.sleep(0.1)
        if not ok:
            failed.append(k)
    print("PX4 에 적용한 값: 게인 %d개 (%s 의 base) · 한도와 기체 파라미터 %d개" % (
        n_gain, os.path.basename(a.gains), len(values) - n_gain))
    if failed:
        print("적용하지 못한 값: %s" % "  ".join(failed))
    return 0


if __name__ == "__main__":
    sys.exit(main())
