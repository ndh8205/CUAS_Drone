#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""result.json 을 읽어 결과 요약을 보여 준다.  사용: show_result.py results/<이름>"""
import json
import os
import sys

WHAT = {"gate": "게이트", "miss": "놓침", "wind corridor": "바람 통로 이탈", "hold": "제자리 유지", "fail": "실패",
        "landing off pad": "착륙 패드 밖", "landing error": "착륙 오차"}
# 완주 실패 사유마다 먼저 볼 곳
LOOK = [("이륙하지 못함", "고도 루프 게인 (MPC_Z_P · MPC_Z_VEL_P_ACC · MPC_Z_VEL_I_ACC)"),
        ("전복", "각속도 루프와 자세 루프 게인 · 루프 그림의 rate loop 와 attitude loop"),
        ("시간 초과", "수평 위치 루프와 속도 루프 게인 · 요소별 시간에서 오래 걸린 곳"),
        ("코스 중간에 지면", "고도 루프 게인 · 루프 그림의 position up"),
        ("충돌 착지", "고도 루프 게인 · 착륙 직전의 하강 속도"),
        ("한도 위반", "코스 파일의 limits 값 · 실행 노드를 고쳤다면 속도와 기울기 명령"),
        ("허용 범위 밖 게인", "실행 노드가 PX4 에 적용하는 게인 값 · 게인 표의 허용 범위"),
        ("한도 값 변경", "실행 노드가 바꾸는 PX4 파라미터 · 코스 파일의 limits 값"),
        ("비정상 이동", "실행 노드가 기체 위치를 직접 바꾸는 코드"),
        ("배터리", "기체 설계의 호버 시간"),
        ("실행 노드가 비행 중", "실행 노드의 오류 · 결과 폴더의 runner.log")]


def ko(what):
    out = what
    for k in sorted(WHAT, key=len, reverse=True):
        out = out.replace(k, WHAT[k])
    return out


def item_times(r):
    """심판의 진행 기록에서 요소마다 걸린 시간을 구한다: [(이름, 초)]."""
    out, t_prev = [], None
    for e in r.get("events") or []:
        ph = e.get("phase")
        if ph == "TAKEOFF":
            t_prev = e["t"]
        elif ph in ("GATE_DONE", "HOLD_DONE") and t_prev is not None:
            out.append((e.get("item", ""), e["t"] - t_prev))
            t_prev = e["t"]
        elif ph == "DONE" and t_prev is not None:
            out.append(("착륙", e["t"] - t_prev))
            t_prev = e["t"]
    return out


def crashed(d):
    """실행 노드의 기록에 오류(Traceback)가 남았는지 본다."""
    p = os.path.join(d, "runner.log")
    if not os.path.exists(p):
        return False
    with open(p, encoding="utf-8", errors="replace") as f:
        return "Traceback (most recent call last)" in f.read()


def main():
    d = sys.argv[1] if len(sys.argv) > 1 else "."
    p = os.path.join(d, "result.json")
    if not os.path.exists(p):
        print("결과 파일이 없음: %s (심판 로그 referee.log 확인)" % p)
        return 1
    with open(p, encoding="utf-8") as f:
        r = json.load(f)
    fin = r["status"] == "FINISHED"
    print("=" * 40)
    print(" 코스        %s" % r["course"])
    print(" 상태        %s" % ("완주" if fin else "완주 실패 (%s)" % r["reason"]))
    if fin:
        print(" 시간        %.2f s" % r["time_s"])
        print(" 벌점        +%.2f s" % r["penalty_s"])
        print(" 점수        %.2f s   (작을수록 좋음)" % r["score"])
        for x in r["penalties"]:
            print("   벌점 +%-5.2f %s" % (x["seconds"], ko(x["what"])))
    else:
        look = next((v for k, v in LOOK if k in r["reason"]), None)
        if crashed(d):                                # 실행 노드가 오류로 끝난 실행: 원인은 그 오류
            look = "실행 노드의 오류 · 위에 출력된 runner.log 의 끝부분"
        if look:
            print(" 먼저 볼 곳  %s" % look)
        if not any(e.get("phase") == "TAKEOFF" for e in r.get("events") or []):
            # 뜨지 못한 실행: 요소별 줄은 모두 비어 있으므로 적지 않는다
            print(" 루프 그림   plot_loops.png · 루프마다 목표값(setpoint)과 실제값(actual)을 견줌")
            print(" 기체        %.2f kg · 추력 대 무게 %.2f" % (r["mass_kg"], r["thrust_to_weight"]))
            print("=" * 40)
            return 0
    # 완주하지 못한 실행에서는 판정이 난 요소만 적는다 (닿지 못한 요소는 줄을 만들지 않음)
    judged = {e.get("item") for e in r.get("events") or [] if e.get("phase") in ("GATE_DONE", "HOLD_DONE")}
    if r["gates"]:
        n_ok = sum(1 for v in r["gates"].values() if v["passed"])
        print(" 게이트      %d / %d 통과   (옆 · 위 = 게이트 중심에서 벗어난 거리)" % (n_ok, len(r["gates"])))
        for k, v in r["gates"].items():
            if v["lateral_m"] is None:
                if fin or k in judged:
                    print("   %s 놓침 (지나지 않음)" % k)
            else:
                print("   %s %s  옆 %+.2f m  위 %+.2f m" % (k, "통과" if v["passed"] else "놓침", v["lateral_m"], v["vertical_m"]))
    for k, v in r["wind_corridor_max_m"].items():
        if fin or v > 0.0:
            print(" 바람 통로   %s 최대 이탈 %.2f m" % (k, v))
    for k, v in r["holds"].items():
        if fin or k in judged:
            print(" 제자리 유지 %s %s" % (k, "성공" if v else "실패"))
    if r["landing_error_m"] is not None:
        print(" 착륙 오차   %.3f m" % r["landing_error_m"])
    times = item_times(r)
    if times:
        print(" 요소별 시간 %s  (초)" % " · ".join("%s %.1f" % (k, v) for k, v in times))
    steps = r.get("steps") or []
    if steps:
        print(" 계단 응답   상승 = 거리의 10 % 에서 90 % 까지 걸린 시간 · 지나침 = 목표를 넘어간 비율")
        print("             정착 = 움직이기 시작한 뒤 목표의 5 % 안에 머물 때까지 걸린 시간")
        for s in steps:
            if s["kind"] == "stay":
                print("   %s 제자리           최대 벗어남 %.2f m" % (s["id"], s["max_dev_m"]))
            elif s["rise_s"] is None:
                print("   %s %s %.1f m       목표의 90 %% 에 닿지 못함 (남은 거리 %.2f m)" % (s["id"], s["axis"], s["dist_m"], s["final_err_m"]))
            else:
                settle = "정착 못 함" if s["settle_s"] is None else "정착 %.1f s" % s["settle_s"]
                print("   %s %s %.1f m       상승 %.1f s · 지나침 %.0f %% · %s" % (s["id"], s["axis"], s["dist_m"], s["rise_s"], s["overshoot_pct"], settle))
    print(" 에너지      %.1f / %.1f Wh" % (r["energy_used_wh"], r["usable_wh"]))
    print(" 최대 속도   %.2f m/s   최대 기울기 %.0f 도" % (r["max_speed_mps"], r["max_tilt_deg"]))
    print(" 기체        %.2f kg · 추력 대 무게 %.2f" % (r["mass_kg"], r["thrust_to_weight"]))
    print("=" * 40)
    return 0


if __name__ == "__main__":
    sys.exit(main())
