#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""result.json 을 읽어 결과 요약을 보여 준다.  사용: show_result.py results/<이름>"""
import json
import os
import sys

WHAT = {"gate": "게이트", "miss": "놓침", "wind corridor": "바람 통로 이탈", "hold": "제자리 유지", "fail": "실패",
        "landing off pad": "착륙 패드 밖", "landing error": "착륙 오차"}


def ko(what):
    out = what
    for k in sorted(WHAT, key=len, reverse=True):
        out = out.replace(k, WHAT[k])
    return out


def main():
    d = sys.argv[1] if len(sys.argv) > 1 else "."
    p = os.path.join(d, "result.json")
    if not os.path.exists(p):
        print("결과 파일이 없음: %s (심판 로그 referee.log 확인)" % p)
        return 1
    with open(p, encoding="utf-8") as f:
        r = json.load(f)
    fin = r["status"] == "FINISHED"
    print("=" * 40)
    print(" 코스        %s" % r["course"])
    print(" 상태        %s" % ("완주" if fin else "완주 실패 (%s)" % r["reason"]))
    if fin:
        print(" 시간        %.2f s" % r["time_s"])
        print(" 벌점        +%.2f s" % r["penalty_s"])
        print(" 점수        %.2f s   (작을수록 좋음)" % r["score"])
    for x in r["penalties"]:
        print("   벌점 +%-5.2f %s" % (x["seconds"], ko(x["what"])))
    n_ok = sum(1 for v in r["gates"].values() if v["passed"])
    print(" 게이트      %d / %d 통과   (옆 · 위 = 게이트 중심에서 벗어난 거리)" % (n_ok, len(r["gates"])))
    for k, v in r["gates"].items():
        if v["lateral_m"] is None:
            print("   %s 놓침 (지나지 않음)" % k)
        else:
            print("   %s %s  옆 %+.2f m  위 %+.2f m" % (k, "통과" if v["passed"] else "놓침", v["lateral_m"], v["vertical_m"]))
    for k, v in r["wind_corridor_max_m"].items():
        print(" 바람 통로   %s 최대 이탈 %.2f m" % (k, v))
    for k, v in r["holds"].items():
        print(" 제자리 유지 %s %s" % (k, "성공" if v else "실패"))
    if r["landing_error_m"] is not None:
        print(" 착륙 오차   %.3f m" % r["landing_error_m"])
    print(" 에너지      %.1f / %.1f Wh" % (r["energy_used_wh"], r["usable_wh"]))
    print(" 최대 속도   %.2f m/s   최대 기울기 %.0f 도" % (r["max_speed_mps"], r["max_tilt_deg"]))
    print(" 기체        %.2f kg · 추력 대 무게 %.2f" % (r["mass_kg"], r["thrust_to_weight"]))
    print("=" * 40)
    return 0


if __name__ == "__main__":
    sys.exit(main())
