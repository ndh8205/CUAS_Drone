#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""루프 기록(loops.csv)으로 루프 그림을 그린다. 레이스가 끝날 때 자동으로 한 번 그려지고, 아래 명령으로 다시 그릴 수 있다.

사용 (race_kit 폴더에서)
  python3 tools/plot_loops.py results/t1                        그 실행의 plot_loops.png 를 다시 그림
  python3 tools/plot_loops.py results/t1 results/t2             두 실행을 겹쳐 그림 (끝에 적은 폴더에 compare_loops.png)
  python3 tools/plot_loops.py results/t1 results/t2 --element S2 --loop position
                                                                요소 S2 의 목표가 바뀐 순간을 0초로 맞춰 위치 루프만 겹쳐 그림
선택 항목
  --element 이름   그 요소의 목표 위치가 바뀐 순간을 0초로 두고 그 요소가 차례였던 동안만 그림 (같은 계단끼리 겹쳐짐)
  --loop 이름      rate · attitude · velocity · position 가운데 하나만 크게 그림
  --from 초 --to 초  그릴 시간 범위
  --out 파일       저장할 그림 파일
그림의 실선은 실제값(actual), 점선은 목표값(setpoint)이다. 겹쳐 그릴 때는 실행마다 색이 다르다.
"""
import argparse
import csv
import json
import math
import os
import sys

COLS = ["t", "rollrate_sp", "rollrate", "pitchrate_sp", "pitchrate", "yawrate_sp", "yawrate",
        "roll_sp", "roll", "pitch_sp", "pitch", "yaw_sp", "yaw",
        "vx_sp", "vx", "vy_sp", "vy", "vz_sp", "vz", "x_sp", "x", "y_sp", "y", "z_sp", "z"]
PANELS = [("roll rate (deg/s)", 1, 2), ("pitch rate (deg/s)", 3, 4), ("yaw rate (deg/s)", 5, 6),
          ("roll (deg)", 7, 8), ("pitch (deg)", 9, 10), ("yaw (deg)", 11, 12),
          ("velocity east (m/s)", 13, 14), ("velocity north (m/s)", 15, 16), ("velocity up (m/s)", 17, 18),
          ("position east (m)", 19, 20), ("position north (m)", 21, 22), ("position up (m)", 23, 24)]
ROWS = ["rate", "attitude", "velocity", "position"]
TAG_COLORS = {"cruise": "tab:blue", "wind": "tab:orange", "precision": "tab:olive", "landing": "tab:green"}
RUN_COLORS = ["tab:blue", "tab:orange", "tab:green", "tab:purple", "tab:brown"]


def read_run(folder):
    """결과 폴더에서 루프 기록과 요소 구간을 읽는다: (행 배열, 구간 목록, 이륙 여부)."""
    import numpy as np
    rows = []
    with open(os.path.join(folder, "loops.csv"), encoding="utf-8") as f:
        rd = csv.reader(f)
        next(rd)
        for r in rd:
            rows.append([float(x) if x != "" else float("nan") for x in r])
    meta = {"lifted": True, "spans": []}
    mp = os.path.join(folder, "loops_meta.json")
    if os.path.exists(mp):
        with open(mp, encoding="utf-8") as f:
            meta = json.load(f)
    return np.array(rows, dtype=float), [tuple(s) for s in meta.get("spans", [])], bool(meta.get("lifted", True))


def unwrap_yaw(a):
    import numpy as np
    for c in (11, 12):                                # 요 각은 +-180도에서 넘어가는 곳을 이어 붙임
        ok = ~np.isnan(a[:, c])
        if ok.any():
            a[ok, c] = np.degrees(np.unwrap(np.radians(a[ok, c])))
    return a


def plot_one(rows, spans, lifted, png_path):
    """한 실행의 루프 그림: 4행(각속도, 자세, 속도, 위치) x 3열, 맨 위에 요소와 게인 조의 띠."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch
    a = unwrap_yaw(np.array(rows, dtype=float))
    t = a[:, 0]
    fig = plt.figure(figsize=(15, 9.8))
    gs = fig.add_gridspec(5, 3, height_ratios=[0.16, 1, 1, 1, 1])
    x0, x1 = float(t[0]), float(t[-1])
    width = max(x1 - x0, 1e-6)
    strips = []
    for c in range(3):                                # 열마다 띠 하나 (아래 그림들과 시간 축이 같음)
        st = fig.add_subplot(gs[0, c])
        for ta, tb, name, tag in spans:               # 요소마다 걸린 시간과 그때의 게인 조
            st.axvspan(ta, tb, color=TAG_COLORS.get(tag, "0.6"), alpha=0.45, lw=0)
            st.axvline(tb, color="white", lw=1.0)
            if (tb - ta) / width > 0.05:
                st.text((ta + tb) / 2.0, 0.5, name, ha="center", va="center", fontsize=7.5)
        if not spans:
            st.text(0.5, 0.5, "no liftoff" if not lifted else "no referee record", transform=st.transAxes,
                    ha="center", va="center", fontsize=8, color="0.3")
        st.set_ylim(0, 1)
        st.set_yticks([])
        st.tick_params(labelbottom=False, length=0)
        st.set_xlim(x0, x1)
        strips.append(st)
    strips[0].set_ylabel("element", rotation=0, ha="right", va="center", fontsize=8)
    for k, (name, i_sp, i_act) in enumerate(PANELS):
        b = fig.add_subplot(gs[k // 3 + 1, k % 3], sharex=strips[k % 3])
        b.plot(t, a[:, i_act], color="tab:blue", lw=1.1)
        b.plot(t, a[:, i_sp], color="tab:red", lw=1.0, ls="--")
        for ta, tb, _, _ in spans:
            b.axvline(tb, color="0.55", lw=0.6, ls=":")
        b.set_title(name, fontsize=9)
        b.grid(alpha=0.3)
        b.tick_params(labelsize=8)
        if k % 3 == 0:
            b.set_ylabel(ROWS[k // 3] + " loop", fontsize=9)
        if k // 3 == 3:
            b.set_xlabel("time since liftoff (s)" if lifted else "time since start of logging (s)", fontsize=9)
        else:
            b.tick_params(labelbottom=False)
    handles = [Line2D([], [], color="tab:blue", lw=1.4), Line2D([], [], color="tab:red", lw=1.2, ls="--")]
    labels = ["actual", "setpoint"]
    for tag in ("cruise", "wind", "precision", "landing"):
        if any(s[3] == tag for s in spans):
            handles.append(Patch(color=TAG_COLORS[tag], alpha=0.45))
            labels.append("gain set: %s" % tag)
    fig.legend(handles, labels, loc="upper center", ncol=len(handles), frameon=False, fontsize=9.5, bbox_to_anchor=(0.5, 0.998))
    fig.tight_layout(rect=(0, 0, 1, 0.968))
    fig.savefig(png_path, dpi=110)
    plt.close(fig)


def element_start(spans, name):
    """요소가 차례가 된 시각 (그 요소 구간의 시작). 없으면 None."""
    for ta, tb, n, tag in spans:
        if n == name:
            return ta, tb
    return None


def plot_compare(runs, png_path, loop=None, element=None, t_from=None, t_to=None):
    """여러 실행을 겹쳐 그린다. runs = [(이름, 행 배열, 구간 목록)]. 실선 = 실제값, 점선 = 목표값, 색 = 실행."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.lines import Line2D
    rows_idx = [ROWS.index(loop)] if loop else [0, 1, 2, 3]
    shifted = []
    for name, a, spans in runs:
        a = unwrap_yaw(np.array(a, dtype=float))
        t0, dur = 0.0, None
        if element:
            se = element_start(spans, element)
            if se is None:
                print("%s: 요소 %s 의 구간이 없음 (그 요소에 닿지 못한 실행) · 이 실행은 그리지 않음" % (name, element))
                continue
            t0, dur = se[0], se[1] - se[0]
            # 0초 = 그 요소의 목표 위치가 실제로 바뀐 순간 (심판이 차례를 넘긴 시각과 실행 노드가 목표를 바꾼 시각은 조금 다름)
            i0 = int(np.searchsorted(a[:, 0], t0))
            if i0 < len(a):
                base = [a[i0, c] for c in (19, 21, 23)]
                for i in range(i0, len(a)):
                    if a[i, 0] > se[1]:
                        break
                    if any((not math.isnan(a[i, c])) and (not math.isnan(base[k])) and abs(a[i, c] - base[k]) > 0.2
                           for k, c in enumerate((19, 21, 23))):
                        dur -= a[i, 0] - t0
                        t0 = a[i, 0]
                        break
        t = a[:, 0] - t0
        shifted.append((name, t, a, dur))
    if not shifted:
        print("그릴 실행이 없음")
        return False
    lo = t_from if t_from is not None else (-1.0 if element else min(float(s[1][0]) for s in shifted))
    hi = t_to if t_to is not None else (max(s[3] for s in shifted) + 0.5 if element else max(float(s[1][-1]) for s in shifted))
    fig, ax = plt.subplots(len(rows_idx), 3, figsize=(15, 2.6 * len(rows_idx) + 1.2), sharex=True, squeeze=False)
    for ri, r in enumerate(rows_idx):
        for c in range(3):
            name, i_sp, i_act = PANELS[r * 3 + c]
            b = ax[ri][c]
            for k, (rn, t, a, dur) in enumerate(shifted):
                # 요소를 지정하면 실행마다 그 요소가 차례였던 동안만 그린다 (먼저 끝난 실행의 다음 요소가 섞이지 않게)
                m = (t >= lo) & (t <= (min(hi, dur + 0.2) if element else hi))
                col = RUN_COLORS[k % len(RUN_COLORS)]
                b.plot(t[m], a[m, i_act], color=col, lw=1.3)
                b.plot(t[m], a[m, i_sp], color=col, lw=0.9, ls="--", alpha=0.75)
            b.set_title(name, fontsize=9)
            b.grid(alpha=0.3)
            b.tick_params(labelsize=8)
            if c == 0:
                b.set_ylabel(ROWS[r] + " loop", fontsize=9)
            if ri == len(rows_idx) - 1:
                b.set_xlabel("time since the setpoint step of element %s (s)" % element if element else "time since liftoff (s)", fontsize=9)
    handles = [Line2D([], [], color=RUN_COLORS[k % len(RUN_COLORS)], lw=1.6) for k in range(len(shifted))]
    labels = [s[0] for s in shifted]
    handles += [Line2D([], [], color="0.3", lw=1.3), Line2D([], [], color="0.3", lw=0.9, ls="--")]
    labels += ["actual", "setpoint"]
    fig.legend(handles, labels, loc="upper center", ncol=len(handles), frameon=False, fontsize=9.5, bbox_to_anchor=(0.5, 0.995))
    fig.tight_layout(rect=(0, 0, 1, 1.0 - 0.42 / fig.get_size_inches()[1]))
    fig.savefig(png_path, dpi=110)
    plt.close(fig)
    return True


def main():
    ap = argparse.ArgumentParser(description="루프 기록으로 루프 그림을 그린다")
    ap.add_argument("folders", nargs="+", help="결과 폴더 (results/<이름>). 둘 이상이면 겹쳐 그림")
    ap.add_argument("--loop", choices=ROWS, default=None)
    ap.add_argument("--element", default=None)
    ap.add_argument("--from", dest="t_from", type=float, default=None)
    ap.add_argument("--to", dest="t_to", type=float, default=None)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    for d in a.folders:
        if not os.path.exists(os.path.join(d, "loops.csv")):
            print("루프 기록이 없음: %s" % os.path.join(d, "loops.csv"))
            return 1
    single = len(a.folders) == 1 and not (a.loop or a.element or a.t_from is not None or a.t_to is not None)
    if single:
        rows, spans, lifted = read_run(a.folders[0])
        out = a.out or os.path.join(a.folders[0], "plot_loops.png")
        plot_one(rows, spans, lifted, out)
    else:
        runs = []
        for d in a.folders:
            rows, spans, lifted = read_run(d)
            runs.append((os.path.basename(os.path.normpath(d)), rows, spans))
        out = a.out or os.path.join(a.folders[-1], "compare_loops.png")
        if not plot_compare(runs, out, a.loop, a.element, a.t_from, a.t_to):
            return 1
    print("저장: %s" % out)
    try:
        import subprocess
        w = subprocess.check_output(["wslpath", "-w", out], stderr=subprocess.DEVNULL).decode().strip()
        print('그림 보기: explorer.exe "%s"' % w)
    except Exception:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
