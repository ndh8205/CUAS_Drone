#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""코스 파일로 Gazebo 월드를 만든다. PX4 기본 empty.world 에 게이트·바람 구역 표시·착륙 마커를 더한다."""
import argparse
import math
import os
import sys

import yaml

BAR = 0.10                      # 게이트 틀 굵기 (m)
MARKER_BOARD_HALF = 0.7         # 마커 판(1.4 m)의 절반. 눕힌 뒤 무늬 중심은 모델 원점에서 -x 로 이만큼
MARKER_Z = 0.07                 # 아스팔트 윗면(0.05 m)보다 위
CAM_HFOV = 1.047                # 아래 방향 카메라의 수평 화각 (rad). 기체 모형(iris_base.sdf)의 값
CAM_COLS, CAM_ROWS = 320.0, 240.0
VIEW_MARGIN_M = 0.30            # 탐색 지점에서 표식 무늬가 화면 끝까지 남겨야 하는 여유 (m)
COLORS = {"cruise": "Gazebo/Red", "wind": "Gazebo/Orange", "precision": "Gazebo/Yellow", "landing": "Gazebo/Green"}


def box(name, size, pose, material, collide=True, transparency=None):
    col = ""
    if collide:
        col = "<collision name='%s_c'><pose>%s</pose><geometry><box><size>%s</size></box></geometry></collision>" % (name, pose, size)
    tr = "" if transparency is None else "<transparency>%.2f</transparency>" % transparency
    vis = ("<visual name='%s_v'><pose>%s</pose><geometry><box><size>%s</size></box></geometry>%s"
           "<material><script><uri>file://media/materials/scripts/gazebo.material</uri><name>%s</name></script></material></visual>") % (
               name, pose, size, tr, material)
    return col + vis


def gate_model(g):
    """게이트 틀. 충돌체는 두지 않는다(부딪히면 PX4 상태 추정이 크게 흔들려 제어 평가가 흐려짐). 통과 판정은 심판이 한다."""
    w, h, t = float(g["w"]), float(g["h"]), BAR
    yaw = math.radians(float(g.get("yaw_deg", 0.0)))
    mat = COLORS.get(g.get("tag", "cruise"), "Gazebo/Red")
    parts = [
        box("top", "%g %g %g" % (t, w + 2 * t, t), "0 0 %g 0 0 0" % (h / 2 + t / 2), mat, collide=False),
        box("bottom", "%g %g %g" % (t, w + 2 * t, t), "0 0 %g 0 0 0" % (-h / 2 - t / 2), mat, collide=False),
        box("left", "%g %g %g" % (t, t, h), "0 %g 0 0 0 0" % (w / 2 + t / 2), mat, collide=False),
        box("right", "%g %g %g" % (t, t, h), "0 %g 0 0 0 0" % (-w / 2 - t / 2), mat, collide=False),
    ]
    leg = float(g["z"]) - h / 2 - t
    if leg > 0.05:
        for side, y in (("legl", w / 2 + t / 2), ("legr", -w / 2 - t / 2)):
            parts.append(box(side, "%g %g %g" % (t, t, leg), "0 %g %g 0 0 0" % (y, -h / 2 - t - leg / 2), "Gazebo/Grey", collide=False))
    return ("<model name='gate_%s'><static>true</static><pose>%g %g %g 0 0 %g</pose><link name='link'>%s</link></model>" % (
        g["id"], g["x"], g["y"], g["z"], yaw, "".join(parts)))


def hold_model(hd):
    r = float(hd["radius"])
    vis = ("<visual name='v'><cast_shadows>false</cast_shadows><geometry><sphere><radius>%g</radius></sphere></geometry><transparency>0.55</transparency>"
           "<material><ambient>1 0.85 0 1</ambient><diffuse>1 0.85 0 1</diffuse><emissive>0.4 0.34 0 1</emissive></material></visual>") % r
    return "<model name='hold_%s'><static>true</static><pose>%g %g %g 0 0 0</pose><link name='link'>%s</link></model>" % (
        hd["id"], hd["x"], hd["y"], hd["z"], vis)


def wind_model(z):
    sx, sy, sz = z["xmax"] - z["xmin"], z["ymax"] - z["ymin"], z["zmax"] - z["zmin"]
    cx, cy, cz = (z["xmax"] + z["xmin"]) / 2.0, (z["ymax"] + z["ymin"]) / 2.0, (z["zmax"] + z["zmin"]) / 2.0
    part = ("<visual name='zone_v'><cast_shadows>false</cast_shadows><geometry><box><size>%g %g %g</size></box></geometry>"
            "<transparency>0.82</transparency><material><ambient>0.25 0.7 1 1</ambient><diffuse>0.25 0.7 1 1</diffuse>"
            "<emissive>0.1 0.3 0.45 1</emissive></material></visual>") % (sx, sy, sz)
    return "<model name='wind_%s'><static>true</static><pose>%g %g %g 0 0 0</pose><link name='link'>%s</link></model>" % (z["id"], cx, cy, cz, part)


def marker_include(landing):
    m = landing["marker"]
    return ("<include><uri>model://%s</uri><name>pad_marker</name><pose>%g %g %g 0 -1.5707963 0</pose></include>" % (
        m["model"], m["x"] + MARKER_BOARD_HALF, m["y"], MARKER_Z))        # 판을 눕힘 (무늬가 위를 봄)


def marker_view_margin(course):
    """탐색 지점에 멈춘 기체의 아래 방향 카메라 화면에서 표식 무늬가 화면 끝까지 남기는 여유 (앞뒤, 좌우. m).

    음수이면 무늬가 화면 밖으로 잘린다. 표식 무늬는 월드 축과 나란하게 놓인다.
    기수 방향(landing.yaw_deg)이 없으면 실행 노드가 90도 단위 방향을 고르므로 불리한 쪽(큰 어긋남이 화면의 짧은 쪽)으로 본다.
    """
    ld = course["landing"]
    s, m = ld["search"], ld["marker"]
    h = float(s["z"]) - float(ld.get("pad_top_z", 0.0))
    half_lr = h * math.tan(CAM_HFOV / 2.0)             # 화면 좌우 절반 = 기체 좌우
    half_fb = half_lr * CAM_ROWS / CAM_COLS            # 화면 위아래 절반 = 기체 앞뒤
    dx, dy = float(m["x"]) - float(s["x"]), float(m["y"]) - float(s["y"])
    half_p = float(m["pattern_size"]) / 2.0
    if ld.get("yaw_deg") is None:
        fwd, left = max(abs(dx), abs(dy)), min(abs(dx), abs(dy))
    else:
        yaw = math.radians(float(ld["yaw_deg"]))
        fwd = abs(dx * math.cos(yaw) + dy * math.sin(yaw))
        left = abs(-dx * math.sin(yaw) + dy * math.cos(yaw))
        half_p *= abs(math.cos(yaw)) + abs(math.sin(yaw))
    return half_fb - fwd - half_p, half_lr - left - half_p


def gui_block(course, follow):
    """Gazebo 화면의 처음 시점. 코스 파일의 gui_view(pos, look)로 코스 전경을 보게 하고, follow 면 기체를 따라간다."""
    if follow:
        return ("<gui fullscreen='0'><camera name='user_camera'><pose>-4 -2.5 2.2 0 0.3 0.55</pose>"
                "<track_visual><name>iris</name><min_dist>3.0</min_dist><max_dist>4.5</max_dist></track_visual></camera></gui>")
    v = course.get("gui_view")
    if not v:
        return ""
    p, t = v["pos"], v["look"]
    dx, dy, dz = t[0] - p[0], t[1] - p[1], t[2] - p[2]
    yaw = math.atan2(dy, dx)
    pitch = math.atan2(-dz, math.hypot(dx, dy))
    return "<gui fullscreen='0'><camera name='user_camera'><pose>%g %g %g 0 %g %g</pose></camera></gui>" % (p[0], p[1], p[2], pitch, yaw)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--course", required=True)
    ap.add_argument("--base-world", required=True, help="PX4 empty.world 경로")
    ap.add_argument("--out", required=True)
    ap.add_argument("--no-zone-visual", action="store_true")
    ap.add_argument("--gui-view", action="store_true", help="Gazebo 화면의 처음 시점을 코스 전경으로 (화면을 띄울 때만)")
    ap.add_argument("--follow", action="store_true", help="Gazebo 화면이 기체를 따라감")
    a = ap.parse_args()
    with open(a.course, encoding="utf-8") as f:
        course = yaml.safe_load(f)
    with open(a.base_world, encoding="utf-8") as f:
        world = f.read()
    extra = []
    for item in course["sequence"]:
        if item["type"] == "gate":
            extra.append(gate_model(item))
        elif item["type"] == "hold":
            extra.append(hold_model(item))
    if not a.no_zone_visual:
        for z in course.get("wind_zones", []):
            extra.append(wind_model(z))
    if course.get("landing"):                         # 조절용 코스에는 착륙 표식이 없음
        extra.append(marker_include(course["landing"]))
    if a.gui_view or a.follow:
        g = gui_block(course, a.follow)
        if g:
            extra.append(g)
    idx = world.rfind("</world>")
    if idx < 0:
        print("base world 에 </world> 가 없음")
        return 1
    out = world[:idx] + "\n    <!-- race course: %s -->\n    " % course["name"] + "\n    ".join(extra) + "\n  " + world[idx:]
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        f.write(out)
    print("코스 월드 저장: %s (게이트 %d개 · 바람 구역 %d개)" % (
        a.out, sum(1 for i in course["sequence"] if i["type"] == "gate"), len(course.get("wind_zones", []) or [])))
    mfb, mlr = marker_view_margin(course) if course.get("landing") else (9.0, 9.0)
    if min(mfb, mlr) < VIEW_MARGIN_M:      # 코스를 고칠 때의 점검 (배포한 코스에서는 나오지 않음)
        print("[주의] 탐색 지점에서 착륙 표식이 카메라 화면 끝에 가까움 (앞뒤 여유 %.2f m · 좌우 여유 %.2f m · 기준 %.2f m). "
              "탐색 지점을 표식 쪽으로 옮기거나 탐색 높이를 올릴 것" % (mfb, mlr, VIEW_MARGIN_M))
    return 0


if __name__ == "__main__":
    sys.exit(main())
