#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""아래 방향 카메라 화면을 창으로 보여 준다 (race.sh --gui 일 때만 실행. 채점과 무관).

화면 가운데 십자 = 기체 바로 아래 방향. 착륙 표식을 찾으면 테두리와 중심을 그리고,
착륙 구간에서는 실행 노드가 계산한 높이와 수평 거리를 함께 적는다.
"""
import json
import os
import sys
import threading
import time

# 창은 Gazebo 와 같은 화면(DISPLAY, X11)에 띄운다. 이 설정이 없으면 창 도구(GTK)가 다른 그래픽 연결을 먼저 시도하다
# 수십 초 뒤에야 창이 뜨는 경우가 있다 (cv2 를 불러오기 전에 정해야 함).
os.environ.setdefault("GDK_BACKEND", "x11")
os.environ.setdefault("NO_AT_BRIDGE", "1")

import cv2
import numpy as np
import rospy
from sensor_msgs.msg import CompressedImage
from std_msgs.msg import String

SCALE = 2
WIN = "Drone View"


def main():
    rospy.init_node("race_cam_view", anonymous=True)
    lock = threading.Lock()
    st = {"jpg": None, "n": 0, "vis": None, "vis_t": 0.0, "race": {}}
    dic = cv2.aruco.Dictionary_get(cv2.aruco.DICT_4X4_1000)
    par = cv2.aruco.DetectorParameters_create()
    t_start = time.time()

    def on_img(msg):                      # 받은 JPEG 은 그대로 두고 그리는 쪽에서 푼다 (받는 쪽을 가볍게)
        with lock:
            st["jpg"] = msg.data
            st["n"] += 1
            if st["n"] == 1:
                print("first image after %.1f s" % (time.time() - t_start), flush=True)

    def on_vis(msg):
        try:
            st["vis"] = json.loads(msg.data)
            st["vis_t"] = time.time()
        except ValueError:
            pass

    def on_race(msg):
        try:
            st["race"] = json.loads(msg.data)
        except ValueError:
            pass

    rospy.Subscriber("/iris/usb_cam/image_raw/compressed", CompressedImage, on_img, queue_size=1, buff_size=2 ** 22)
    rospy.Subscriber("/race/vision", String, on_vis, queue_size=5)
    rospy.Subscriber("/race/state", String, on_race, queue_size=20)
    print("subscribed after %.1f s" % (time.time() - t_start), flush=True)
    pos = os.environ.get("RACE_CAMVIEW_POS", "60,60").split(",")      # 창 위치 "x,y" (기본 60,60)
    green, yellow = (0, 255, 0), (0, 220, 255)
    shown = False
    blank = np.full((240 * SCALE, 320 * SCALE, 3), 60, np.uint8)
    cv2.putText(blank, "waiting for the camera image", (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, green, 2)
    while not rospy.is_shutdown():
        with lock:
            jpg = st["jpg"]
        if jpg is None:
            view = blank.copy()
        else:
            img = cv2.imdecode(np.frombuffer(jpg, np.uint8), cv2.IMREAD_COLOR)
            if img is None:
                view = blank.copy()
            else:
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                corners, ids, _ = cv2.aruco.detectMarkers(gray, dic, parameters=par)
                view = cv2.resize(img, None, fx=SCALE, fy=SCALE, interpolation=cv2.INTER_LINEAR)
                h, w = view.shape[:2]
                cv2.line(view, (w // 2 - 22, h // 2), (w // 2 + 22, h // 2), green, 2)
                cv2.line(view, (w // 2, h // 2 - 22), (w // 2, h // 2 + 22), green, 2)
                if ids is not None:
                    for c, i in zip(corners, ids.flatten()):
                        pts = (c[0] * SCALE).astype(np.int32)
                        cv2.polylines(view, [pts], True, yellow, 2)
                        u, v = pts.mean(axis=0).astype(int)
                        cv2.circle(view, (int(u), int(v)), 5, yellow, -1)
                        cv2.putText(view, "id %d" % int(i), (int(pts[:, 0].min()), max(int(pts[:, 1].min()) - 8, 16)),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, yellow, 2)
        r = st["race"]
        hh = view.shape[0]
        line1 = "%s %s %s" % (r.get("phase", ""), r.get("item", ""), r.get("sub", ""))
        cv2.putText(view, line1.strip(), (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.65, green, 2)
        cv2.putText(view, "gain set: %s" % r.get("tag", ""), (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.65, green, 2)
        v = st["vis"]
        if v is not None and time.time() - st["vis_t"] < 1.0:
            cv2.putText(view, "height %.2f m   offset %.2f m" % (v["h"], float(np.hypot(v["dx"], v["dy"]))), (10, hh - 14),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.65, green, 2)
        cv2.imshow(WIN, view)
        if not shown:
            shown = True
            try:
                cv2.moveWindow(WIN, int(pos[0]), int(pos[1]))
            except (cv2.error, ValueError, IndexError):
                pass
            print("window shown after %.1f s" % (time.time() - t_start), flush=True)
        cv2.waitKey(60)
    return 0


if __name__ == "__main__":
    sys.exit(main())
