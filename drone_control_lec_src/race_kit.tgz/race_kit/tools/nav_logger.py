#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""항법 점검용 기록 도구 (채점과 무관, 키트 점검용).

Gazebo 참값, PX4 추정 위치, GPS 원시값, 기압 고도를 같은 시각에 적어 추정 오차를 본다.
실행: RACE_NAVLOG=1 ./race.sh ...  ->  results/<이름>/nav.csv
"""
import argparse
import csv
import math
import os
import sys

import rospy
from gazebo_msgs.msg import ModelStates
from geometry_msgs.msg import PoseStamped
from mavros_msgs.msg import Altitude
from sensor_msgs.msg import CompressedImage, NavSatFix
from std_msgs.msg import String

R_EARTH = 6378137.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--rate", type=float, default=10.0)
    ap.add_argument("--cam-dir", default="", help="아래 방향 카메라 영상을 1초마다 저장할 폴더")
    a = ap.parse_args(rospy.myargv()[1:])
    rospy.init_node("race_navlog")
    s = {"truth": None, "ekf": None, "gps": None, "alt": None}

    def on_models(msg):
        try:
            i = msg.name.index("iris")
        except ValueError:
            return
        p = msg.pose[i].position
        s["truth"] = (p.x, p.y, p.z)

    def on_pose(msg):
        p = msg.pose.position
        s["ekf"] = (p.x, p.y, p.z)

    def on_fix(msg):
        s["gps"] = (msg.latitude, msg.longitude, msg.altitude)

    def on_alt(msg):
        s["alt"] = (msg.monotonic, msg.local, msg.relative)

    rospy.Subscriber("/gazebo/model_states", ModelStates, on_models, queue_size=1)
    rospy.Subscriber("/mavros/local_position/pose", PoseStamped, on_pose, queue_size=5)
    rospy.Subscriber("/mavros/global_position/raw/fix", NavSatFix, on_fix, queue_size=5)
    rospy.Subscriber("/mavros/altitude", Altitude, on_alt, queue_size=5)
    vis_f = open(a.out.replace(".csv", "") + "_vision.jsonl", "w")

    def on_vis(msg):
        t = s["truth"]
        vis_f.write(msg.data[:-1] + (', "tx": %.3f, "ty": %.3f, "tz": %.3f}' % (t[0], t[1], t[2]) if t else "}") + "\n")

    rospy.Subscriber("/race/vision", String, on_vis, queue_size=50)
    cam = {"t": -1e9}

    def on_cam(msg):
        now = rospy.get_time()
        if now - cam["t"] < 1.0:
            return
        cam["t"] = now
        with open(os.path.join(a.cam_dir, "cam_%07.2f.jpg" % now), "wb") as cf:
            cf.write(msg.data)

    if a.cam_dir:
        os.makedirs(a.cam_dir, exist_ok=True)
        rospy.Subscriber("/iris/usb_cam/image_raw/compressed", CompressedImage, on_cam, queue_size=1, buff_size=2 ** 22)
    rate = rospy.Rate(a.rate)
    ref = {}
    with open(a.out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["t", "tx", "ty", "tz", "ex", "ey", "ez", "gx", "gy", "gz", "baro", "alt_local", "alt_rel"])
        n = 0
        while not rospy.is_shutdown():
            try:
                rate.sleep()
            except rospy.ROSInterruptException:
                break
            if s["truth"] is None or s["ekf"] is None:
                continue
            if "truth" not in ref:                       # 첫 표본을 원점으로 (모두 출발점 기준 변위로 적음)
                ref["truth"] = s["truth"]
                ref["ekf"] = s["ekf"]
            row = [round(rospy.get_time(), 3)]
            row += [round(s["truth"][i] - ref["truth"][i], 4) for i in range(3)]
            row += [round(s["ekf"][i] - ref["ekf"][i], 4) for i in range(3)]
            if s["gps"] is not None:
                if "gps" not in ref:
                    ref["gps"] = s["gps"]
                    ref["gps_truth"] = [s["truth"][i] - ref["truth"][i] for i in range(3)]
                lat0, lon0, alt0 = ref["gps"]
                gy = math.radians(s["gps"][0] - lat0) * R_EARTH
                gx = math.radians(s["gps"][1] - lon0) * R_EARTH * math.cos(math.radians(lat0))
                gz = s["gps"][2] - alt0
                row += [round(gx + ref["gps_truth"][0], 4), round(gy + ref["gps_truth"][1], 4), round(gz + ref["gps_truth"][2], 4)]
            else:
                row += ["", "", ""]
            if s["alt"] is not None:
                if "baro" not in ref:
                    ref["baro"] = s["alt"][0]
                    ref["baro_truth"] = s["truth"][2] - ref["truth"][2]
                row += [round(s["alt"][0] - ref["baro"] + ref["baro_truth"], 4), round(s["alt"][1], 4), round(s["alt"][2], 4)]
            else:
                row += ["", "", ""]
            w.writerow(row)
            n += 1
            if n % 50 == 0:
                f.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
