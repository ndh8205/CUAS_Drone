#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""설계 파일과 게인 파일의 형식을 실행 전에 점검한다 (race.sh 가 시뮬레이터를 켜기 전에 부름).

사용: check_inputs.py --design 파일 --gains 파일      (설계 파일과 게인 파일의 형식)
      check_inputs.py --runner 파일                  (내 실행 노드의 문법)
형식이 맞으면 0, 아니면 고칠 곳을 알려 주고 1 로 끝난다.
부품표에 없는 값은 기체 만들기 단계가, 범위 밖 게인과 표에 없는 이름은 실행 노드가 따로 알린다.
"""
import argparse
import ast
import os
import sys

import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
TAGS = ("cruise", "wind", "precision", "landing")
HEAD = "입력 파일 오류"


def allowed_table():
    """실행 노드(nodes/race_runner.py)의 게인 표 {이름: (최소, 최대)} 를 읽는다. 표가 한 곳에만 있도록 소스에서 직접 읽는다."""
    p = os.path.join(HERE, "..", "nodes", "race_runner.py")
    try:
        with open(p, encoding="utf-8") as f:
            tree = ast.parse(f.read())
        for node in tree.body:
            if isinstance(node, ast.Assign) and any(getattr(t, "id", "") == "ALLOWED" for t in node.targets):
                return dict(ast.literal_eval(node.value))
    except (OSError, SyntaxError, ValueError):
        pass
    return {}


def allowed_names():
    return list(allowed_table().keys())


def is_number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def load(path, what, errors):
    """파일을 읽어 돌려준다. 문제가 있으면 errors 에 설명을 넣고 None."""
    if not path or not os.path.isfile(path):
        errors.append("%s 파일이 없음: %s" % (what, path or "(이름 없음)"))
        return None
    with open(path, encoding="utf-8", errors="replace") as f:
        text = f.read()
    lines = text.split("\n")
    for n, ln in enumerate(lines, 1):
        if "\t" in ln[:len(ln) - len(ln.lstrip())]:
            errors.append("%s 파일 %d번째 줄의 들여쓰기에 탭 문자가 있음 · 빈칸으로 바꿀 것\n    %3d: %s" % (what, n, n, ln.replace("\t", "<탭>")))
            return None
    try:
        return yaml.safe_load(text)
    except yaml.YAMLError as e:
        mark = getattr(e, "problem_mark", None)
        n = (mark.line + 1) if mark is not None else None
        msg = "%s 파일의 형식이 맞지 않음: %s" % (what, path)
        if n:
            msg += "\n  %d번째 줄 근처" % n
            for k in range(max(1, n - 1), min(len(lines), n + 1) + 1):
                msg += "\n    %3d: %s" % (k, lines[k - 1])
        msg += ("\n  확인할 것"
                "\n   - 들여쓰기는 빈칸 · 같은 묶음의 줄은 같은 칸에서 시작"
                "\n   - 이름 뒤에는 쌍점과 빈칸 한 칸 (예: MPC_XY_P: 0.6)"
                "\n   - 구간의 값은 {} 를 지우고 아래 줄에 기록")
        errors.append(msg)
        return None


def check_gains(g, errors, notes):
    if not isinstance(g, dict):
        errors.append("게인 파일 맨 위에는 base: 와 schedule: 이 있어야 함")
        return
    extra = [str(k) for k in g if k not in ("base", "schedule")]
    if extra:
        errors.append("게인 파일 맨 위에 모르는 이름: %s  (base 와 schedule 만 가능 · 게인은 그 아래에 들여쓰기 뒤 기록)" % "  ".join(extra))
    base = g.get("base")
    if base is None:
        errors.append("게인 파일에 base: 가 없음")
        base = {}
    elif not isinstance(base, dict):
        errors.append("base: 아래에는 '이름: 값' 줄이 와야 함 (지금 값: %r)" % (base,))
        base = {}
    sched = g.get("schedule")
    if sched is None:
        sched = {}
    elif not isinstance(sched, dict):
        errors.append("schedule: 아래에는 구간 이름(cruise · wind · precision · landing)이 와야 함 (지금 값: %r)" % (sched,))
        sched = {}
    groups = [("base", base)]
    for tag, val in sched.items():
        if val is None:
            continue
        if not isinstance(val, dict):
            errors.append("schedule 의 %s: 아래에는 '이름: 값' 줄이 와야 함 (지금 값: %r)" % (tag, val))
            continue
        groups.append((str(tag), val))
    for where, d in groups:
        for k, v in d.items():
            if not is_number(v):
                errors.append("숫자가 아닌 값: %s 의 %s = %r  (소수점은 마침표 · 값은 하나만)" % (where, k, v))
    table = allowed_table()
    if table and isinstance(g.get("base"), dict):
        missing = [n for n in table if n not in base]
        if missing:
            notes.append("[참고] base 에 없는 게인 %d개 = 허용 범위의 최솟값으로 적용: %s" % (len(missing), "  ".join(missing)))
        if untuned(g, table):
            notes.append("[안내] 게인이 모두 제공 값(허용 범위의 최솟값) 그대로 · 이 값으로는 이륙하지 못함 · 게인 조절이 먼저")


def untuned(g, table=None):
    """게인이 하나도 조절되지 않았는지 본다: base 의 값이 모두 허용 범위의 최솟값 이하이고 구간별 값이 없음."""
    table = table or allowed_table()
    if not table or not isinstance(g, dict):
        return False
    base = g.get("base") if isinstance(g.get("base"), dict) else {}
    sched = g.get("schedule") if isinstance(g.get("schedule"), dict) else {}
    if any(isinstance(v, dict) and any(k in table for k in v) for v in sched.values()):
        return False
    for k, (lo, hi) in table.items():
        v = base.get(k, lo)
        if not is_number(v) or float(v) > lo + 1e-9:
            return False
    return True


def check_runner(path, errors):
    """내 실행 노드의 문법을 본다 (실행하지 않고 읽기만 함)."""
    if not path or not os.path.isfile(path):
        errors.append("실행 노드 파일이 없음: %s" % (path or "(이름 없음)"))
        return
    with open(path, encoding="utf-8", errors="replace") as f:
        src = f.read()
    try:
        compile(src, path, "exec")
    except SyntaxError as e:
        line = (e.text or "").rstrip()
        errors.append("실행 노드의 문법 오류: %s\n  %s번째 줄: %s\n    %s" % (path, e.lineno, e.msg, line))


def check_design(d, errors):
    if not isinstance(d, dict):
        errors.append("설계 파일에는 frame · motor · prop_in · battery 줄이 있어야 함")
        return
    for k in ("frame", "motor", "prop_in", "battery"):
        if d.get(k) is None:
            errors.append("설계 파일에 빠진 항목: %s" % k)
    b = d.get("battery")
    if b is not None and not isinstance(b, dict):
        errors.append("battery: 아래에는 chemistry · cells · capacity_mah 줄이 와야 함 (지금 값: %r)" % (b,))
    elif isinstance(b, dict):
        for k in ("chemistry", "cells", "capacity_mah"):
            if b.get(k) is None:
                errors.append("설계 파일에 빠진 항목: battery 의 %s" % k)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--design", default="")
    ap.add_argument("--gains", default="")
    ap.add_argument("--runner", default="")
    a = ap.parse_args()
    errors, notes = [], []
    if a.runner:
        check_runner(a.runner, errors)
        if errors:
            print("%s (%d건) · 고친 뒤 다시 실행" % (HEAD, len(errors)))
            for e in errors:
                print(" - " + e)
            return 1
        return 0
    d = load(a.design, "설계", errors)
    n_d = len(errors)
    if d is not None or n_d == 0:
        check_design(d, errors)
    n_g = len(errors)
    g = load(a.gains, "게인", errors)
    if g is not None or len(errors) == n_g:
        check_gains(g, errors, notes)
    for n in notes:
        print(n)
    if errors:
        print("%s (%d건) · 고친 뒤 다시 실행" % (HEAD, len(errors)))
        for e in errors:
            print(" - " + e)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
