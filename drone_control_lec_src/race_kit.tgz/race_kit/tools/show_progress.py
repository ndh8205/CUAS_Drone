#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""실행 노드 로그를 읽어 진행 상황을 한 줄씩 보여 준다 (race.sh 가 씀)."""
import json
import sys

LAND = {"search": "착륙 표식 찾는 중", "align": "표식 위로 정렬 중", "descend": "정렬 완료 → 하강", "final": "PX4 자동 착륙으로 넘김",
        "no_marker": "표식을 찾지 못함 → 그 자리에 착륙", "land_timeout": "정렬 시간 초과 → 그 자리에 착륙"}
TAGS = {"cruise": "일반", "wind": "바람", "precision": "제자리 유지", "landing": "착륙"}


def main():
    t0 = None
    for line in sys.stdin:
        i = line.find("GAINS_CHECK ")
        if i >= 0:
            try:
                d = json.loads(line[i + 12:])
            except ValueError:
                continue
            if d.get("ignored"):
                print("  [주의] 표에 없는 이름 · 적용하지 않음: %s" % "  ".join(d["ignored"]))
            if d.get("clamped"):
                print("  [주의] 범위 밖 값 · 범위 끝값으로 적용: %s" % "  ".join(d["clamped"]))
            if d.get("unknown_tags"):
                print("  [주의] 없는 구간 이름 · 적용하지 않음: %s" % "  ".join(d["unknown_tags"]))
            sys.stdout.flush()
            continue
        i = line.find("GAINS tag=")
        if i >= 0:
            rest = line[i + 10:].strip()
            tag, _, ch = rest.partition(" changed=")
            try:
                n = len(json.loads(ch))
            except ValueError:
                n = 0
            if t0 is not None:
                print("           게인 조 -> %s (%s) · 바뀐 값 %d개" % (tag, TAGS.get(tag, tag), n))
            sys.stdout.flush()
            continue
        i = line.find("RACE {")
        if i < 0:
            continue
        try:
            d = json.loads(line[i + 5:])
        except ValueError:
            continue
        ph, item, sub = d.get("phase", ""), d.get("item", ""), d.get("sub", "")
        if ph == "TAKEOFF":
            t0 = d["t"]
        t = d["t"] - (t0 if t0 is not None else d["t"])
        msg = None
        if ph == "TAKEOFF":
            msg = "이륙 (기록 시작)"
        elif ph == "GATE_DONE":
            msg = "게이트 %s %s" % (item, "지남" if sub == "passed" else "시간 초과로 건너뜀")
        elif ph == "HOLD":
            msg = "제자리 유지 %s 시작" % item
        elif ph == "HOLD_DONE":
            msg = "제자리 유지 %s %s" % (item, "성공" if sub == "ok" else "실패(시간 초과)")
        elif ph == "LAND":
            msg = LAND.get(sub, sub)
        elif ph == "DONE":
            msg = "끝"
        elif ph == "TIMEOUT":
            msg = "코스 제한 시간 초과"
        elif ph == "ABORT":
            msg = "시작 실패 (%s)" % sub
        if msg:
            print("  [%6.1f s] %s" % (t, msg))
            sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
