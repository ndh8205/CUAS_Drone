#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""심판 로그와 실행 노드 로그를 읽어 진행 상황을 한 줄씩 보여 준다 (race.sh 가 씀).

- 이륙, 게이트, 제자리 유지, 접지, 완주 실패 = 심판이 참값으로 적은 EVENT 줄 (실행 노드를 바꿔도 그대로 나옴)
- 게인 전환, 착륙 단계, 시작 실패           = 실행 노드가 적은 줄
"""
import json
import sys

LAND = {"align": "표식 위로 정렬 중", "descend": "정렬 완료 · 하강 시작", "final": "PX4 자동 착륙으로 넘김",
        "no_marker": "표식을 찾지 못해 그 자리에 착륙", "land_timeout": "정렬 시간 초과로 그 자리에 착륙"}
TAGS = {"cruise": "일반", "wind": "바람", "precision": "제자리 유지", "landing": "착륙"}
GATE = {"passed": "통과", "missed": "놓침 (열린 면 밖으로 지남)", "skipped": "놓침 (지나지 않고 다음 요소로 감)",
        "timeout": "놓침 (제한 시간 안에 지나지 못함)"}
HOLD = {"ok": "성공", "fail": "실패 (제한 시간 안에 머물지 못함)", "skipped": "실패 (머물지 않고 다음 요소로 감)"}
ABORT = {"no_liftoff": "이륙하지 못함 (20초 안에 뜨지 않음)", "arming_failed": "시동 실패"}


def referee_line(d):
    ph, item, sub = d.get("phase", ""), d.get("item", ""), d.get("sub", "")
    if ph == "TAKEOFF":
        return "이륙 (기록 시작)"
    if ph == "GATE_DONE":
        return "게이트 %s %s" % (item, GATE.get(sub, sub))
    if ph == "HOLD":
        return "제자리 유지 %s 시작" % item
    if ph == "HOLD_DONE":
        return "제자리 유지 %s %s" % (item, HOLD.get(sub, sub))
    if ph == "LAND":
        return "착륙 구간 시작"
    if ph == "DONE":
        return "접지 (기록 끝)"
    if ph == "DNF":
        return "완주 실패: %s" % sub
    return None


def main():
    t0 = None
    for line in sys.stdin:
        i = line.find("GAINS_CHECK ")
        if i >= 0:
            try:
                d = json.loads(line[i + 12:])
            except ValueError:
                continue
            if d.get("ignored"):
                print("  [주의] 표에 없는 이름 · 적용하지 않음: %s" % "  ".join(d["ignored"]))
            if d.get("clamped"):
                print("  [주의] 범위 밖 값 · 범위 끝값으로 적용: %s" % "  ".join(d["clamped"]))
            if d.get("unknown_tags"):
                print("  [주의] 없는 구간 이름 · 적용하지 않음: %s" % "  ".join(d["unknown_tags"]))
            sys.stdout.flush()
            continue
        i = line.find("GAINS tag=")
        if i >= 0:
            rest = line[i + 10:].strip()
            tag, _, ch = rest.partition(" changed=")
            try:
                n = len(json.loads(ch))
            except ValueError:
                n = 0
            if t0 is not None:
                print("           게인 전환 -> %s (%s) · 바뀐 값 %d개" % (tag, TAGS.get(tag, tag), n))
            sys.stdout.flush()
            continue
        msg = None
        i = line.find("EVENT {")
        if i >= 0:                                    # 심판
            try:
                d = json.loads(line[i + 6:])
            except ValueError:
                continue
            if d.get("phase") == "TAKEOFF":
                t0 = d["t"]
            msg = referee_line(d)
        else:                                         # 실행 노드
            i = line.find("RACE {")
            if i < 0:
                continue
            try:
                d = json.loads(line[i + 5:])
            except ValueError:
                continue
            ph, sub = d.get("phase", ""), d.get("sub", "")
            if ph == "LAND" and sub in LAND:
                msg = LAND[sub]
            elif ph == "ABORT":
                msg = ABORT.get(sub, "시작 실패 (%s)" % sub)
        if msg:
            t = d["t"] - (t0 if t0 is not None else d["t"])
            print("  [%6.1f s] %s" % (t, msg))
            sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
