#!/bin/bash
# 레이스 키트 환경 점검. 새 터미널에서 실행:  ./check_env.sh
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FAIL=0
ok()   { echo "  [정상] $1"; }
bad()  { echo "  [문제] $1"; FAIL=1; }
note() { echo "  [참고] $1"; }

echo "1. 운영체제"
. /etc/os-release 2>/dev/null
if [ "$VERSION_ID" = "20.04" ]; then ok "Ubuntu 20.04"; else bad "Ubuntu $VERSION_ID (수업 환경은 20.04)"; fi

echo "2. ROS 와 PX4"
if [ "$ROS_DISTRO" = "noetic" ]; then ok "ROS noetic"; else bad "ROS 환경이 잡히지 않음 (~/.bashrc 의 source 줄 확인, 새 터미널에서 다시 실행)"; fi
for pkg in px4 mavros mavlink_sitl_gazebo; do
  if p=$(rospack find $pkg 2>/dev/null); then ok "$pkg: $p"; else bad "ROS 패키지 $pkg 를 찾지 못함"; fi
done
if p=$(rospack find px4 2>/dev/null); then
  v=$(cd "$p" && git rev-parse --short=8 HEAD 2>/dev/null)
  if [ "$v" = "45e8712d" ]; then ok "PX4 판 $v (수업 기준)"; else note "PX4 판 $v (수업 기준은 45e8712d, 다르면 결과가 달라질 수 있음)"; fi
fi
if [ -f "$(rospack find px4 2>/dev/null)/launch/mavros_posix_sitl.launch" ]; then ok "mavros_posix_sitl.launch"; else bad "mavros_posix_sitl.launch 없음"; fi

echo "3. 파이썬 모듈"
python3 - <<'PY'
import sys
bad = 0
try:
    import cv2
    cv2.aruco.Dictionary_get(cv2.aruco.DICT_4X4_1000)
    print("  [정상] OpenCV %s + aruco" % cv2.__version__)
except Exception as e:
    print("  [문제] OpenCV aruco 를 쓸 수 없음: %s" % e); bad = 1
for m in ("yaml", "numpy", "matplotlib", "rospy"):
    try:
        __import__(m)
        print("  [정상] %s" % m)
    except Exception as e:
        print("  [문제] %s 없음: %s" % (m, e)); bad = 1
sys.exit(bad)
PY
[ $? -eq 0 ] || FAIL=1

echo "4. 시계 (12초 측정)"
python3 - <<'PY'
import time
t0, m0 = time.time(), time.monotonic()
worst = 0.0
for _ in range(120):
    time.sleep(0.1)
    worst = max(worst, abs((time.time() - t0) - (time.monotonic() - m0)))
if worst > 0.2:
    print("  [문제] 시계가 %.1f초 튐. 시뮬레이션이 끊기거나 멈출 수 있음" % worst)
    print("         해결: sudo systemctl disable --now systemd-timesyncd  (그 뒤 wsl --shutdown 하고 다시 열기)")
else:
    print("  [정상] 시계 튐 없음 (최대 %.3f초)" % worst)
PY
if systemctl is-active --quiet systemd-timesyncd 2>/dev/null; then
  note "systemd-timesyncd 가 켜져 있음. 시뮬레이션 시간이 튀면 위 해결 명령으로 끌 것"
fi

echo "5. 가상 화면 (화면 없이 실행할 때 카메라 영상용)"
if command -v Xvfb >/dev/null 2>&1; then ok "Xvfb 있음"; else bad "Xvfb 없음. 설치: sudo apt install -y xvfb"; fi

echo "6. 키트 파일"
for f in race.sh design/build_vehicle.py design/catalog.yaml design/iris_base.sdf design/my_design.yaml gains/my_gains.yaml \
         courses/practice.yaml courses/tune.yaml nodes/race_runner.py nodes/referee.py nodes/wind_node.py nodes/loop_logger.py \
         tools/make_world.py tools/cam_view.py tools/check_inputs.py tools/plot_loops.py examples/hover_node.py \
         models/race_gps/race_gps.sdf models/race_pad_51/model.sdf; do
  [ -f "$KIT/$f" ] || bad "파일 없음: $f"
done
[ $FAIL -eq 0 ] && ok "필수 파일 있음"

echo "7. 기체 생성 시험 (my_design.yaml)"
chk=$(python3 "$KIT/tools/check_inputs.py" --design "$KIT/design/my_design.yaml" --gains "$KIT/gains/my_gains.yaml" 2>&1); crc=$?
[ -n "$chk" ] && echo "$chk" | sed 's/^/    /'
if [ $crc -ne 0 ]; then
  bad "설계 파일 또는 게인 파일의 형식 오류 (위 내용 확인)"
else
  out=$(python3 "$KIT/design/build_vehicle.py" --design "$KIT/design/my_design.yaml" --report-only); rc=$?
  echo "$out" | sed 's/^/    /'
  if [ $rc -eq 0 ]; then
    ok "설계가 조건을 만족함"
  else
    bad "설계가 조건을 만족하지 않음 (위 '제작 불가' 항목 확인)"
  fi
fi

echo
if [ $FAIL -eq 0 ]; then echo "점검 통과. 다음 단계: ./race.sh tune 으로 조절용 시험 비행"; else echo "문제 항목을 먼저 해결할 것"; fi
exit $FAIL
