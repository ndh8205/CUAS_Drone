#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""설계 파일(my_design.yaml)로 레이스 기체를 만든다.

출력(build/): iris_race.sdf (Gazebo 기체), vehicle.yaml (계산 값), px4_params.yaml (PX4 기체 파라미터),
              design_report.txt (설계 요약)

모형 요약
- 프로펠러: 추력 T = k_T w^2, 토크 Q = c_Q w^2  (k_T = C_T rho D^4 / 4pi^2, c_Q = C_P rho D^5 / 8pi^3)
- 모터: 단자 전압 V = w / K_V + R I,  전류 I = Q / K_t + I_0,  K_t = 1 / K_V (SI 단위)
- 배터리: 단자 전압 = 셀 수 x 시작 전압 - 내부 저항 x 총 전류,  전류 한도 = 방전율 x 용량
- 최대 회전수 = 전압 한계와 전류 한계 중 작은 쪽. 최대 추력에 장착 효율(보정 상수)을 곱한다.
- 기본 구성(F500, M920, 10인치, LiPo 3S 5000 mAh)이 PX4 iris 값과 같아지도록 보정 상수를 정한다.
"""
import argparse
import math
import os
import sys
import xml.etree.ElementTree as ET

import yaml

RHO = 1.225
GRAV = 9.80665
IRIS = dict(
    mass=1.5, ixx=0.029125, iyy=0.029125, izz=0.055225,
    max_rot=1100.0, motor_const=5.84e-06, tau_up=0.0125, moment_const=0.06, ca_km=0.05,
    wheelbase_mm=500.0, prop_in=10.0, cda=0.06,
    rotor_xy=[(0.13, -0.22), (-0.13, 0.20), (0.13, 0.22), (-0.13, -0.20)],      # SDF (앞 x, 왼쪽 y)
    ca_xy=[(0.1515, 0.245), (-0.1515, -0.1875), (0.1515, -0.245), (-0.1515, 0.1875)],  # PX4 (앞 x, 오른쪽 y)
    ca_km_sign=[1.0, 1.0, -1.0, -1.0],
)
IRIS["t_max"] = IRIS["motor_const"] * IRIS["max_rot"] ** 2
DEFAULT_DESIGN = dict(frame="F500", motor="M920", prop_in=10, battery=dict(chemistry="lipo", cells=3, capacity_mah=5000))


class DesignError(Exception):
    pass


def check_choices(design, cat):
    b = design.get("battery", {})
    if design.get("frame") not in cat["frames"]:
        raise DesignError("frame 값이 부품표에 없음: %s" % design.get("frame"))
    if design.get("motor") not in cat["motors"]:
        raise DesignError("motor 값이 부품표에 없음: %s" % design.get("motor"))
    if design.get("prop_in") not in cat["props"]["allowed_in"]:
        raise DesignError("prop_in 값이 부품표에 없음: %s" % design.get("prop_in"))
    if b.get("chemistry") not in cat["batteries"]["chemistry"]:
        raise DesignError("battery.chemistry 값이 부품표에 없음: %s" % b.get("chemistry"))
    if b.get("cells") not in cat["batteries"]["cells_allowed"]:
        raise DesignError("battery.cells 값이 부품표에 없음: %s" % b.get("cells"))
    if b.get("capacity_mah") not in cat["batteries"]["capacity_mah_allowed"]:
        raise DesignError("battery.capacity_mah 값이 부품표에 없음: %s" % b.get("capacity_mah"))


def raw_inertia(s, m_frame, m_tip, m_esc, m_av, m_batt):
    """부품 질량 배치로 계산한 관성(보정 전)."""
    ixx = iyy = izz = 0.0
    m_arm = 0.55 * m_frame / 4.0
    for (x, y) in IRIS["rotor_xy"]:
        x *= s
        y *= s
        ixx += m_tip * y * y
        iyy += m_tip * x * x
        izz += m_tip * (x * x + y * y)
        ixx += m_esc * (0.5 * y) ** 2
        iyy += m_esc * (0.5 * x) ** 2
        izz += m_esc * ((0.5 * x) ** 2 + (0.5 * y) ** 2)
        ixx += m_arm * y * y / 3.0
        iyy += m_arm * x * x / 3.0
        izz += m_arm * (x * x + y * y) / 3.0
    m_c = 0.45 * m_frame + m_av
    a, b, c = 0.20 * s, 0.14 * s, 0.06
    ixx += m_c * (b * b + c * c) / 12.0
    iyy += m_c * (a * a + c * c) / 12.0
    izz += m_c * (a * a + b * b) / 12.0
    k = (m_batt / 0.39) ** (1.0 / 3.0)
    a, b, c = 0.14 * k, 0.045 * k, 0.035 * k
    ixx += m_batt * (b * b + c * c) / 12.0
    iyy += m_batt * (a * a + c * c) / 12.0
    izz += m_batt * (a * a + b * b) / 12.0
    return ixx, iyy, izz


def physics(design, cat):
    """보정 전 물리량."""
    fr = cat["frames"][design["frame"]]
    mo = cat["motors"][design["motor"]]
    pr = cat["props"]
    bc = cat["batteries"]
    chem = bc["chemistry"][design["battery"]["chemistry"]]
    fx = cat["fixed"]
    d_in = float(design["prop_in"])
    dia = d_in * 0.0254
    cells = int(design["battery"]["cells"])
    cap_ah = design["battery"]["capacity_mah"] / 1000.0
    s = fr["wheelbase_mm"] / IRIS["wheelbase_mm"]
    m_prop = pr["mass_kg_at_10in"] * (d_in / 10.0) ** 2.5
    e_nom = cells * chem["v_nom"] * cap_ah
    m_batt = e_nom / chem["wh_per_kg"] + bc["pack_overhead_kg"]
    mass = fr["mass_kg"] + 4.0 * (mo["mass_kg"] + m_prop + fx["esc_mass_kg"]) + fx["avionics_mass_kg"] + m_batt
    kt_prop = pr["ct"] * RHO * dia ** 4 / (4.0 * math.pi ** 2)
    cq = pr["cp"] * RHO * dia ** 5 / (8.0 * math.pi ** 3)
    kvr = mo["kv"] * 2.0 * math.pi / 60.0
    kt_m = 1.0 / kvr
    r_pack = cells * chem["r_cell_ohm_at_5ah"] * (5.0 / cap_ah)
    v_open = cells * chem["v_start"]
    i_av = fx["avionics_power_w"] / v_open
    i_batt_max = chem["c_rate_max"] * cap_ah

    def i_motor(w):
        return cq * w * w / kt_m + mo["i0_a"]

    def v_gap(w):
        im = i_motor(w)
        return (w / kvr + mo["r_ohm"] * im) - (v_open - r_pack * (4.0 * im + i_av))

    lo, hi = 0.0, v_open * kvr
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        if v_gap(mid) > 0.0:
            hi = mid
        else:
            lo = mid
    w_volt = lo
    i_lim_batt = (i_batt_max - i_av) / 4.0
    i_lim = min(mo["imax_a"], i_lim_batt)
    w_curr = math.sqrt(kt_m * (i_lim - mo["i0_a"]) / cq) if i_lim > mo["i0_a"] else 0.0
    if w_volt <= w_curr:
        w_max, limiter = w_volt, "전압"
    elif mo["imax_a"] <= i_lim_batt:
        w_max, limiter = w_curr, "모터 허용 전류"
    else:
        w_max, limiter = w_curr, "배터리 허용 전류"
    j_rot = m_prop * dia * dia / 12.0
    tau_m = j_rot * mo["r_ohm"] / (kt_m ** 2)
    m_tip = mo["mass_kg"] + m_prop
    raw_i = raw_inertia(s, fr["mass_kg"], m_tip, fx["esc_mass_kg"], fx["avionics_mass_kg"], m_batt)
    return dict(s=s, dia=dia, d_in=d_in, mass=mass, m_batt=m_batt, m_prop=m_prop, e_nom=e_nom,
                kt_prop=kt_prop, cq=cq, kvr=kvr, kt_m=kt_m, r_m=mo["r_ohm"], i0=mo["i0_a"], imax_m=mo["imax_a"],
                r_pack=r_pack, v_open=v_open, i_av=i_av, i_batt_max=i_batt_max,
                w_max=w_max, w_volt=w_volt, w_curr=w_curr, limiter=limiter, tau_m=tau_m, raw_i=raw_i,
                max_prop_in=fr["max_prop_in"])


def build(design, cat):
    """보정까지 적용한 기체 값."""
    check_choices(design, cat)
    ref = physics(DEFAULT_DESIGN, cat)
    p = physics(design, cat)
    fx = cat["fixed"]
    rules = cat["rules"]
    eta_inst = IRIS["t_max"] / (ref["kt_prop"] * ref["w_max"] ** 2)      # 장착 효율(기본 구성 = iris)
    t_max = eta_inst * p["kt_prop"] * p["w_max"] ** 2
    motor_const = t_max / IRIS["max_rot"] ** 2
    tau_up = min(max(IRIS["tau_up"] * p["tau_m"] / ref["tau_m"], 0.006), 0.08)
    d_ratio = p["d_in"] / IRIS["prop_in"]
    inertia = [IRIS[k] * p["raw_i"][i] / ref["raw_i"][i] for i, k in enumerate(("ixx", "iyy", "izz"))]
    weight = p["mass"] * GRAV
    twr = 4.0 * t_max / weight
    t_h = weight / 4.0
    v = dict(design=design, scale=p["s"], prop_in=p["d_in"], prop_dia_m=p["dia"], mass=p["mass"],
             battery_mass=p["m_batt"], inertia=dict(ixx=inertia[0], iyy=inertia[1], izz=inertia[2]),
             t_max_per_motor=t_max, thrust_to_weight=twr, limiter=p["limiter"],
             motor_const=motor_const, moment_const=IRIS["moment_const"] * d_ratio, max_rot=IRIS["max_rot"],
             tau_up=tau_up, tau_down=2.0 * tau_up, cda=IRIS["cda"] * p["s"] ** 2,
             eta_inst=eta_inst, kt_prop=p["kt_prop"], cq=p["cq"], kvr=p["kvr"], kt_m=p["kt_m"],
             r_m=p["r_m"], i0=p["i0"], r_pack=p["r_pack"], v_open=p["v_open"], i_av=p["i_av"],
             i_batt_max=p["i_batt_max"], w_max_phys=p["w_max"],
             energy_wh=p["e_nom"], usable_wh=p["e_nom"] * cat["batteries"]["usable_fraction"],
             avionics_power_w=fx["avionics_power_w"], esc_efficiency=fx["esc_efficiency"])
    problems = []
    if p["d_in"] > p["max_prop_in"]:
        problems.append("프로펠러 %g인치는 %s 프레임 한도(%g인치)를 넘음" % (p["d_in"], design["frame"], p["max_prop_in"]))
    if twr < rules["min_thrust_to_weight"]:
        problems.append("추력 대 무게 %.2f < 요구 %.2f (최대 추력 제한 요인: %s)" % (twr, rules["min_thrust_to_weight"], p["limiter"]))
    hover = None
    if twr > 1.0:
        w_h = math.sqrt(t_h / (eta_inst * p["kt_prop"]))
        i_h = p["cq"] * w_h * w_h / p["kt_m"] + p["i0"]
        v_m = w_h / p["kvr"] + p["r_m"] * i_h
        i_tot = 4.0 * i_h + p["i_av"]
        p_h = 4.0 * v_m * i_h / fx["esc_efficiency"] + fx["avionics_power_w"] + i_tot ** 2 * p["r_pack"]
        minutes = v["usable_wh"] / p_h * 60.0
        cmd = (math.sqrt(t_h / motor_const) - 100.0) / 1000.0
        hover = dict(power_w=p_h, current_a=i_tot, minutes=minutes, throttle=cmd)
        if minutes < rules["min_hover_minutes"]:
            problems.append("호버 시간 %.1f분 < 요구 %.1f분" % (minutes, rules["min_hover_minutes"]))
    v["hover"] = hover
    v["problems"] = problems
    return v


def px4_params(v):
    s = v["scale"]
    km = IRIS["ca_km"] * v["prop_in"] / IRIS["prop_in"]
    out = {}
    for i, (x, y) in enumerate(IRIS["ca_xy"]):
        out["CA_ROTOR%d_PX" % i] = round(x * s, 4)
        out["CA_ROTOR%d_PY" % i] = round(y * s, 4)
        out["CA_ROTOR%d_KM" % i] = round(km * IRIS["ca_km_sign"][i], 4)
    if v["hover"]:
        out["MPC_THR_HOVER"] = round(min(max(v["hover"]["throttle"], 0.1), 0.8), 3)
    return out


def write_sdf(base_path, out_path, v, gps_model="race_gps", clean_imu=True):
    tree = ET.parse(base_path)
    model = tree.getroot().find("model")
    s = v["scale"]
    d_ratio = v["prop_in"] / IRIS["prop_in"]
    for link in model.findall("link"):
        name = link.get("name")
        if name == "base_link":
            inert = link.find("inertial")
            inert.find("mass").text = "%.4f" % v["mass"]
            for k in ("ixx", "iyy", "izz"):
                inert.find("inertia").find(k).text = "%.6f" % v["inertia"][k]
            link.find("collision/geometry/box/size").text = "%.3f %.3f 0.11" % (0.47 * s, 0.47 * s)
            link.find("visual/geometry/mesh/scale").text = "%g %g %g" % (s, s, s)
        elif name.startswith("rotor_"):
            i = int(name.split("_")[1])
            x, y = IRIS["rotor_xy"][i]
            link.find("pose").text = "%.4f %.4f 0.023 0 0 0" % (x * s, y * s)
            link.find("collision/geometry/cylinder/radius").text = "%.4f" % (0.128 * d_ratio)
            link.find("visual/geometry/mesh/scale").text = "%g %g 1" % (d_ratio, d_ratio)
    for plug in list(model.findall("plugin")):
        fn = plug.get("filename", "")
        if fn == "libgazebo_motor_model.so":
            plug.find("timeConstantUp").text = "%.5f" % v["tau_up"]
            plug.find("timeConstantDown").text = "%.5f" % v["tau_down"]
            plug.find("motorConstant").text = "%.6e" % v["motor_const"]
            plug.find("momentConstant").text = "%.4f" % v["moment_const"]
        elif fn == "libgazebo_imu_plugin.so" and clean_imu:
            for tag in ("gyroscopeRandomWalk", "gyroscopeTurnOnBiasSigma", "accelerometerRandomWalk", "accelerometerTurnOnBiasSigma"):
                el = plug.find(tag)
                if el is not None:
                    el.text = "0"
    for inc in model.findall("include"):                   # 항법은 평가 대상이 아니라 GPS 위치 잡음을 끈 모형을 씀
        uri = inc.find("uri")
        if uri is not None and uri.text.strip() == "model://gps" and gps_model:
            uri.text = "model://" + gps_model
    for link in model.findall("link"):                     # 영상 송출 플러그인은 레이스에 쓰지 않음
        for sensor in link.findall("sensor"):
            for plug in list(sensor.findall("plugin")):
                if plug.get("name") == "GstCameraPlugin":
                    sensor.remove(plug)
    data = ET.tostring(tree.getroot(), encoding="unicode")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("<?xml version='1.0'?>\n<!-- build_vehicle.py 가 만든 파일. 직접 고치지 말 것 -->\n" + data + "\n")


def report(v):
    d = v["design"]
    b = d["battery"]
    lines = []
    lines.append("설계: 프레임 %s / 모터 %s / 프로펠러 %g인치 / 배터리 %s %dS %d mAh" % (
        d["frame"], d["motor"], v["prop_in"], b["chemistry"], b["cells"], b["capacity_mah"]))
    lines.append("총질량            %.3f kg (배터리 %.3f kg)" % (v["mass"], v["battery_mass"]))
    lines.append("관성 Ixx Iyy Izz  %.4f  %.4f  %.4f kg m^2" % (v["inertia"]["ixx"], v["inertia"]["iyy"], v["inertia"]["izz"]))
    lines.append("모터당 최대 추력  %.2f N (제한 요인: %s)" % (v["t_max_per_motor"], v["limiter"]))
    lines.append("추력 대 무게      %.2f" % v["thrust_to_weight"])
    lines.append("모터 응답 시간    올림 %.1f ms / 내림 %.1f ms" % (v["tau_up"] * 1e3, v["tau_down"] * 1e3))
    if v["hover"]:
        h = v["hover"]
        lines.append("호버              스로틀 %.0f %% / 전력 %.0f W / 전류 %.1f A / 시간 %.1f분" % (
            h["throttle"] * 100.0, h["power_w"], h["current_a"], h["minutes"]))
    lines.append("배터리            공칭 %.1f Wh / 가용 %.1f Wh / 허용 전류 %.0f A" % (v["energy_wh"], v["usable_wh"], v["i_batt_max"]))
    lines.append("바람 받는 면적    C_dA %.3f m^2" % v["cda"])
    if v["problems"]:
        lines.append("제작 불가:")
        lines.extend("  - " + x for x in v["problems"])
    else:
        lines.append("판정: 제작 가능")
    return "\n".join(lines)


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    ap = argparse.ArgumentParser()
    ap.add_argument("--design", default=os.path.join(here, "my_design.yaml"))
    ap.add_argument("--catalog", default=os.path.join(here, "catalog.yaml"))
    ap.add_argument("--base-sdf", default=os.path.join(here, "iris_base.sdf"))
    ap.add_argument("--out", default=os.path.join(here, "..", "build"))
    ap.add_argument("--report-only", action="store_true")
    ap.add_argument("--gps-model", default="race_gps", help="race_gps = 위치 잡음 없음, gps = PX4 기본(잡음 있음)")
    ap.add_argument("--raw-imu", action="store_true", help="IMU 바이어스를 PX4 기본 모형 그대로 둠 (점검용)")
    a = ap.parse_args()
    with open(a.catalog, encoding="utf-8") as f:
        cat = yaml.safe_load(f)
    with open(a.design, encoding="utf-8") as f:
        design = yaml.safe_load(f)
    try:
        v = build(design, cat)
    except DesignError as e:
        print("설계 오류: %s" % e)
        return 2
    text = report(v)
    print(text)
    if a.report_only:
        return 2 if v["problems"] else 0
    if v["problems"]:
        return 2
    os.makedirs(a.out, exist_ok=True)
    write_sdf(a.base_sdf, os.path.join(a.out, "iris_race.sdf"), v, a.gps_model, not a.raw_imu)
    with open(os.path.join(a.out, "vehicle.yaml"), "w", encoding="utf-8") as f:
        yaml.safe_dump(v, f, allow_unicode=True, default_flow_style=False)
    with open(os.path.join(a.out, "px4_params.yaml"), "w", encoding="utf-8") as f:
        yaml.safe_dump(px4_params(v), f, default_flow_style=False)
    with open(os.path.join(a.out, "design_report.txt"), "w", encoding="utf-8") as f:
        f.write(text + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
