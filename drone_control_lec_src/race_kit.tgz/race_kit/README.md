# 드론 제어 기말 레이스 키트

PX4 SITL과 Gazebo에서 정해진 코스를 비행하고 완주 시간과 벌점으로 점수를 계산한다. 평가 대상은 제어다. 수정할 수 있는 파일은 기체 설계 파일과 게인 파일 두 개다.

**폴더 구성**

| 경로 | 내용 | 수정 |
|---|---|---|
| `design/my_design.yaml` | 기체 설계 | 가능 |
| `gains/my_gains.yaml` | PX4 게인과 구간별 게인표 | 가능 |
| `design/catalog.yaml` | 부품표 | 금지 |
| `courses/practice.yaml` | 연습 코스 | 금지 |
| `race.sh`, `check_env.sh` | 레이스 실행, 환경 점검 | 금지 |
| `nodes/`, `tools/`, `models/` | 실행 노드, 심판, 바람, 월드 생성기, 모형 | 금지 |
| `results/` | 실행 결과 | 해당 없음 |

## 1. 준비

**필요 환경**

- 수업에서 구축한 환경: WSL2 Ubuntu 20.04, ROS Noetic, PX4 SITL, MAVROS
- 가상 화면 도구 Xvfb: `sudo apt install -y xvfb`

**받는 곳**

키트 묶음 `race_kit.tgz`는 수업 GitHub 저장소 `ndh8205/CUAS_Drone`의 `drone_control_lec_src` 폴더에 있다. 수업에서 쓰던 Ubuntu 20.04 터미널에서 아래 명령으로 받는다.

```bash
cd ~
wget https://github.com/ndh8205/CUAS_Drone/raw/main/drone_control_lec_src/race_kit.tgz
```

브라우저로 받았다면 Windows 다운로드 폴더에 저장된 파일을 WSL 홈 폴더로 복사한다.

```bash
cp /mnt/c/Users/<Windows 사용자 이름>/Downloads/race_kit.tgz ~/
```

**설치 순서**

1. 홈 폴더에서 묶음 풀기
2. 실행 권한 부여와 환경 점검

```bash
cd ~
tar -xzf race_kit.tgz
cd ~/race_kit
chmod +x race.sh check_env.sh
./check_env.sh
```

점검 결과가 모두 정상이면 "점검 통과"가 출력된다. 문제 항목에는 해결 명령이 함께 출력된다.

## 2. 실행

```bash
./race.sh practice                 # 연습 코스, 화면 없이 실행
./race.sh practice --gui           # Gazebo 화면과 드론 카메라 창을 함께 실행
./race.sh practice --gui --follow  # Gazebo 화면이 기체를 따라감
./race.sh practice --name try01    # 결과 폴더 이름 지정 (results/try01)
./race.sh practice --gains gains/test_a.yaml --design design/test_a.yaml
```

실행 순서는 기체 생성, 코스 생성, 시뮬레이터 시작, 레이스, 결과 출력이다. 한 번 실행에 1–2분 걸린다. 레이스 시간은 시뮬레이션 시간으로 측정하므로 컴퓨터 성능과 무관하다.

`race.sh`는 시뮬레이터를 켜기 전에 설계 파일과 게인 파일의 형식을 점검한다. 파일 이름이 틀렸거나 형식이 맞지 않으면 고칠 곳을 출력하고 끝난다. 같은 이름으로 다시 실행하면 앞 실행의 결과를 덮어쓴다.

레이스는 PX4 시뮬레이션의 저장 파라미터(`~/.ros/parameters*.bson`)를 시작할 때와 끝날 때 지운다. 매번 기본값에서 시작하고 레이스에서 바꾼 값이 다른 시뮬레이션 실행에 남지 않게 하려는 것이다. QGroundControl에서 따로 바꿔 저장한 시뮬레이션 파라미터도 함께 지워진다.

**실행 중 출력 예**

```text
  [   0.0 s] 이륙 (기록 시작)
  [   5.6 s] 게이트 G1 지남
  [   8.0 s] 게이트 G2 지남
           게인 조 -> wind (바람) · 바뀐 값 0개
  [  10.5 s] 게이트 G3 지남
  [  22.0 s] 제자리 유지 H1 성공
  [  29.1 s] 표식 위로 정렬 중
  [  38.9 s] PX4 자동 착륙으로 넘김
  [  42.3 s] 끝
```

기본 파일 그대로 연습 코스를 실행한 출력의 일부다. 시각은 기체가 땅에서 뜬 순간을 0으로 둔 시뮬레이션 시간이다. 같은 파일로 다시 실행해도 0.3초 안팎의 차이가 난다.

## 3. 기체 설계 파일

`design/my_design.yaml`에서 프레임, 모터, 프로펠러, 배터리를 선택한다. 선택할 수 있는 값은 `design/catalog.yaml`에 있다. 부품표는 교육용 가상 값이다.

```yaml
frame: F500            # F330, F450, F500, F600 (휠베이스 mm)
motor: M920            # M2400, M1400, M920, M700, M480 (KV)
prop_in: 10            # 프로펠러 지름 5–12 인치, 프레임 한도 이하
battery:
  chemistry: lipo      # lipo 또는 liion
  cells: 3             # 2–6 (2S–6S)
  capacity_mah: 5000   # 1300, 2200, 3300, 5000, 8000, 10000
```

기체 생성기 `design/build_vehicle.py`가 설계에서 질량, 관성, 모터당 최대 추력, 모터 응답 시간, 호버 시간을 계산하고 Gazebo 기체와 PX4 기체 파라미터를 생성한다. `--report-only`를 붙이면 레이스를 실행하지 않고 계산 결과만 출력한다.

```bash
python3 design/build_vehicle.py --report-only
```

**계산 모형**

- 프로펠러: 추력 `T = k_T w^2`, 토크 `Q = c_Q w^2`, `k_T`는 지름의 4제곱에 비례
- 모터: 단자 전압 `V = w / K_V + R I`, 전류 `I = Q / K_t + I_0`
- 배터리: 단자 전압 = 셀 수 x 시작 전압 - 내부 저항 x 총 전류, 전류 한도 = 방전율 x 용량
- 최대 회전수: 전압 한계와 전류 한계 중 작은 쪽
- 질량: 프레임, 모터, 프로펠러, 변속기, 항전 장비, 배터리의 합
- 바람 받는 면적: 프레임 크기의 제곱에 비례

**제작 조건**

- 프로펠러 지름이 프레임 한도 이하
- 추력 대 무게 1.3 이상
- 호버 시간 4분 이상

조건을 만족하지 않는 설계는 "제작 불가"로 출력되고 레이스가 시작되지 않는다. 기체가 바뀌면 같은 게인에서도 응답이 달라진다. 최대 추력이 크고 관성이 작은 기체는 각속도 루프의 게인을 낮춰야 진동하지 않는다.

## 4. 게인 파일

`gains/my_gains.yaml`에는 PX4 다중 루프 제어기의 게인 20개와 구간별 게인표가 있다.

| 루프 | 파라미터 | 뜻 | 허용 범위 | 기본값 |
|---|---|---|---|---|
| 위치 | `MPC_XY_P` | 수평 위치 오차를 속도 명령으로 바꾸는 비례 게인 | 0.1–2.0 | 0.95 |
| 위치 | `MPC_Z_P` | 고도 오차를 상승 속도 명령으로 바꾸는 비례 게인 | 0.1–1.5 | 1.0 |
| 속도 | `MPC_XY_VEL_P_ACC` | 수평 속도 오차의 비례 게인 | 1.2–5.0 | 1.8 |
| 속도 | `MPC_XY_VEL_I_ACC` | 수평 속도 오차의 적분 게인 | 0.0–10.0 | 0.4 |
| 속도 | `MPC_XY_VEL_D_ACC` | 수평 속도 오차의 미분 게인 | 0.1–2.0 | 0.2 |
| 속도 | `MPC_Z_VEL_P_ACC` | 수직 속도 오차의 비례 게인 | 2.0–15.0 | 4.0 |
| 속도 | `MPC_Z_VEL_I_ACC` | 수직 속도 오차의 적분 게인 | 0.2–3.0 | 2.0 |
| 속도 | `MPC_Z_VEL_D_ACC` | 수직 속도 오차의 미분 게인 | 0.0–2.0 | 0.0 |
| 자세 | `MC_ROLL_P`, `MC_PITCH_P` | 롤과 피치 각 오차를 각속도 명령으로 바꾸는 비례 게인 | 0.5–12.0 | 4.0 |
| 자세 | `MC_YAW_P` | 요 각 오차의 비례 게인 | 0.5–5.0 | 2.8 |
| 각속도 | `MC_ROLLRATE_P`, `MC_PITCHRATE_P` | 롤과 피치 각속도 오차의 비례 게인 | 0.01–0.5, 0.01–0.6 | 0.15 |
| 각속도 | `MC_ROLLRATE_I`, `MC_PITCHRATE_I` | 롤과 피치 각속도 오차의 적분 게인 | 0.0–2.0 | 0.2 |
| 각속도 | `MC_ROLLRATE_D`, `MC_PITCHRATE_D` | 롤과 피치 각속도 오차의 미분 게인 | 0.0–0.01 | 0.003 |
| 각속도 | `MC_YAWRATE_P`, `MC_YAWRATE_I`, `MC_YAWRATE_D` | 요 각속도 오차의 비례, 적분, 미분 게인 | 0.0–0.6, 0.0–2.0, 0.0–0.01 | 0.2, 0.1, 0.0 |

범위를 벗어난 값은 범위 끝값으로 적용되고 실행 중에 주의 문구가 출력된다. 표에 없는 파라미터는 적용되지 않는다. 최대 속도, 최대 기울기, 착륙 속도 같은 한도 값은 코스 파일이 지정하며 수정할 수 없다.

### 구간별 게인표

코스의 각 구간에는 이름이 있다. 실행 노드는 구간이 바뀔 때 `base` 값 위에 그 구간의 값을 덮어 PX4에 적용한다. 비워 둔 구간은 `base` 값으로 비행한다.

| 구간 이름 | 내용 |
|---|---|
| `cruise` | 게이트 사이 이동 |
| `wind` | 바람 구간 |
| `precision` | 제자리 유지 |
| `landing` | 비전 착륙 |

```yaml
base:
  MPC_XY_P: 0.95
  MPC_XY_VEL_P_ACC: 1.8
  # ... 나머지 값

schedule:
  cruise: {}
  wind:                        # 값은 예시
    MPC_XY_VEL_P_ACC: 2.5
    MPC_XY_VEL_I_ACC: 1.0
  precision: {}
  landing:                     # 값은 예시
    MPC_XY_P: 0.7
```

**파일을 고칠 때의 규칙**

- 들여쓰기는 빈칸 (탭 금지). 구간 이름은 빈칸 2개, 그 아래 값은 빈칸 4개
- 이름 뒤에는 쌍점과 빈칸 한 칸 (`MPC_XY_P: 0.95`)
- 구간의 값은 `{}`를 지운 뒤 아래 줄에 기록
- 값은 숫자 하나, 소수점은 마침표
- `base`에서 지운 게인은 PX4 기본값으로 비행하며 실행할 때 안내 줄 출력

사본을 만들어 값을 바꾸고 `--gains`로 지정하면 원본을 그대로 둔 채 비교할 수 있다.

```bash
cp gains/my_gains.yaml gains/try_a.yaml
nano gains/try_a.yaml
./race.sh practice --name try_a --gains gains/try_a.yaml
grep -H '"score"' results/*/result.json      # 모든 실행의 점수
```

## 5. 코스와 채점

코스 요소와 수치는 `courses/practice.yaml`에 있다. 실전 코스는 같은 요소를 다른 배치와 다른 세기로 구성하며 레이스 당일에 공개한다.

| 요소 | 내용 | 실패 시 |
|---|---|---|
| 게이트 | 기체 중심이 열린 면 안으로 통과 | 게이트마다 벌점 15초 |
| 바람 구간 | 구역 안에서만 바람과 돌풍 작용. 기준 경로에서 허용 폭 이내 유지 | 벌점 5초 |
| 제자리 유지 | 지정 반경 안에서 2초 유지 | 25초 안에 못 하면 벌점 10초 |
| 비전 착륙 | 아래 방향 카메라로 ArUco 표식을 찾아 그 위에 착륙 | 오차 0.1 m 초과분 1 m당 20초, 0.7 m 초과 시 15초 |

**점수**

- 점수 = 완주 시간 + 벌점 (초, 작을수록 좋음)
- 완주 시간 = 기체가 땅에서 뜬 순간부터 접지까지의 시뮬레이션 시간 (시동부터 뜨기까지의 지연은 기록에서 제외)
- 완주 실패: 기울기 70도 초과, 코스 중간 지면 접촉, 제한 시간 초과, 배터리 가용 에너지 소진, 접지 속도 2.5 m/s 초과

바람의 힘은 `F = 1/2 x 1.225 x C_dA x |w - v| (w - v)`로 계산한다. `w`는 바람 속도, `v`는 기체 속도, `C_dA`는 기체 설계에서 정해지는 값이다. 돌풍은 위치로 정해지므로 같은 경로에서는 실행할 때마다 같은 바람이 분다.

착륙 구간에서는 카메라가 기체에 고정되어 있어 기체가 기울면 표식이 화면에서 움직인다. 실행 노드는 이 기울기를 보정하지 않는다. 수평 방향 게인이 높으면 정렬 단계에서 기체가 진동하고 정렬 시간이 길어진다. 착륙 구간의 기수 방향과 탐색 지점은 코스 파일이 정한다.

## 6. 결과

결과는 `results/<실행 이름>/`에 저장된다.

| 파일 | 내용 |
|---|---|
| `result.json` | 상태, 시간, 벌점, 게이트별 통과 위치, 바람 통로 이탈, 착륙 오차, 에너지 |
| `plot.png` | 비행 경로(구간별 색), 고도와 속도 |
| `traj.csv` | 시간별 위치, 속도, 기울기, 구간 |
| `gains.yaml`, `design.yaml` | 그 실행에 사용한 게인과 설계 |
| `runner.log`, `referee.log`, `sim.log` | 실행 노드, 심판, 시뮬레이터 기록 |

Windows에서 그림을 여는 명령은 실행이 끝날 때 출력된다.

## 7. 제출

- 제출 파일: `my_design.yaml`, `my_gains.yaml` (폴더 이름은 학번)
- 채점: 제출한 파일 두 개만 채점 컴퓨터로 가져가 같은 키트로 실전 코스 실행
- 키트의 다른 파일을 수정한 결과는 채점에 반영되지 않음
- 형식 오류가 있는 파일과 제작 불가 설계는 주행하지 못하므로 완주 실패로 처리

제출 전에 제출할 파일을 그대로 지정해 연습 코스를 한 번 실행한다.

```bash
S=/mnt/c/Users/<Windows 사용자 이름>/Downloads/<학번>
mkdir $S
cp design/my_design.yaml $S/my_design.yaml
cp gains/try_b.yaml $S/my_gains.yaml          # 가장 좋았던 게인 파일을 이 이름으로 복사
./race.sh practice --name final --design $S/my_design.yaml --gains $S/my_gains.yaml
```

완주를 확인한 뒤 학번 폴더를 zip 파일 하나로 묶어 메일로 보낸다.

```bash
python3 -m zipfile -c $S.zip $S               # 다운로드 폴더에 <학번>.zip 생성
python3 -m zipfile -l $S.zip                  # 들어 있는 파일 확인
```

| 항목 | 내용 |
|---|---|
| 받는 사람 | `dh.nam@controla.re.kr` |
| 제목 | `[드론제어 기말] <학번> <이름> 1라운드` (2라운드는 끝을 `2라운드`로) |
| 첨부 | Windows 다운로드 폴더의 `<학번>.zip` |

## 8. 문제 해결

| 증상 | 조치 |
|---|---|
| "ROS 와 PX4 환경이 잡혀 있지 않음" | 새 터미널에서 다시 실행, `~/.bashrc`의 source 줄 확인 |
| "시뮬레이터 준비 실패"가 세 번 반복 | `wsl --shutdown` 뒤 다시 실행, Xvfb 설치 확인 |
| "제작 불가" | 출력된 조건을 보고 설계 수정 |
| "입력 파일 오류" | 출력된 파일 이름과 줄 번호 확인, 4절의 규칙대로 수정 |
| "Permission denied" | `chmod +x race.sh check_env.sh` 실행 |
| `--gui`에서 Gazebo 화면이 뜨지 않음 | `wsl --shutdown` 뒤 다시 실행. 연습과 채점은 화면 없이도 가능 |
| 디스크 공간 부족 | `rosclean purge -y`로 ROS 실행 기록 삭제, 필요 없는 `results/` 폴더 삭제 |
| 시뮬레이션 시간이 멈추거나 끊김 | `./check_env.sh`의 시계 항목 확인 |
| 이전 실행이 남아 있음 | `pkill -x px4; pkill -x gzserver` 뒤 다시 실행 |
| `wget`으로 키트를 받지 못함 | 브라우저로 같은 주소를 열어 받은 뒤 1절의 복사 명령 사용 |

레이스는 끝날 때 그 실행의 PX4 비행 기록(`~/.ros/log/<날짜>/*.ulg`, 실행마다 약 20 MB)을 지운다. 남기려면 `RACE_KEEP_ULOG=1 ./race.sh practice`처럼 실행한다.
